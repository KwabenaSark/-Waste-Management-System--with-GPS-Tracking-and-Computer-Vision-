import { Navigate, useRoutes } from 'react-router-dom';
// layouts
import DashboardLayout from './layouts/dashboard';
import SimpleLayout from './layouts/simple';
//
import BlogPage from './pages/BlogPage';
import UserPage from './pages/UserPage';
import LoginPage from './pages/LoginPage';
import Page404 from './pages/Page404';
import ProductsPage from './pages/ProductsPage';
import DashboardAppPage from './pages/DashboardAppPage';
import Expo from './pages/Expo';
import RegisterPage from './pages/RegisterPage';
import UpdatePage from './pages/UpdatePage';
import { useEffect, useState } from 'react';
import axios from 'axios';
import VehiclePage from './pages/VehiclePage';
import VehicleAdd from './pages/addPages/VehicleAdd';
import VehicleUpdate from './pages/addPages/VehicleUpdate';
import FuelLogPage from './pages/FuelLogPage';
import FuelAddForm from './Forms/FuelAddForm';
import FuelAdd from './pages/addPages/FuelAdd';
import FuelUpdate from './pages/addPages/FuelUpdate';
import CollectionRecords from './pages/CollectionRecords';
import CollectionAdd from './pages/addPages/CollectionAdd';
import CollectionUpdate from './pages/addPages/CollectionUpdate';
import Location from './pages/Locations';
import LocationAdd from './pages/addPages/LocationAdd';
import LocationUpdate from './pages/addPages/LocationUpdate';
import GPS from './pages/GPS';
import IssuePage from './pages/Issue';
import IssueAdd from './pages/addPages/IssueAdd';
import IssueUpdate from './pages/addPages/IssueUpdate';
import Report from './pages/Report';
import LandingPage from './LandingPage/LandingPage';

import CustomerUpdate from './pages/addPages/CustomerUpdate';
import CustomersPage from './pages/Customers';
import AddressForm from './pages/checkout/AddressForm';
import Checkout from './pages/checkout/Checkout';

// ----------------------------------------------------------------------

export default function Router() {


  

    const displayID = localStorage.getItem('displayID');
  
    const [user, setUser] = useState({
      username: '',
      password: '',
      role: '', // Default role
      picture: '',
      status:''
    });
  
    useEffect(() => {
      const fetchUserData = async () => {
        try {
          const response = await axios.get(`http://localhost:8080/users/${displayID}`);
          const userData = response.data;
          setUser(userData);
        } catch (err) {
          console.log(err);
        }
      };
  
      // Check if displayID is defined before making the request
      if (displayID) {
        fetchUserData();
      }
    }, [displayID]);
  
    const isGarbageCollector = user.role === 'Garbage Collector';
    const isClerk = user.role === 'Clerk';
    const session = user.status === "No";




 
    
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
      const Token = localStorage.getItem('Token');
      setIsLoggedIn(Token); // Assuming 'True' in local storage means logged in
  }, []);



  const routes = useRoutes([
    {
      element: <LandingPage /> ,
      children: [
        { element: <Navigate to="/dashboard/landing" />, index: true },
      ],
    },
    {
      path: '/dashboard',
        element: session ? <LandingPage /> : <DashboardLayout />,
      children: [
        { element:  isClerk ? <DashboardLayout /> : <DashboardAppPage /> , index: true },
        { path: 'app', element: <DashboardAppPage /> },
        {
          path: 'user',
          element: isGarbageCollector ? <Navigate to="/dashboard" /> : <UserPage />,
        },
        {
          path: 'vehicle',
          element: isGarbageCollector ? <Navigate to="/dashboard" /> : <VehiclePage />,
        },
        {
          path: 'CollectionRec',
          element: isGarbageCollector ? <Navigate to="/dashboard" /> : <CollectionRecords />,
        },
        {
          path: 'GPS',
          element: isGarbageCollector ? <Navigate to="/dashboard" /> : <GPS />,
        },
        {
          path: 'Report',
          element: isGarbageCollector ? <Navigate to="/dashboard" /> : <Report />,
        }, {
          path: 'Customers',
          element: isGarbageCollector ? <Navigate to="/dashboard" /> : <CustomersPage />,
        },
        { path: 'products', element: <ProductsPage /> },
        { path: 'blog', element: <BlogPage /> },
        { path: 'Expo', element: <Expo /> },
        { path: 'Reg', element: <RegisterPage /> },
        { path: 'Update', element: <UpdatePage /> },
        { path: 'update/:id', element: <UpdatePage /> },
        { path: 'vehicle', element: <VehiclePage /> },
        { path: 'Addvehicle', element: <VehicleAdd /> },
        { path: 'UpdateVehicle/:VehicleID', element: <VehicleUpdate /> },
        { path: 'FuelLog', element: <FuelLogPage /> },
        { path: 'FuelAdd', element: <FuelAdd/> },
        { path: 'UpdateFuel/:id', element: <FuelUpdate /> },
        { path: 'CollectionRec', element: <CollectionRecords /> },
        { path: 'CollectionAdd/:id', element: <CollectionAdd /> },
        { path: 'UpdateCollection/:id', element: <CollectionUpdate /> },
        { path: 'Location', element: <Location /> },
        { path: 'LocationAdd', element: <LocationAdd /> },
        { path: 'LocationUpdate/:id', element: <LocationUpdate /> },
        { path: 'GPS', element: <GPS /> },
        { path: 'Issue', element: <IssuePage/> },
        { path: 'IssueAdd', element: <IssueAdd/> },
        { path: 'IssueUpdate/:id', element: <IssueUpdate /> },
        { path: 'Report', element: <Report /> },
        { path: 'CustomerUpdate/:id', element: <CustomerUpdate /> },
       
      
     
      ],
    },
  
    {
      element: <SimpleLayout />,
      children: [
        { element: <Navigate to="/dashboard/app" />, index: true },
        { path: '404', element: <Page404 /> },
        { path: '*', element: <Navigate to="/404" /> },
        { path: 'Login', element: <LoginPage  /> },
        { path: 'Register', element: <RegisterPage  /> },
        { path: 'Landing', element:    <LandingPage /> },
        { path: 'SignUp', element:    <Checkout /> },
       

      ],
    },
    {
      path: '*',
      element: <Navigate to="/404" replace />,
    },
    {
      path: 'Landing',
      element: <Navigate to="/landing" replace />,
    },
    {
      path: 'SignUp',
      element: <Navigate to="/SignUp" replace />,
    },
    
    
  ]);

  return routes;
}
