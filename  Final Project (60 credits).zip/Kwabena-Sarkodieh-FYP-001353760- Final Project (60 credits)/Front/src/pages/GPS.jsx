import React, { useEffect, useState, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import axios from 'axios';
import { Card, Button, Typography, Grid, Paper, List, ListItem, ListItemText, ListItemAvatar, Avatar } from '@mui/material';
import CardContent from '@mui/material/CardContent';
import { styled } from '@mui/material/styles';
import 'mapbox-gl/dist/mapbox-gl.css';
import Replay from './Replay';
import Stack from '@mui/material/Stack';


const AnimatedCard = styled(Card)`
  display: block;
  height: 80px;
  width: 50%;
  top: -80px;
  float: right;
  animation: swipeUp 0.5s ease-in-out;

  @keyframes swipeUp {
    from {
      transform: translateY(100%);
    }
    to {
      transform: translateY(0);
    }
  }
}`;

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));

const GPS = () => {
    
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));

  const [emp, setEmp] = useState([]);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [mapStyle, setMapStyle] = useState('mapbox://styles/mapbox/streets-v12');
  const [selectedId, setSelectedId] = useState(null);
  const [isCardVisible, setCardVisibility] = useState(false);
  const [show, setShow] = useState([]);

  // Use useRef to hold the map object
  const mapRef = useRef(null);

  // Initialize geojsonFeatures outside the map load callback
  let geojsonFeatures = [];

  useEffect(() => {
    const fetchAllVehicles = async () => {
      try {
        const res = await axios.get('http://localhost:8080/GPS-List');
        const fetchedUsers = res.data;
        setEmp(fetchedUsers);
      } catch (err) {
        console.log(err);
      }
    };

    const fetchAllUsers = async () => {
      try {
        const res = await axios.get('http://localhost:8080/GPS');
        const fetchedUsers = res.data;

        const usersWithNumericCoordinates = fetchedUsers.map((user) => ({
          ...user,
          Latitude: parseFloat(user.Latitude),
          Longitude: parseFloat(user.Longitude),
        }));

        setUsers(usersWithNumericCoordinates);
        setFilteredUsers(usersWithNumericCoordinates);

        // Initialize the map only if it hasn't been initialized yet
        if (!mapRef.current) {
          mapboxgl.accessToken = 'pk.eyJ1Ijoia29iYnkxLSIsImEiOiJjbHB2NW5lMmcwMjNqMmhwYm12NWtiZm05In0.Z0IZunMVk_wccwNHMRh7AA';

          mapRef.current = new mapboxgl.Map({
            container: 'map',
            style: mapStyle,
            zoom: 15,
            center: [-0.169342, 5.63966],
          });

          mapRef.current.on('load', () => {
            mapRef.current.loadImage(
              '/assets/illustrations/Truck.png',
              (error, image) => {
                if (error) throw error;

                mapRef.current.addImage('cat', image);

                // Move this part outside the callback
                geojsonFeatures = usersWithNumericCoordinates.map((user) => ({
                  id: user.id,
                  type: 'Feature',
                  geometry: {
                    type: 'Point',
                    coordinates: [user.Longitude, user.Latitude],
                  },
                  properties: {
                    title: user.username + ' ' + user.vehicle,
                  },
                }));

                mapRef.current.addLayer({
                  id: 'points',
                  type: 'symbol',
                  source: {
                    type: 'geojson',
                    data: {
                      type: 'FeatureCollection',
                      features: geojsonFeatures,
                    },
                  },
                  layout: {
                    'icon-image': 'cat',
                    'icon-size': 0.2,
                    'text-field': ['get', 'title'],
                    'text-size': 12,
                    'text-offset': [0, -5],
                    'text-anchor': 'top',
                  },
                });
              }
            );
          });
        }
      } catch (err) {
        console.error(err);
      }
    };

    fetchAllUsers();
    fetchAllVehicles();
  }, [mapStyle]);

  const handleStyleChange = (newStyle) => {
    setMapStyle(newStyle);
  };

  const handleListItemClick = (id) => {
    setSelectedId(id);
    console.log('Selected User ID:', id);

    // Retrieve selected user info and update the map center
    SelectedUser(id);
    showCard();
  };

  const SelectedUser = async (id) => {
    try {
      const response = await axios.get(`http://localhost:8080/SelectedUser/${id}`);
      const result = response.data || response.data.error;

      console.log(result, 'tell me');

      // Assuming result is an array of objects
      result.map((details) => {
        if (details && details.Latitude && details.Longitude) {
          mapRef.current.setCenter([details.Longitude, details.Latitude]);
          mapRef.current.resize(); // Refresh the map to display the updated center
        }
        return null; // Ensure you have a return statement in the map function
      });
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Storing selectedId in local storage
localStorage.setItem('selectedId', selectedId);


  // Call the function
  


  

  const showCard = () => {
    setCardVisibility(true);
  };


  const [showMap, setShowMap] = useState(true);
  const [showDetails, setShowDetails] = useState(false);
  const handleClick = () => {
    // Simulate();
    setShowMap(!showMap);
    setShowDetails(!showDetails);
  };

  const handleReverse = () => {
    // setShowMap(true);
    location.reload();
  
    console.log("im running")
  };
  



    // Retrieve timestamp and speed from local storage
    const Timestamp = localStorage.getItem('timestamp');
    const Speed = localStorage.getItem('speed');
  return (
    <>
      <Grid container spacing={1}>
        <Grid item xs={2}>
          <Item>
            <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
              {emp.map((user) => (
                <ListItem
                  key={user.id}
                  onClick={() => handleListItemClick(user.id)}
                  selected={selectedId === user.id}
                  button
                >
                  <ListItemAvatar>
                    <Avatar alt={user.username} src={user.picture} />
                  </ListItemAvatar>
                  <ListItemText primary={user.username} secondary={`Vehicle: ${user.vehicle}`} />
                </ListItem>
              ))}
            </List>
          </Item>
        </Grid>
        <Grid item xs={10}>
        <Card>
      {showMap ? (
        <Card  id="map" style={{ height: '80vh', width: '100%' }}>
          {/* Your map component goes here */}
        </Card>
      ) : (
        <Card>
         <Replay />
      </Card>
       
      )}
    </Card>
          {isCardVisible && (
            <AnimatedCard>
            

      <br />
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 1, sm: 2, md: 6 }}>
      <Button variant="contained" onClick={handleClick}>
        {showDetails ? 'Stop' : 'Play'}
      </Button>

      {showDetails && (
        <>
          <Typography>Speedometer: {Speed}</Typography>
          <Typography>Time: {new Date(Timestamp).toLocaleTimeString()}</Typography>
        </>
      )}

     
    </Stack>
   
            </AnimatedCard>
          )}
          <br />
          <Card style={{ marginTop: '10px' }}>
            <Button onClick={() => handleStyleChange('mapbox://styles/mapbox/dark-v11')}>Dark View</Button>
            <Button onClick={() => handleStyleChange('mapbox://styles/mapbox/satellite-streets-v12')}>
              Satellite View
            </Button>
            <Button onClick={() => handleStyleChange('mapbox://styles/mapbox/streets-v12')}>Streets View</Button>
          </Card>
          <br />
          <Typography>Find Vehicle</Typography>
        </Grid>
      </Grid>
    </>
  );
};

export default GPS;
