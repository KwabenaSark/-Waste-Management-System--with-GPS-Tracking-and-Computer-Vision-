import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Toolbar from '@mui/material/Toolbar';
import Paper from '@mui/material/Paper';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Button from '@mui/material/Button';
import Link from '@mui/material/Link';
import Typography from '@mui/material/Typography';
import AddressForm from './AddressForm';
import PaymentForm from './PaymentForm';
import Review from './Review';
import axios from 'axios';
import  {  useState } from 'react';
import Modal from '@mui/material/Modal';

function Copyright() {
  return (
    <Typography variant="body2" color="text.secondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="#">
        Kwabena Sarkodieh
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}


function PPolicy(){
  return (
    <Typography variant="body2" color="text.secondary" align="center">
      <p><strong>Privacy Policy</strong></p>
      
      <p>Effective Date: 01/01/2024</p>
      
      <p>Thank you for choosing Eco - Waste Solutions for your waste management needs. We are committed to protecting your privacy and ensuring that your personal information is handled securely. This Privacy Policy outlines how we collect, use, disclose, and safeguard your information when you use our waste management system, including our website and mobile applications. By accessing or using our services, you agree to the terms of this Privacy Policy.</p>
      
      <p><strong>1. Information We Collect</strong></p>
      <p>We may collect personal information from you when you interact with our waste management system. This may include:</p>
      <ul>
        <li>Contact information such as name, address, email address, and phone number.</li>
        <li>Account credentials such as username and password.</li>
        <li>Payment information for billing purposes.</li>
        <li>Information about your waste management preferences and usage.</li>
        <li>Device information such as IP address, browser type, and operating system.</li>
      </ul>
      <p>We collect this information to provide you with our services, process your transactions, improve our products and services, and communicate with you.</p>
      
      <p><strong>2. How We Use Your Information</strong></p>
      <p>We use your information for the following purposes:</p>
      <ul>
        <li>To operate and maintain our waste management system.</li>
        <li>To process your transactions and provide you with the requested services.</li>
        <li>To communicate with you about your account, updates, and promotional offers.</li>
        <li>To personalize your experience and improve our products and services.</li>
        <li>To comply with legal obligations and enforce our terms of service.</li>
      </ul>
      
      <p><strong>3. How We Share Your Information</strong></p>
      <p>We may share your personal information with third parties for the following purposes:</p>
      <ul>
        <li>With service providers who assist us in providing our services, such as payment processors and logistics partners.</li>
        <li>With law enforcement or government agencies as required by law or to protect our rights.</li>
        <li>With affiliated companies or business partners for marketing purposes, with your consent.</li>
        <li>In connection with a merger, acquisition, or sale of assets, where your information may be transferred as part of the transaction.</li>
      </ul>
      <p>We do not sell or rent your personal information to third parties for their marketing purposes without your explicit consent.</p>
      
      <p><strong>4. Data Security</strong></p>
      <p>We take appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.</p>
      
      <p><strong>5. Your Choices</strong></p>
      <p>You may update, correct, or delete your account information at any time by logging into your account settings. You may also opt-out of receiving promotional emails from us by following the instructions provided in the emails.</p>
      
      <p><strong>6. Children's Privacy</strong></p>
      <p>Our waste management system is not intended for children under the age of 13, and we do not knowingly collect personal information from children. If you believe that we have collected personal information from a child under 13, please contact us immediately.</p>
      
      <p><strong>7. Changes to This Privacy Policy</strong></p>
      <p>We reserve the right to update or change this Privacy Policy at any time. We will notify you of any changes by posting the new Privacy Policy on this page. Your continued use of our services after any modifications to the Privacy Policy constitutes your acceptance of the changes.</p>
      
      <p><strong>8. Contact Us</strong></p>
      <p>If you have any questions or concerns about this Privacy Policy or our practices, please contact us at [Contact Information].</p>
      
      <p>Thank you for trusting [Company Name] with your waste management needs.</p>
    </Typography>
  );
}





export default function Checkout() {



  const [isPasswordComplexEnough, setPasswordComplexEnough] = useState(false);


    // Define handleBack function
    const handleBack = () => {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };
  
  const steps = ['Create Account', 'Choose Plan','Payment details'];
  
  function getStepContent(step) {
    switch (step) {
      case 0:
        return <AddressForm onPasswordComplexityChange={setPasswordComplexEnough} />;
      case 1:
        return <Review />;
      case 2:
        return <PaymentForm onButtonClick={handleButtonClick} />;
      default:
        throw new Error('Unknown step');
    }
  }




  
  const [activeStep, setActiveStep] = React.useState(0);

  // const handleNext = () => {
  //   setActiveStep(activeStep + 1);
  // };

  const handleNext = () => {
    if (activeStep === 0 && !isPasswordComplexEnough) {
      // Do not proceed if password complexity requirements are not satisfied
      return;
    }
    setActiveStep(activeStep + 1);
  };
  


 let Name = JSON.parse(localStorage.getItem('formData')).username ||" " ;

  // const ccess = JSON.parse(localStorage.getItem('KeyToken')) ;
  const [buttonDisabled, setButtonDisabled] = useState(true);

  const handleButtonClick = () => {
    // Logic to handle button click
    setButtonDisabled(false); // Enable the button
  };

  const [RegStatus, setRegStatus] = useState(true);

 const register = async () => {
  try {
    const storedFormData = JSON.parse(localStorage.getItem('formData'));
    const sub = JSON.parse(localStorage.getItem('Subscription'));

    // Fetch settings data
    const response = await axios.get('http://localhost:8080/Settings');
    const settData = response.data[0];

    // Determine price based on subscription
    const pri = sub == 'Standard' ? settData.Standard :
                sub =='professional' ? settData.Professional :
                sub =='Enterprise' ? settData.Enterprise :
                null;

    // Make POST request with subscription and price
    const postResponse = await axios.post('http://localhost:8080/CusCreate', { ...storedFormData, subscriptions: sub, price: pri });
    console.log(postResponse.data.message);

    // Handle success
    setRegStatus(postResponse.data.message);

    if (postResponse.data.message === 'Insert successful!') {
      // Perform navigation or other actions
      setTimeout(function() {
        window.location.href = '/login'; // Redirect to /login after 1.5 seconds
         // Call the register function
      }, 1500); // 1500 milliseconds = 1.5 seconds
    }
  } catch (error) {
    // Handle errors
    console.error('Error during registration:', error);
    // Optionally set an error status or display an error message to the user
  }
};




  if (activeStep === steps.length) {
    register();

 
  }


  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  
  return (
    <React.Fragment>
      <CssBaseline />
      <AppBar
        position="absolute"
        color="default"
        elevation={0}
        sx={{
          position: 'relative',
          borderBottom: (t) => `1px solid ${t.palette.divider}`,
        }}
      >
         
      </AppBar>
      <Button
  color="primary"
  variant="contained"
  size="small"
  component="a"
  href="/landing"
  style={{
    position: 'absolute',
    top: '5%',
    right: '3%',
  }}
>
  Sign in
</Button>

<Button
  color="primary"
  variant="contained"
  size="small"
  component="a"
  onClick={handleOpen}
  style={{
    position: 'absolute',
    bottom: '5%',
    right: '3%',
  }}
>
  Privacy Policy
</Button>
<Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="privacy-policy-title"
        aria-describedby="privacy-policy-description"
      >
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: 'white',
            padding: '20px',
            minWidth: '300px',
            maxWidth: '80%',
            maxHeight: '80%',
            overflow: 'auto',
            borderRadius: '8px',
            boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
          }}
        >
          <Typography id="privacy-policy-title" variant="h5" gutterBottom>
            Privacy Policy
          </Typography>
          <PPolicy />
        </div>
      </Modal>



      <Container
  component="main"
  maxWidth={activeStep === 1 ? "lg" : "sm"}
  sx={{ mb: 4 }}
>
        <Paper variant="outlined" sx={{ my: { xs: 3, md: 6 }, p: { xs: 2, md: 3 } }}>
          <Typography component="h1" variant="h4" align="center">
            Finish Setting Your Account
          </Typography>
          <Stepper activeStep={activeStep} sx={{ pt: 3, pb: 5 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          {activeStep === steps.length ? (
            <React.Fragment>
              <Typography variant="h5" gutterBottom>
                Thank you for Subscribing.
              </Typography>
              <Typography variant="subtitle1">
                {Name} we have emailed you the subscription
                confirmation, and will send you an updates concerning the Waste Collection Service.
              </Typography>
            </React.Fragment>
          ) : (
            <React.Fragment>
              {getStepContent(activeStep)}
              <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                {activeStep !== 0 && (
                  <Button onClick={handleBack} sx={{ mt: 3, ml: 1 }}>
                    Back
                  </Button>
                )}

                <Button
                  variant="contained"
                  onClick={handleNext}
                  sx={{ mt: 3, ml: 1 }}
                   disabled={activeStep === steps.length - 1 && buttonDisabled }
                >
                  {activeStep === steps.length - 1 ? 'Done' : 'Next'}
                </Button>
              </Box>
            </React.Fragment>
          )}
        </Paper>
        <Copyright />
      </Container>
    </React.Fragment>
  );
}
