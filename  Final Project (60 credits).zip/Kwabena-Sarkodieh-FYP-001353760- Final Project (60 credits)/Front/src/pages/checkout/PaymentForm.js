import * as React from 'react';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { Button } from '@mui/material';

const PaymentForm = ({ onButtonClick }) => {

  const handleButtonClick = () => {
    onButtonClick();
                        };




const sub = JSON.parse(localStorage.getItem('Subscription'));

// Define href based on subscription type
const href = sub == 'professional' 
  ? 'https://buy.stripe.com/test_8wM4iu9Hy3Mi7okeUW' 
  : (sub == 'Standard' || sub == 'Enterprise') 
    ? 'https://buy.stripe.com/test_5kA16i06Y2IedMIdQR' 
    : '';

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Press Button to Make Payment 
      </Typography>
      <Grid item xs={12} sm={6} sx={{ textAlign: 'center' }}>
  <Button sx={{ mt: 3, ml: 1, width: '200px', height: '50px' }} variant="contained"  href={href}  onClick={handleButtonClick}>Pay</Button>
</Grid>


      
    </React.Fragment>
  );
}
export default PaymentForm;