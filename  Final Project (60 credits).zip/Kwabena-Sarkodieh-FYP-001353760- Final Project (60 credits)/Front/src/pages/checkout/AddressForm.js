import React, { useState, useEffect } from 'react';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import MenuItem from '@mui/material/MenuItem';
import axios from 'axios';

export default function AddressForm({ onRegister,onPasswordComplexityChange }) {
  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const [user_full_name, setuser_full_name] = useState("");
  const [email, setemail] = useState("");
  const [phone_number, setphone_number] = useState("");
  const [address, setaddress] = useState("");
  const [Location, setLocation] = useState("");
  const [Long, setLong] = useState("");
  const [Lat, setLat] = useState("");
  const [Desc, setDesc] = useState("");
  const [Schedule, setSchedule] = useState("");
  const [Status, setStatus] = useState("");
  const [Frequency, setFrequency] = useState("");

  useEffect(() => {
    const formData = {
      username: username,
      password: password,
      full_name: user_full_name,
      email: email,
      phone_number:  phone_number,
      address: address,
      Location_Name: Location,
      Longitude: Long,
      Latitude: Lat,
      Description: Desc,
      customer_name: user_full_name,
      Schedule: Schedule,
      Status: 'Active',
      Frequency: '',
      role: 'Customer'
    };
    
    // Store formData in local storage
    localStorage.setItem('formData', JSON.stringify(formData));
  
    // Optionally, you can also call onRegister(formData) here if needed
    // onRegister(formData);
  }, [, username, password,user_full_name, email,  phone_number, address, Location, Desc,Long,Lat, Schedule]);
  

  const fetchCurrentLocation = () => {
    // Logic to fetch current location goes here
    navigator.geolocation.getCurrentPosition((position) => {
      setLat(position.coords.latitude);
      setLong(position.coords.longitude);
    }, (error) => {
      console.error('Error fetching current location:', error);
    });

    fetchAddress();
  };





  const fetchAddress = async () => {
    try {
      const response = await axios.get(
        `http://api.positionstack.com/v1/reverse?access_key=9313ecc646b732dd5200fb4636bb1c6d&query=${Lat},${Long}`
      );

      const { data } = response;
      if (data.data.length > 0) {
        const { label, street } = data.data[0];
        setLocation(label,street );
      
      } else {
        // Handle the case where no location data is found
        console.error('No location data found for the given query.');
      }
    } catch (error) {
      console.error('Error fetching location data:', error);
    }
  };


    // Function to fetch latitude and longitude from Positionstack
    const fetchLatLong = async () => {
      try {
        const response = await axios.get(
          `http://api.positionstack.com/v1/forward?access_key=9313ecc646b732dd5200fb4636bb1c6d&query=${Location}`
        );
  
        const { data } = response;
        if (data.data.length > 0) {
          const { latitude, longitude } = data.data[0];
          setLat(latitude);
          setLong(longitude);
        } else {
          // Handle the case where no location data is found
          console.error('No location data found for the given query.');
        }
      } catch (error) {
        console.error('Error fetching location data:', error);
      }
    };

  const storedFormData = JSON.parse(localStorage.getItem('formData'));


  const storedEmail = localStorage.getItem('begin') || "";

console.log(storedFormData,'text to see')



const [isPasswordComplexEnough, setPasswordComplexEnough] = useState(false);

// Define isPasswordComplex function outside useEffect
function isPasswordComplex(password) {
  // Minimum length requirement
  if (password.length < 8) {
    return false;
  }

  // Regular expressions for checking uppercase letters, lowercase letters, numbers, and special characters
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecialChar = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password);

  // Check if all criteria are met
  return hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar;
}

useEffect(() => {
  // Update parent state based on password complexity
  onPasswordComplexityChange(isPasswordComplex(password));
}, [password, onPasswordComplexityChange]); // Pass onPasswordComplexityChange as a dependency












  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Create Account
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="full_name"
            label="Full name"
            fullWidth
            variant="standard"
            value={user_full_name}
            onChange={(e) => setuser_full_name(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="username"
            label="Username"
            fullWidth
            variant="standard"
            value={username}
            onChange={(e) => setusername(e.target.value)}
          />
        </Grid>
        <Grid item xs={12}>
  <TextField
    required
    id="password"
    label="Password"
    fullWidth
    variant="standard"
    value={password}
    onChange={(e) => setpassword(e.target.value)}
    error={!isPasswordComplex(password)} // Add error prop based on password complexity
    helperText={!isPasswordComplex(password) ? "Password must be at least 8 characters long and contain uppercase letters, lowercase letters, numbers, and special characters." : ""}
  />
</Grid>

        <Grid item xs={12}>
          <TextField
            id="email"
            label="Email"
            fullWidth
            variant="standard"
            value={email || storedEmail}
            onChange={(e) => setemail(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="phone_number"
            label="Phone Number"
            fullWidth
            variant="standard"
            value={phone_number}
            onChange={(e) => setphone_number(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            name="schedule"
            label="Pick Collection Date"
            select
            fullWidth
            variant="standard"
            value={Schedule}
            onChange={(e) => setSchedule(e.target.value)}
          >
            <MenuItem value="Monday">Monday</MenuItem>
            <MenuItem value="Tuesday">Tuesday</MenuItem>
            <MenuItem value="Wednesday">Wednesday</MenuItem>
            <MenuItem value="Thursday">Thursday</MenuItem>
            <MenuItem value="Friday">Friday</MenuItem>
          </TextField>
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            id="address"
            label="Address"
            fullWidth
            variant="standard"
            value={address}
            onChange={(e) => setaddress(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <Stack direction="row" spacing={2}>
            <TextField
            required
              name="Location_Name"
              label="Location"
              value={Location}
              onChange={(e) => {
                setLocation(e.target.value);
                fetchLatLong();
            }}
            
            />
            <Typography>Or</Typography>
            <Button onClick={fetchCurrentLocation} variant="contained">Use Current GPS</Button>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            id="description"
            label="Description"
            fullWidth
            variant="standard"
            value={Desc}
            onChange={(e) => setDesc(e.target.value)}
          />
        </Grid>
     
      </Grid>
    </React.Fragment>
  );
}
