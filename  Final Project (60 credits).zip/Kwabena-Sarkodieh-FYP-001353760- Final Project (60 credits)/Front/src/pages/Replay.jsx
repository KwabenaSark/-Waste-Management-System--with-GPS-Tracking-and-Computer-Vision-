import mapboxgl from 'mapbox-gl';

import 'mapbox-gl/dist/mapbox-gl.css';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
const Replay = () => {
    const [emp, setEmp] = useState([]);
    const [geojson, setGeojson] = useState(null); // Declare geojson in the component state
    useEffect(() => {
   

       
        const fetchCoords = async () => {
            try {

// Retrieving selectedId from local storage
const retrievedId = localStorage.getItem('selectedId');
console.log('Retrieved ID:', retrievedId);

              const res = await axios.get(`http://localhost:8080/Simulate/${retrievedId}`);
              const fetchedUsers = res.data;
              setEmp(fetchedUsers);
     
              // Create GeoJSON dynamically
              const newGeojson = {
                type: 'FeatureCollection',
                features: [
                  {
                    type: 'Feature',
                    properties: {
                        timestamp: fetchedUsers.map(user => user.Timestamp),
                        speed: fetchedUsers.map(user => user.Speed),
                    },
                    geometry: {
                      coordinates: fetchedUsers.map(user => [user.Longitude, user.Latitude]),
                      type: 'LineString',
                    },
                  },
                ],
              };
      
              setGeojson(newGeojson);
              initializeMap(newGeojson); // Pass the newGeojson to initializeMap







              
      
            } catch (err) {
              console.log(err);
            }
          };
      
          const initializeMap = (geojson) => {
            mapboxgl.accessToken = 'pk.eyJ1Ijoia29iYnkxLSIsImEiOiJjbHB2NW5lMmcwMjNqMmhwYm12NWtiZm05In0.Z0IZunMVk_wccwNHMRh7AA';
      
            const map = new mapboxgl.Map({
              container: 'map',
              style: 'mapbox://styles/mapbox/streets-v12',
              center: geojson.features[0].geometry.coordinates.slice(-1)[0],
              zoom: 15.773,
              pitch: 45,
              bearing: -17.6,
            });
      
            map.on('load', () => {
              map.addSource('line', {
                type: 'geojson',
                data: geojson,
              });
      
              map.addLayer({
                type: 'line',
                source: 'line',
                id: 'line-layer',
                paint: {
                  'line-color': 'yellow',
                  'line-width': 12,
                  'line-opacity': 1,
                },
              });

              
 map.addLayer({
    type: 'fill-extrusion',
    id: 'extrusion',
    source: 'line',
    paint: {
        'fill-extrusion-color': 'yellow',
        'fill-extrusion-height': 0, // starting height
        'fill-extrusion-base': 0, // starting from 0
        'fill-extrusion-opacity': 0.6
    }
});
        // Line dash array animation
        const dashArraySequence = [
    [0, 4, 3],
    [0.5, 4, 2.5],
    [1, 4, 2],
    [1.5, 4, 1.5],
    [2, 4, 1],
    [2.5, 4, 0.5],
    [3, 4, 0],
    [0, 0.5, 3, 3.5],
    [0, 1, 3, 3],
    [0, 1.5, 3, 2.5],
    [0, 2, 3, 2],
    [0, 2.5, 3, 1.5],
    [0, 3, 3, 1],
    [0, 3.5, 3, 0.5]
    
            
        ];

        let dashStep = 0;
        let dashStartTime;
        
        function animateDashArray(timestamp) {
            if (!dashStartTime) dashStartTime = timestamp;
        
            const progress = timestamp - dashStartTime;
            const speed = 0.1; // adjust as needed
        
            const newStep = parseInt((progress / 50) % dashArraySequence.length);
        
            if (newStep !== dashStep) {
                map.setPaintProperty(
                    'line-layer',
                    'line-dasharray',
                    dashArraySequence[dashStep]
                );
                dashStep = newStep;
            }
        
            if (progress < 5000) {
                requestAnimationFrame(animateDashArray);
            } else {
                // Reset the animation after completion
                dashStartTime = null;
                dashStep = 0;
                animateDashArray(0);
            }
        }
      
        

        const [lng, lat] = geojson.features[0].geometry.coordinates[0];
        console.log(lng , lat, 'checking')
       // Extract the initial marker coordinates from the first feature of the GeoJSON


       const marker = new mapboxgl.Marker({
        color: 'red',
    });
    
    // Set the initial marker position and add it to the map
    marker.setLngLat([lng, lat]).addTo(map);
    
    let coordinateIndex = 0;
    const animationDelay = 100; // Adjust this value to control the speed (in milliseconds)
    
    function animateMarker() {
        if (geojson && geojson.features && geojson.features.length > 0) {
          const [newLng, newLat] = geojson.features[0].geometry.coordinates[coordinateIndex % geojson.features[0].geometry.coordinates.length];
          const timestamp = geojson.features[0].properties.timestamp[coordinateIndex % geojson.features[0].properties.timestamp.length];
          const speed = geojson.features[0].properties.speed[coordinateIndex % geojson.features[0].properties.speed.length];
      
          console.log('Timestamp:', timestamp, 'Speed:', speed);

          localStorage.setItem('timestamp', timestamp);
          localStorage.setItem('speed', speed);
          
      
          marker.setLngLat([newLng, newLat]).addTo(map);
          coordinateIndex = (coordinateIndex + 1) % geojson.features[0].geometry.coordinates.length;
      
          setTimeout(animateMarker, animationDelay);
        } else {
          console.error('Invalid geojson:', geojson);
        }
      }
      
    
    // Start the animation
    animateMarker();
    
  
        
        
        
        
        // Trigger both animations
        animateDashArray(0);
        animateMarker(0);
        
    });

};
    fetchCoords();
   
  }, []);

  

    return (
        <div id="map" style={{ width: '100%', height: '80vh' }}  />
    );
};

export default Replay;