import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import React, { useEffect, useState } from 'react'
import { useNavigate , Link} from 'react-router-dom';
import axios from 'axios'
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
  Grid
} from '@mui/material';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
// mock
//import USERLIST from '../_mock/user';
import { styled } from '@mui/material/styles';
// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'name', label: 'Cost', alignRight: false },
  { id: 'company', label: 'DateTime', alignRight: false },
  { id: 'role', label: 'Vehicle', alignRight: false },
  { id: 'isVerified', label: 'Username', alignRight: false },
  { id: 'status', label: 'Note', alignRight: false },
  { id: 'photo', label: 'Photo', alignRight: false },
  { id: '' },
];

// ----------------------------------------------------------------------

const StyledPaper = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  maxWidth: 800,
  color: theme.palette.text.primary,
}));

export default function FuelLogPage() {
  const [open, setOpen] = useState(null);

  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [selected, setSelected] = useState([]);

  const [orderBy, setOrderBy] = useState('name');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(5);
  
  const [filteredUsers, setFilteredUsers] = useState([]);

  const [role, setRole] = useState([]);

 // Assuming this is within an asynchronous function or using async/await

 const storedUserData = localStorage.getItem('userData');




//getiing user name from the things
if (storedUserData) {
  const userData = JSON.parse(storedUserData);
  
  const username = userData.username;
  const id = userData.id;

  console.log('Username:', username);
  console.log('ID:', id);
} else {
  console.log('No user data found in localStorage');
}
// Fetch users
const [users, setUsers] = useState([]);


//for second
const [users2, setUsers2] = useState([]);
const [filteredUsers2, setFilteredUsers2] = useState([]);
const [filterName2, setFilterName2] = useState('');

useEffect(() => {
  const fetchAllUsers = async () => {
    try {
      const res = await axios.get('http://localhost:8080/Fuel');
      const fetchedUsers = res.data;

      // Initialize both users and filteredUsers with the data
      setUsers(fetchedUsers);
      setFilteredUsers(fetchedUsers);
    } catch (err) {
      console.log(err);
    }
  };


  const fetchSecondUsers = async () => {
    try {
      const displayID = localStorage.getItem('displayID');
      const res = await axios.get(`http://localhost:8080/FuelSecond/${displayID}`);
      const fetchedUsers = res.data;

      // Initialize both users and filteredUsers with the data
      setUsers2(fetchedUsers);
      setFilteredUsers2(fetchedUsers);
    } catch (err) {
      console.log(err);
    }
  };

console.log(filteredUsers2, 'f2')

  const checkUserRole = async () => {
    try {
      const displayID = localStorage.getItem('displayID');
      const response = await axios.post(`http://localhost:8080/check_role/${displayID}`);
      const result = response.data.status || response.data.error;

      // Handle the result as needed, e.g., update state or perform other actions
      console.log(result);
      setRole(result);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Call both functions within useEffect
  fetchAllUsers();
  checkUserRole();
  fetchSecondUsers();
}, []);




console.log(role,'tell me')




function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}


function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });

  if (query) {
    // Use the appropriate property for filtering (e.g., _user.username)
    return filter(array, (_user) => _user.username.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }

  return stabilizedThis.map((el) => el[0]);
}





  const handleOpenMenu = (event, userId) => {
    setSelected([userId]); // Set the selected user ID
    setOpen(event.currentTarget);
  };
  

  const handleCloseMenu = () => {
    setOpen(null);
  };

const handleRequestSort = (event, property) => {
  const isAsc = orderBy === property && order === 'asc';
  setOrder(isAsc ? 'desc' : 'asc');
  setOrderBy(property);

  // Sort the filteredUsers array based on the selected property and order
  const sortedUsers = stableSort(filteredUsers, getComparator(order, property));

  // Update the filteredUsers state with the sorted array
  setFilteredUsers(sortedUsers);
};

  



  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      // If all users are currently selected, unselect all
      const allSelected = selected.length === users.length;
      const newSelecteds = allSelected ? [] : users.map((user) => user.fuel_log_id);
      setSelected(newSelecteds);
    } else {
      // If unchecking the checkbox, unselect all
      setSelected([]);
    }
  };
  const handleSelectAllClick2 = (event) => {
    if (event.target.checked) {
      // If all users are currently selected, unselect all
      const allSelected = selected.length === users2.length;
      const newSelecteds = allSelected ? [] : users2.map((user) => user.fuel_log_id);
      setSelected(newSelecteds);
    } else {
      // If unchecking the checkbox, unselect all
      setSelected([]);
    }
  };
  

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

 

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setPage(0);
    setRowsPerPage(parseInt(event.target.value, 10));
  };

  const handleFilterByName = (event) => {
    const value = event.target.value.toLowerCase();
  
    // Update the filterName state
    setFilterName(value);
  
    // If the search box is empty, show all users
    const newFilteredUsers = value
      ? users.filter((user) => user?.username?.toLowerCase().includes(value))
      : users; // Show all users when the search box is empty
  
    // Update the filteredUsers state
    setFilteredUsers(newFilteredUsers);
  };
  
  const handleFilterByName2 = (event) => {
    const value = event.target.value.toLowerCase();
  
    // Update the filterName state
    setFilterName2(value);
  
    // If the search box is empty, show all users
    const newFilteredUsers = value
      ? users2.filter((user) => user?.date?.toLowerCase().includes(value))
      : users2; // Show all users when the search box is empty
  
    // Update the filteredUsers state
    setFilteredUsers2(newFilteredUsers);
  };
  
  
  // Retrieve user role from local storage
const storedUserRole = localStorage.getItem('userRole');


  //fpr the update route
  const handleEdit = () => {
    console.log(selected); // Check the values in the console
    // Redirect to the '/update' page with the first selected user ID
    navigate(`/dashboard/UpdateFuel/${selected[0]}`);
  
    const displayID = localStorage.getItem('displayID');
    const number = 1;
    
    axios.post('http://localhost:8080/ErrorT', { displayID, number })
      .then(response => {
        // console.log('Data inserted successfully');
        // Handle success
      })
      .catch(error => {
        // console.error('Error inserting data:', error);
        // Handle error
      });
  };
  
  


  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - users.length) : 0;

  //const filteredUsers = applySortFilter(users, getComparator(order, orderBy), filterName);


  const isNotFound = !filteredUsers.length && !!filterName;
  const navigate = useNavigate();

  //route
  const Adduser = () => {
  navigate('/dashboard/FuelAdd');
  };

 

//




    //delete
    const handleDelete = async () => {
      try {
        await Promise.all(
          selected.map(async (id) => {
            // Delete user based on the username
            await axios.delete(`http://localhost:8080/Fuel/${id}`);
          })
        );
    
        setSelected([]);
        window.location.href ='/dashboard/FuelLog';
    
      } catch (err) {
        console.error(err);
      }
    };
    
    
    
    console.log(selected)
    

    //delete 2
    const handleDeletee = async (selectedUserIds) => {
      try {
        await Promise.all(
          selectedUserIds.map(async (id) => {
            // Delete user based on the user ID
            await axios.delete(`http://localhost:8080/Fuel/${id}`);
          })
        );
    
        setSelected([]);
       
        window.location.href ='/dashboard/FuelLog';
      
      } catch (err) {
        console.error(err);
      }
    };
    


     //Update
     const handleUpdate = async (id)=>{
        try{
           await axios.put("http://localhost:8080/users/" + id)
            window.location.reload()
        }catch(err){
            console.log(err)
        }
    }

console.log(selected);



const [anchorEl, setAnchorEl] = useState(null);
const [popshw, setPopshw] = useState([]);
  
const handleClickP = async (event, userId) => {
  setAnchorEl(event.currentTarget);
  setSelected([userId]);


  const Popover = async () => {
  try {
    const res = await axios.get(`http://localhost:8080/Fuelpop/${userId}`);
    const fetchedUsers = res.data;
    console.log(fetchedUsers, 'trying book')
    setPopshw(fetchedUsers);
  } catch (err) {
    console.log(err ,'dont get');
  }

};

 Popover();
};

const handleClose = () => {
  setAnchorEl(null);
};

const openP = Boolean(anchorEl);
const id = openP ? 'simple-popover' : undefined;

// console.log(popshw.note , 'test photo');


  return (
    <>
      <Helmet>
        <title> User | Minimal UI </title>
      </Helmet>

      <div>
      {role === 'allow' ? ( 
  <Container>
      <Container>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>
            Fuel Logs
          </Typography>
          <Button variant="contained" startIcon={<Iconify icon="eva:plus-fill" />} onClick={Adduser}>
            New Fuel Log
          </Button>
        </Stack>
       

        <Card>

          
          <UserListToolbar numSelected={selected.length} filterName={filterName} onFilterName={handleFilterByName} onDelete={handleDelete} />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={filteredUsers.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
        {filteredUsers.map((user) => (
          <TableRow hover key={user.fuel_log_id} tabIndex={-1} role="checkbox">
            <TableCell padding="checkbox">
              <Checkbox checked={selected.indexOf(user.fuel_log_id) !== -1} onChange={(event) => handleClick(event, user.fuel_log_id)} />
            </TableCell>

            

      <TableCell align="left"> <Label color='success' >{user.cost}</Label></TableCell>

      <TableCell align="left">{new Date(user.date).toLocaleString()}</TableCell>


      <TableCell align="left">{user.vehicle}</TableCell>

      <TableCell align="left">
      
     {user.username}

      </TableCell>
      <TableCell align="left">{user.note}</TableCell>
     

      <TableCell align="left" onClick={(event) => handleClickP(event, user.fuel_log_id)}>
        {<Avatar alt={user.note}  src={`${user.Photo}`} />}
      </TableCell>
      
            < Popover
  id={id}
  open={openP}
  anchorEl={anchorEl}
  onClose={handleClose}
  anchorOrigin={{
    vertical: 'bottom',
    horizontal: 'center',
  }}
  transformOrigin={{
    vertical: 'top',
    horizontal: 'center',
  }}
>
  {/* Content inside the popover */}
  <div>
    <img
     
      src={`${popshw.photo}`}
      alt={popshw.note}
      style={{ maxWidth: '100%' }}
    />
  </div>
  <StyledPaper
        sx={{
          my: 1,
          mx: 'auto',
          p: 2,
        }}
      >
  <Grid container  wrap="nowrap"spacing={1}>
      <Grid item xs={12} sm={6} >
        <Typography variant='h6'>Description:</Typography>
        <Typography>{popshw.note}</Typography>
      </Grid>
      <Grid item xs={12} sm={6}>
        <Typography variant='h6'>User:</Typography>
        <Typography>{popshw.cost}</Typography>
      </Grid>
      <Grid item xs={12} sm={6}>
        <Typography variant='h6'>Timestamp:</Typography>
        <Typography>{new Date(popshw.date).toLocaleString()}</Typography>
      </Grid>
      <Grid item xs={12} sm={6}>
        <Typography variant='h6'>Assigned Vehicle:</Typography>
        <Typography>{popshw.vehicle}</Typography>
      </Grid>
    </Grid>
    </StyledPaper>
</Popover>
      <TableCell align="right">
      <IconButton
  size="large"
  color="inherit"
  onClick={(event) => handleOpenMenu(event, user.fuel_log_id)}
>
  <Iconify icon={'eva:more-vertical-fill'} />
</IconButton>

      </TableCell>
    </TableRow>



  ))}
</TableBody>


                {isNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <Paper
                          sx={{
                            textAlign: 'center',
                          }}
                        >
                          <Typography variant="h6" paragraph>
                            Not found
                          </Typography>

                          <Typography variant="body2">
                            No results found for &nbsp;
                            <strong>&quot;{filterName}&quot;</strong>.
                            <br /> Try checking for typos or using complete words.
                          </Typography>
                        </Paper>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
  rowsPerPageOptions={[5, 10, users.length]}  // Add the total number of rows as an option
  component="div"
  count={users.length}
  rowsPerPage={rowsPerPage}
  page={page}
  onPageChange={handleChangePage}
  onRowsPerPageChange={handleChangeRowsPerPage}
/>

        </Card>
      </Container>

      <Popover
  open={Boolean(open)}
  anchorEl={open}
  onClose={handleCloseMenu}
  anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
  transformOrigin={{ vertical: 'top', horizontal: 'right' }}
  PaperProps={{
    sx: {
      p: 1,
      width: 140,
      '& .MuiMenuItem-root': {
        px: 1,
        typography: 'body2',
        borderRadius: 0.75,
      },
    },
  }}
>
  

  {storedUserRole !== 'Clerk' && (
  <MenuItem onClick={() => handleEdit(selected)}>
    <Iconify icon={'eva:edit-fill'} sx={{ mr: 2 }} />
    Edit
  </MenuItem>
)}


  {storedUserRole !== 'Clerk' && (
  <MenuItem sx={{ color: 'error.main' }} onClick={() => handleDeletee(selected)}>
    <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
    Delete
  </MenuItem>
)}
</Popover>
</Container>
  ) : (
<Container>

{/* Second User Section */}

<Container>
      <Container>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>
            Fuel Logs
          </Typography>
          <Button variant="contained" startIcon={<Iconify icon="eva:plus-fill" />} onClick={Adduser}>
            New Fuel Log
          </Button>
        </Stack>
       

        <Card>

          
          <UserListToolbar numSelected={selected.length} filterName={filterName2} onFilterName={handleFilterByName2} onDelete={handleDelete} placeholder="Search date..." />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={filteredUsers2.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick2}
                  placeholder="Search date..."
                />
                <TableBody>
        {filteredUsers2.map((user) => (
          <TableRow hover key={user.fuel_log_id} tabIndex={-1} role="checkbox">
            <TableCell padding="checkbox">
              <Checkbox checked={selected.indexOf(user.fuel_log_id) !== -1} onChange={(event) => handleClick(event, user.fuel_log_id)} />
            </TableCell>

         

      <TableCell align="left"> <Label color='success' >{user.cost}</Label></TableCell>

      <TableCell align="left">{new Date(user.date).toLocaleString()}</TableCell>


      <TableCell align="left">{user.vehicle}</TableCell>

      <TableCell align="left">
      
     {user.username}

      </TableCell>
      <TableCell align="left">{user.note}</TableCell>
     
      <TableCell align="left"> {<Avatar alt={user.note}  src={`data:image/jpeg;base64,${user.Photo}`} onClick={(event) => handleClickP(event, user.fuel_log_id)} />}</TableCell>

      <TableCell align="right">
      <IconButton
  size="large"
  color="inherit"
  onClick={(event) => handleOpenMenu(event, user.fuel_log_id)}
>
  <Iconify icon={'eva:more-vertical-fill'} />
</IconButton>

      </TableCell>
    </TableRow>



  ))}
</TableBody>


                {isNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <Paper
                          sx={{
                            textAlign: 'center',
                          }}
                        >
                          <Typography variant="h6" paragraph>
                            Not found
                          </Typography>

                          <Typography variant="body2">
                            No results found for &nbsp;
                            <strong>&quot;{filterName}&quot;</strong>.
                            <br /> Try checking for typos or using complete words.
                          </Typography>
                        </Paper>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
  rowsPerPageOptions={[1, users2.length]}  // Add the total number of rows as an option
  component="div"
  count={users2.length}
  rowsPerPage={rowsPerPage}
  page={page}
  onPageChange={handleChangePage}
  onRowsPerPageChange={handleChangeRowsPerPage}
/>

        </Card>
      </Container>

      <Popover
  open={Boolean(open)}
  anchorEl={open}
  onClose={handleCloseMenu}
  anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
  transformOrigin={{ vertical: 'top', horizontal: 'right' }}
  PaperProps={{
    sx: {
      p: 1,
      width: 140,
      '& .MuiMenuItem-root': {
        px: 1,
        typography: 'body2',
        borderRadius: 0.75,
      },
    },
  }}
>

  <MenuItem sx={{ color: 'error.main' }} onClick={() => handleDeletee(selected)}>
    <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
    Delete
  </MenuItem>
</Popover>
</Container>







 
</Container>
   )}
   </div>















    </>
  );
}
