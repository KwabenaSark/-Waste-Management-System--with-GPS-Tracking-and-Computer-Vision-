import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import React, { useEffect, useState } from 'react'
import { useNavigate , Link} from 'react-router-dom';
import axios from 'axios'
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
  ButtonGroup,
  Box,
  Tab, 

} from '@mui/material';


import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
import Maps from './Maps';

// mock
//import USERLIST from '../_mock/user';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'name', label: 'Location', alignRight: false },
  { id: 'role', label: 'Address Description', alignRight: false },
  { id: 'isVerified', label: 'Customer', alignRight: false },
  { id: 'status', label: 'Schedule', alignRight: false },
  { id: 'full_name', label: 'Frequency', alignRight: false },
  { id: 'markoff', label: '', alignRight: false },
  { id: '' },
];

// ----------------------------------------------------------------------



export default function LocationList() {


//cureent date
function getCurrentWeekday() {
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const currentDate = new Date();
    const currentDayIndex = currentDate.getDay();
  
    if (currentDayIndex >= 1 && currentDayIndex <= 5) {
      return daysOfWeek[currentDayIndex];
    } else {
      return "It's the weekend!";
    }
  }
  
  // Example usage
  const currentWeekday = getCurrentWeekday();
  console.log(`Today is ${currentWeekday}`);
  









    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };


  const [open, setOpen] = useState(null);

  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [selected, setSelected] = useState([]);


  const [orderBy, setOrderBy] = useState('name');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(5);
  
  
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [role, setRole] = useState([]);

// Fetch users
const [users, setUsers] = useState([]);
useEffect(() => {
  const fetchAllUsers = async () => {
    try {
      const res = await axios.get('http://localhost:8080/Locations');
      const fetchedUsers = res.data;

      // Initialize both users and filteredUsers with the data
      setUsers(fetchedUsers);
      setFilteredUsers(fetchedUsers);
    } catch (err) {
      console.log(err);
    }
  };


  const checkUserRole = async () => {
    try {
      const displayID = localStorage.getItem('displayID');
      const response = await axios.post(`http://localhost:8080/check_role/${displayID}`);
      const result = response.data.status || response.data.error;

      // Handle the result as needed, e.g., update state or perform other actions
      console.log(result, 'tell me');
      setRole(result);
    } catch (error) {
      console.error('Error:', error);
    }
  };
 
  checkUserRole();
  fetchAllUsers();
}, []);




useEffect(() => {
    // Set the default filter when the component mounts or when role changes
    const defaultDay = role === 'dont allow' ? getCurrentWeekday().toLowerCase() : '';
    setFilterName(defaultDay);

    // Filter users based on the default day
    const newFilteredUsers = defaultDay
      ? users.filter((user) => user?.Schedule?.toLowerCase() === defaultDay)
      : users;

    // Update the filteredUsers state
    setFilteredUsers(newFilteredUsers);
  }, [role]);

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}


function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });

  if (query) {
    // Use the appropriate property for filtering (e.g., _user.username)
    return filter(array, (_user) => _user.username.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }

  return stabilizedThis.map((el) => el[0]);
}





  const handleOpenMenu = (event, userId) => {
    setSelected([userId]); // Set the selected user ID
    setOpen(event.currentTarget);
  };
  

  const handleCloseMenu = () => {
    setOpen(null);
  };

const handleRequestSort = (event, property) => {
  const isAsc = orderBy === property && order === 'asc';
  setOrder(isAsc ? 'desc' : 'asc');
  setOrderBy(property);

  // Sort the filteredUsers array based on the selected property and order
  const sortedUsers = stableSort(filteredUsers, getComparator(order, property));

  // Update the filteredUsers state with the sorted array
  setFilteredUsers(sortedUsers);
};

  



  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      // If all users are currently selected, unselect all
      const allSelected = selected.length === users.length;
      const newSelecteds = allSelected ? [] : users.map((user) => user.id);
      setSelected(newSelecteds);
    } else {
      // If unchecking the checkbox, unselect all
      setSelected([]);
    }
  };
  

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setPage(0);
    setRowsPerPage(parseInt(event.target.value, 10));
  };
 const handleFilterByName = (event) => {
    const value = event.target.value.toLowerCase();
    
    // Set the default value to the current day when role is 'dont allow'
    const defaultValue = role === 'dont allow' ? getCurrentWeekday().toLowerCase() : '';
    setFilterName(value || defaultValue);

    const newFilteredUsers = value
      ? users.filter((user) => user?.Schedule?.toLowerCase().includes(value))
      : users.filter((user) => user?.Schedule?.toLowerCase() === defaultValue);

    setFilteredUsers(newFilteredUsers);
  };


  const handleDayButtonClick = (day) => {
    // Update the filterName state with the selected day
    setFilterName(day.toLowerCase());

    // Filter users based on the selected day
    const newFilteredUsers = day
      ? users.filter((user) => user?.Schedule?.toLowerCase() === day.toLowerCase())
      : users;

    // Update the filteredUsers state
    setFilteredUsers(newFilteredUsers);
  };
  
  
  
  
  


  //fpr the update route
  const handleEdit = () => {
    console.log(selected); // Check the values in the console
    // Redirect to the '/update' page with the first selected user ID
    navigate(`/dashboard/LocationUpdate/${selected[0]}`);
   

  };


  const markoff = (userId) => {
    console.log(selected); // Check the values in the console
    // Toggle the checkbox
    handleClick(userId);

    // Wait for 0.5 seconds before navigating
    
      navigate(`/dashboard/CollectionAdd/${userId}`);
   
  };
  
  


  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - users.length) : 0;

  //const filteredUsers = applySortFilter(users, getComparator(order, orderBy), filterName);


  const isNotFound = !filteredUsers.length && !!filterName;
  const navigate = useNavigate();

  //route
  const Adduser = () => {
  // navigate('/dashboard/LocationAdd');
  };

 

//




    //delete
    const handleDelete = async () => {
      try {
        await Promise.all(
          selected.map(async (id) => {
            // Delete user based on the username
            await axios.delete(`http://localhost:8080/LocationD/${id}`);
          })
        );
    
        setSelected([]);
        window.location.href ='/dashboard/Location';
    
      } catch (err) {
        console.error(err);
      }
    };
    
    
    
    console.log(selected)
    

    //delete 2
    const handleDeletee = async (selectedUserIds) => {
      try {
        await Promise.all(
          selectedUserIds.map(async (id) => {
            // Delete user based on the user ID
            await axios.delete(`http://localhost:8080/LocationD/${id}`);
          })
        );
    
        setSelected([]);
       
        window.location.href ='/dashboard/Location';
      
      } catch (err) {
        console.error(err);
      }
    };
    


     //Update
     const handleUpdate = async (id)=>{
        try{
           await axios.put("http://localhost:8080/users/" + id)
            window.location.reload()
        }catch(err){
            console.log(err)
        }
    }









console.log(selected);




//showing time
const [updatesett, setUpdatesett] = useState({
  start_time:'',
  end_time: '',
});

const [isVisible, setIsVisible] = useState(false);
useEffect(() => {
  const fetchSettingsData = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/Settings`);
      const settData = response.data[0];
      setUpdatesett(settData);
    } catch (err) {
      console.log(err);
    }
  };

  fetchSettingsData();




}, []); // Empty dependency array to execute only once on mount




useEffect(() => {
  const { start_time, end_time } = updatesett;
  const currentTime = new Date();
  const currentHours = currentTime.getHours();
  const currentMinutes = currentTime.getMinutes();
  const currentSeconds = currentTime.getSeconds();
  const currentTimeString = `${currentHours}:${currentMinutes}:${currentSeconds}`;
 

  const startTimeParts = start_time.split(':');
  const endTimeParts = end_time.split(':');
  
  const startTimeString = `${startTimeParts[0]}:${startTimeParts[1]}:${startTimeParts[2]}`;
  const endTimeString = `${endTimeParts[0]}:${endTimeParts[1]}:${endTimeParts[2]}`;
  console.log(currentTimeString,startTimeString,'time')
  if (currentTimeString >= startTimeString && currentTimeString <= endTimeString) {
    setIsVisible(true);
  } else {
    setIsVisible(false);
  }
}, [updatesett]);





  return (
    <>
      <Helmet>
        <title> User | Minimal UI </title>
      </Helmet>

      <Container>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>
            Locations
          </Typography>
          {/* <Button variant="contained" startIcon={<Iconify icon="eva:plus-fill" />} onClick={Adduser}>
            New Location
          </Button> */}
        </Stack>
      

       
           
      

       
        {isVisible && (
        <Card>

          
          <UserListToolbar numSelected={selected.length} filterName={filterName} onFilterName={handleFilterByName} onDelete={handleDelete} />
         {role === 'dont allow' && (
        <ButtonGroup variant="contained" spacing={2} style={{ display: 'none' }}>
          {/* Hide the button group */}
          {/* ... (buttons) */}
        </ButtonGroup>
      )}

      {role !== 'dont allow' && (
        <ButtonGroup variant="contained" spacing={2} style={{ display: 'flex', justifyContent: 'left' }}>
          <Button style={{ margin: '5px', borderRadius: '10px' }} onClick={() => handleDayButtonClick('')}>All</Button>
          <Button style={{ margin: '5px', borderRadius: '10px' }} variant="contained" color="success" onClick={() => handleDayButtonClick('Monday')}>Monday</Button>
          <Button style={{ margin: '5px', borderRadius: '10px' }} onClick={() => handleDayButtonClick('Tuesday')}>Tuesday</Button>
          <Button style={{ margin: '5px', borderRadius: '10px' }} onClick={() => handleDayButtonClick('Wednesday')}>Wednesday</Button>
          <Button style={{ margin: '5px', borderRadius: '10px' }} onClick={() => handleDayButtonClick('Thursday')}>Thursday</Button>
          <Button style={{ margin: '5px', borderRadius: '10px' }} onClick={() => handleDayButtonClick('Friday')}>Friday</Button>
        </ButtonGroup>
      )}
      <br />
          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={filteredUsers.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
        {filteredUsers.map((user) => (
          <TableRow hover key={user.id} tabIndex={-1} role="checkbox">
            <TableCell padding="checkbox">
              <Checkbox checked={selected.indexOf(user.id) !== -1} onChange={(event) => handleClick(event, user.id)} />
            </TableCell>

           
      <TableCell align="left">{user.Location_Name}</TableCell>

      <TableCell align="left">{user.Description}</TableCell>

      <TableCell align="left">{user.Customer_Name}</TableCell>

      <TableCell align="left">
      
      <Label color={user.status === 'Yes' ? 'success' : 'error'}>{user.Schedule}</Label>

      </TableCell>

      <TableCell align="left">{user.Frequency}</TableCell>

      <TableCell align="left">

      <Button
            variant="contained"
            onClick={() => {
              handleClick(user.id);
              markoff(user.id);
            }}
            disabled={user.Status !== 'Active'}
          >
            MarkOff
          </Button>

      </TableCell>
 



      <TableCell align="right">
      <IconButton
  size="large"
  color="inherit"
  onClick={(event) => handleOpenMenu(event, user.id)}
>
  <Iconify icon={'eva:more-vertical-fill'} />
</IconButton>

      </TableCell>
    </TableRow>



  ))}


</TableBody>





                {isNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <Paper
                          sx={{
                            textAlign: 'center',
                          }}
                        >
                          <Typography variant="h6" paragraph>
                            Not found
                          </Typography>

                          <Typography variant="body2">
                            No results found for &nbsp;
                            <strong>&quot;{filterName}&quot;</strong>.
                            <br /> Try checking for typos or using complete words.
                          </Typography>
                        </Paper>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
  rowsPerPageOptions={[5, 10, users.length]}  // Add the total number of rows as an option
  component="div"
  count={users.length}
  rowsPerPage={rowsPerPage}
  page={page}
  onPageChange={handleChangePage}
  onRowsPerPageChange={handleChangeRowsPerPage}
/>

        </Card>
         )}
      </Container>

      <Popover
  open={Boolean(open)}
  anchorEl={open}
  onClose={handleCloseMenu}
  anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
  transformOrigin={{ vertical: 'top', horizontal: 'right' }}
  PaperProps={{
    sx: {
      p: 1,
      width: 140,
      '& .MuiMenuItem-root': {
        px: 1,
        typography: 'body2',
        borderRadius: 0.75,
      },
    },
  }}
>
  <MenuItem onClick={() => handleEdit(selected)}>
    <Iconify icon={'eva:edit-fill'} sx={{ mr: 2 }} />
    Edit
  </MenuItem>
  <MenuItem sx={{ color: 'error.main' }} onClick={() => handleDeletee(selected)}>
    <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
    Delete
  </MenuItem>
</Popover>
    </>
  );
}
