import React, { useState, useEffect, useRef } from 'react';
import * as mobilenet from '@tensorflow-models/mobilenet';
import '@tensorflow/tfjs';
import { Button, CircularProgress, Grid, Typography, Box } from '@mui/material';
import { LinearProgress } from '@mui/material';
import wasteKeywords from './wasteKeywords.json';

const AI_Camera = () => {
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [model, setModel] = useState(null);
  const [imageURL, setImageURL] = useState(null);
  const [results, setResults] = useState({ classifications: [], wasteType: '' });
  const [history, setHistory] = useState([]);
  const [cameraStarted, setCameraStarted] = useState(false);

  const videoRef = useRef();
  const imageRef = useRef();
  const fileInputRef = useRef(null);

  const loadModel = async () => {
    setIsModelLoading(true);
    try {
      const loadedModel = await mobilenet.load();
      setModel(loadedModel);
      setIsModelLoading(false);
    } catch (error) {
      console.error(error);
      setIsModelLoading(false);
    }
  };

  const uploadImage = (e) => {
    const { files } = e.target;
    if (files.length > 0) {
      const url = URL.createObjectURL(files[0]);
      setImageURL(url);
      setTimeout(() => identify(), 1000);
    }
  };

  const startCamera = () => {
    const constraints = { video: true };
    navigator.mediaDevices.getUserMedia(constraints)
      .then((stream) => {
        videoRef.current.srcObject = stream;
        setCameraStarted(true);
      })
      .catch((error) => {
        console.error('Error starting camera:', error);
      });
  };

  const stopCamera = () => {
    const stream = videoRef.current.srcObject;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setCameraStarted(false);
    }
  };

  const captureImage = () => {
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    canvas.getContext('2d').drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const imageUrl = canvas.toDataURL('image/png');
    setImageURL(imageUrl);
    stopCamera();
    setTimeout(() => identify(), 1000);
  };

  const identify = async () => {
    const classifications = await model.classify(imageRef.current);
    const wasteType = determineWasteType(classifications);
    setResults({ classifications, wasteType });
  };

  const determineWasteType = (classifications) => {
    const recyclableKeywords = wasteKeywords.recyclableKeywords;
    const hazardousKeywords = wasteKeywords.hazardousKeywords;
    const electronicKeywords = wasteKeywords.electronicKeywords;
    
    
    let recyclableCount = 0;
    let hazardousCount = 0;
    let electronicCount = 0;
    
    for (const classification of classifications) {
        const className = classification.className.toLowerCase();
        if (recyclableKeywords.some(keyword => className.includes(keyword))) {
            recyclableCount++;
        }
        if (hazardousKeywords.some(keyword => className.includes(keyword))) {
            hazardousCount++;
        }
        if (electronicKeywords.some(keyword => className.includes(keyword))) {
            electronicCount++;
        }
    }
    
    if (recyclableCount > hazardousCount && recyclableCount > electronicCount) {
        return 'Recyclable Waste';
    } else if (hazardousCount > recyclableCount && hazardousCount > electronicCount) {
        return 'Hazardous Waste';
    } else if (electronicCount > recyclableCount && electronicCount > hazardousCount) {
        return 'Electronic Waste';
    } else {
        return 'General Waste';
    }
};

  useEffect(() => {
    loadModel();
  }, []);

  useEffect(() => {
    if (imageURL) {
      setHistory([imageURL, ...history]);
    }
  }, [imageURL]);

  if (isModelLoading) {
    return (
      <div style={{ textAlign: 'center', padding: '20px' }}>
        <CircularProgress />
      </div>
    );
  }

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <Typography variant="h1" className='header'>AI Camera</Typography>
      <Box className='inputHolder'>
        <Grid container spacing={2} justifyContent="center">
          <Grid item>
            {!cameraStarted && (
              <Button variant="contained" color="primary" onClick={() => fileInputRef.current.click()}>Upload Image</Button>
            )}
            <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={uploadImage} />
          </Grid>
          <Grid item>
            {!cameraStarted && <Button variant="contained" color="primary" onClick={startCamera}>Start Camera</Button>}
          </Grid>
          <Grid item>
            {cameraStarted && <Button variant="contained" color="primary" onClick={captureImage}>Capture Image</Button>}
          </Grid>
        </Grid>
      </Box>

      <Grid container justifyContent="center" style={{ marginTop: '20px' }}>
        <Grid item xs={12} md={6}>
          <div className="mainWrapper" style={{ position: 'relative' }}>
            <div className="mainContent">
              <div className="imageHolder">
                <video ref={videoRef} autoPlay playsInline muted style={{ maxWidth: '100%' }} />
                {imageURL && <img src={imageURL} alt="Upload Preview" crossOrigin="anonymous" ref={imageRef} style={{ display: 'none' }} />}
              </div>
              {results.classifications.length > 0 && <div className='resultsHolder' style={{ position: 'absolute', top: '0', left: '0', right: '0', backgroundColor: 'rgba(255,255,255,0.8)', padding: '10px' }}>
                {results.classifications.map((result, index) => (
                  <div className='result' key={result.className}>
                    <Typography variant="body1" className='name'>Result: {result.className}</Typography>
                    <Typography variant="body2"> Waste Type:<b> {results.wasteType}</b></Typography>
                    <div className='confidence'>
                      <Typography variant="body2">Confidence level: </Typography>
                      <LinearProgress variant="determinate" value={result.probability * 100} />
                      <Typography variant="body2">{(result.probability * 100).toFixed(2)}%</Typography>
                    </div>
                  </div>
                ))}
              </div>}
            </div>
          </div>
        </Grid>
      </Grid>
      {history.length > 0 && <div style={{ marginTop: '20px' }}>
        <Typography variant="h2">Recent Images</Typography>
        <Grid container spacing={2}>
          {history.map((image, index) => {
            return (
              <Grid item key={`${image}${index}`}>
                <img src={image} alt='Recent Prediction' onClick={() => setImageURL(image)} style={{ cursor: 'pointer' }} />
              </Grid>
            )
          })}
        </Grid>
      </div>}
    </div>
  );
};

export default AI_Camera;
