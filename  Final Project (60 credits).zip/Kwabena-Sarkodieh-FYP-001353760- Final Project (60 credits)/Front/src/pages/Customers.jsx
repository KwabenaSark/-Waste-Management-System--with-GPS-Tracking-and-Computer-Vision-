import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import React, { useEffect, useState } from 'react'
import { useNavigate , Link} from 'react-router-dom';
import axios from 'axios'
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
} from '@mui/material';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
// mock
//import USERLIST from '../_mock/user';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
 { id: 'full_name', label: 'Full Name', alignRight: false },
  { id: 'name', label: 'Name', alignRight: false },
  { id: 'company', label: 'Password', alignRight: false },
  { id: 'phone_number', label: 'Phone Number', alignRight: false },
  { id: 'email', label: 'Email', alignRight: false },
  { id: 'Address', label: 'Address', alignRight: false },
  { id: 'Description', label: 'Description', alignRight: false },
  { id: 'Schedule', label: 'Schedule', alignRight: false },
  { id: 'Frequency', label: 'Frequency', alignRight: false },
  { id: 'subscriptions', label: 'Subscription', alignRight: false },
  { id: '' },
];

// ----------------------------------------------------------------------



export default function CustomersPage() {
  const [open, setOpen] = useState(null);

  const [page, setPage] = useState(0);

  const [order, setOrder] = useState('asc');

  const [selected, setSelected] = useState([]);

  const [orderBy, setOrderBy] = useState('name');

  const [filterName, setFilterName] = useState('');

  const [rowsPerPage, setRowsPerPage] = useState(5);
  
  const [filteredUsers, setFilteredUsers] = useState([]);


// Fetch users
const [users, setUsers] = useState([]);
useEffect(() => {
  const fetchAllUsers = async () => {
    try {
      const res = await axios.get('http://localhost:8080/customers');
      const fetchedUsers = res.data;

      // Initialize both users and filteredUsers with the data
      setUsers(fetchedUsers);
      setFilteredUsers(fetchedUsers);
    } catch (err) {
      console.log(err);
    }
  };

  fetchAllUsers();
}, []);

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}


function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });

  if (query) {
    // Use the appropriate property for filtering (e.g., _user.username)
    return filter(array, (_user) => _user.username.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }

  return stabilizedThis.map((el) => el[0]);
}





  const handleOpenMenu = (event, userId) => {
    setSelected([userId]); // Set the selected user ID
    setOpen(event.currentTarget);
  };
  

  const handleCloseMenu = () => {
    setOpen(null);
  };

const handleRequestSort = (event, property) => {
  const isAsc = orderBy === property && order === 'asc';
  setOrder(isAsc ? 'desc' : 'asc');
  setOrderBy(property);

  // Sort the filteredUsers array based on the selected property and order
  const sortedUsers = stableSort(filteredUsers, getComparator(order, property));

  // Update the filteredUsers state with the sorted array
  setFilteredUsers(sortedUsers);
};

  
// Retrieve user role from local storage
const storedUserRole = localStorage.getItem('userRole');



  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      // If all users are currently selected, unselect all
      const allSelected = selected.length === users.length;
      const newSelecteds = allSelected ? [] : users.map((user) => user.id);
      setSelected(newSelecteds);
    } else {
      // If unchecking the checkbox, unselect all
      setSelected([]);
    }
  };
  

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setPage(0);
    setRowsPerPage(parseInt(event.target.value, 10));
  };

  const handleFilterByName = (event) => {
    const value = event.target.value.toLowerCase();
  
    // Update the filterName state
    setFilterName(value);
  
    // If the search box is empty, show all users
    const newFilteredUsers = value
      ? users.filter((user) => user?.username?.toLowerCase().includes(value))
      : users; // Show all users when the search box is empty
  
    // Update the filteredUsers state
    setFilteredUsers(newFilteredUsers);
  };
  
  
  
  
  


  //fpr the update route
  const handleEdit = () => {
    console.log(selected); // Check the values in the console
    // Redirect to the '/update' page with the first selected user ID
    navigate(`/dashboard/CustomerUpdate/${selected[0]}`);


    const displayID = localStorage.getItem('displayID');
    const number = 1;
    
    axios.post('http://localhost:8080/ErrorT', { displayID, number })
      .then(response => {
        // console.log('Data inserted successfully');
        // Handle success
      })
      .catch(error => {
        // console.error('Error inserting data:', error);
        // Handle error
      });
    



  };
  
  


  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - users.length) : 0;

  //const filteredUsers = applySortFilter(users, getComparator(order, orderBy), filterName);


  const isNotFound = !filteredUsers.length && !!filterName;
  const navigate = useNavigate();

  //route
  const Adduser = () => {
    navigate('/dashboard/LocationAdd');
  };

 

//




    //delete
    const handleDelete = async () => {
      try {
        await Promise.all(
          selected.map(async (id) => {
            // Delete user based on the username
            await axios.delete(`http://localhost:8080/customers/${id}`);
          })
        );
    
        setSelected([]);
        window.location.href ='/dashboard/Customers';
    
      } catch (err) {
        console.error(err);
      }
    };
    
    
    
    console.log(selected)
    

    //delete 2
    const handleDeletee = async (selectedUserIds) => {
      try {
        await Promise.all(
          selectedUserIds.map(async (id) => {
            // Delete user based on the user ID
            await axios.delete(`http://localhost:8080/customers/${id}`);
          })
        );
    
        setSelected([]);
       
        window.location.href ='/dashboard/user';
      
      } catch (err) {
        console.error(err);
      }
    };
    


     //Update
     const handleUpdate = async (id)=>{
        try{
           await axios.put("http://localhost:8080/customers/" + id)
            window.location.reload()
        }catch(err){
            console.log(err)
        }
    }

console.log(selected);
  return (
    <>
      <Helmet>
        <title> User | Minimal UI </title>
      </Helmet>

      <Container>
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
          <Typography variant="h4" gutterBottom>
            Customers
          </Typography>
          <Button variant="contained" startIcon={<Iconify icon="eva:plus-fill" />} onClick={Adduser}>
            New Customer
          </Button>
        </Stack>

        <Card>

          
          <UserListToolbar numSelected={selected.length} filterName={filterName} onFilterName={handleFilterByName}  onDelete={storedUserRole !== 'Clerk' ? handleDelete : undefined} />

          <Scrollbar>
            <TableContainer sx={{ minWidth: 800 }}>
              <Table>
                <UserListHead
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={filteredUsers.length}
                  numSelected={selected.length}
                  onRequestSort={handleRequestSort}
                  onSelectAllClick={handleSelectAllClick}
                />
                <TableBody>
        {filteredUsers.map((user) => (
          <TableRow hover key={user.user_id} tabIndex={-1} role="checkbox">
            <TableCell padding="checkbox">
              <Checkbox checked={selected.indexOf(user.user_id) !== -1} onChange={(event) => handleClick(event, user.user_id)} />
            </TableCell>
            <TableCell align="left">{user.user_full_name}</TableCell>

            <TableCell component="th" scope="row" padding="none">
              <Stack direction="row" alignItems="center" spacing={2}>
                {user.picture && <Avatar alt={user.username} src={user.picture} />}
                <Typography variant="subtitle2" noWrap>
                  {user.username}
                </Typography>
              </Stack>
            </TableCell>

            <TableCell align="left">
  {user.password.split('').map((char, index) => (
    <span key={index}>*</span>
  ))}
</TableCell>

    

      

     
      <TableCell align="left">{user.phone_number}</TableCell>
      <TableCell align="left">{user.email}</TableCell>
      <TableCell align="left">{user.address}</TableCell>
      <TableCell align="left">{user.Description}</TableCell>
      <TableCell align="left">{user.Schedule}</TableCell>
      <TableCell align="left">{user.Frequency}</TableCell>
     
      <TableCell align="left">
      
      <Label color={user.subscriptions == 'Standard' ||"Professional"||"Enterprise" ? 'success' : 'error' }>{user.subscriptions}</Label>

      </TableCell>


      <TableCell align="right">
     
      {storedUserRole === 'Clerk' && [users[0]?.user_id, users[1]?.user_id].includes(user.user_id) && (
  <IconButton
    size="large"
    color="inherit"
    onClick={(event) => handleOpenMenu(event, user.user_id)}
  >
    <Iconify icon={'eva:more-vertical-fill'} />
  </IconButton>
)}

{storedUserRole !== 'Clerk' && (
    <IconButton
    size="large"
    color="inherit"
    onClick={(event) => handleOpenMenu(event, user.user_id)}
  >
    <Iconify icon={'eva:more-vertical-fill'} />
  </IconButton>
)}


      </TableCell>
    </TableRow>



  ))}
</TableBody>


                {isNotFound && (
                  <TableBody>
                    <TableRow>
                      <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                        <Paper
                          sx={{
                            textAlign: 'center',
                          }}
                        >
                          <Typography variant="h6" paragraph>
                            Not found
                          </Typography>

                          <Typography variant="body2">
                            No results found for &nbsp;
                            <strong>&quot;{filterName}&quot;</strong>.
                            <br /> Try checking for typos or using complete words.
                          </Typography>
                        </Paper>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Scrollbar>

          <TablePagination
  rowsPerPageOptions={[5, 10, users.length]}  // Add the total number of rows as an option
  component="div"
  count={users.length}
  rowsPerPage={rowsPerPage}
  page={page}
  onPageChange={handleChangePage}
  onRowsPerPageChange={handleChangeRowsPerPage}
/>

        </Card>
      </Container>

      <Popover
  open={Boolean(open)}
  anchorEl={open}
  onClose={handleCloseMenu}
  anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
  transformOrigin={{ vertical: 'top', horizontal: 'right' }}
  PaperProps={{
    sx: {
      p: 1,
      width: 140,
      '& .MuiMenuItem-root': {
        px: 1,
        typography: 'body2',
        borderRadius: 0.75,
      },
    },
  }}
>
  <MenuItem onClick={() => handleEdit(selected)}>
    <Iconify icon={'eva:edit-fill'} sx={{ mr: 2 }} />
    Edit
  </MenuItem>
  {storedUserRole !== 'Clerk' && (
  <MenuItem sx={{ color: 'error.main' }} onClick={() => handleDeletee(selected)}>
    <Iconify icon={'eva:trash-2-outline'} sx={{ mr: 2 }} />
    Delete
  </MenuItem>
)}

</Popover>
    </>
  );
}
