import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useTheme } from '@mui/material/styles';
import { Container, Typography, Paper } from '@mui/material';
import {
  DragDropContext,
  Droppable,
  Draggable,
} from 'react-beautiful-dnd';

export default function DashboardAppBoard() {
  const theme = useTheme();

  // Define 5 columns for your Kanban board
  const initialColumns = {
    'column-1': {
      id: 'column-1',
      title: 'To Do',
      taskIds: ['task-1', 'task-2'],
    },
    'column-2': {
      id: 'column-2',
      title: 'In Progress',
      taskIds: ['task-3', 'task-4'],
    },
    'column-3': {
      id: 'column-3',
      title: 'Review',
      taskIds: ['task-5', 'task-6'],
    },
    'column-4': {
      id: 'column-4',
      title: 'Testing',
      taskIds: ['task-7', 'task-8'],
    },
    'column-5': {
      id: 'column-5',
      title: 'Done',
      taskIds: ['task-9', 'task-10'],
    },
  };

  // Define tasks with unique IDs
  const tasks = {
    'task-1': { id: 'task-1', content: 'Task 1' },
    'task-2': { id: 'task-2', content: 'Task 2' },
    'task-3': { id: 'task-3', content: 'Task 3' },
    'task-4': { id: 'task-4', content: 'Task 4' },
    'task-5': { id: 'task-5', content: 'Task 5' },
    'task-6': { id: 'task-6', content: 'Task 6' },
    'task-7': { id: 'task-7', content: 'Task 7' },
    'task-8': { id: 'task-8', content: 'Task 8' },
    'task-9': { id: 'task-9', content: 'Task 9' },
    'task-10': { id: 'task-10', content: 'Task 10' },
  };

  // Create a state to manage columns
  const [columns, setColumns] = useState(initialColumns);

  const onDragEnd = (result) => {
    const { source, destination, draggableId } = result;

    if (!destination) {
      return; // The item was dropped outside of a droppable area
    }

    const sourceColumn = columns[source.droppableId];
    const destinationColumn = columns[destination.droppableId];

    if (sourceColumn === destinationColumn) {
      // Task moved within the same column
      const newTaskIds = [...sourceColumn.taskIds];
      newTaskIds.splice(source.index, 1);
      newTaskIds.splice(destination.index, 0, draggableId);

      const newColumn = {
        ...sourceColumn,
        taskIds: newTaskIds,
      };

      setColumns((prevColumns) => ({
        ...prevColumns,
        [newColumn.id]: newColumn,
      }));
    } else {
      // Task moved to a different column
      const newSourceTaskIds = [...sourceColumn.taskIds];
      newSourceTaskIds.splice(source.index, 1);

      const newDestinationTaskIds = [...destinationColumn.taskIds];
      newDestinationTaskIds.splice(destination.index, 0, draggableId);

      const updatedColumns = {
        ...columns,
        [sourceColumn.id]: {
          ...sourceColumn,
          taskIds: newSourceTaskIds,
        },
        [destinationColumn.id]: {
          ...destinationColumn,
          taskIds: newDestinationTaskIds,
        },
      };

      setColumns(updatedColumns);
    }
  };

  return (
    <>
      <Helmet>
        <title>Dashboard | Minimal UI</title>
      </Helmet>

      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 5 }}>
          Hi, Welcome back
        </Typography>

        <DragDropContext onDragEnd={onDragEnd}>
          <div
            style={{
              display: 'flex',
              overflowX: 'auto',
              justifyContent: 'space-between',
            }}
          >
            {Object.keys(columns).map((columnId) => {
              const column = columns[columnId];
              const tasksInColumn = column.taskIds.map((taskId) => tasks[taskId]);

              return (
                <div key={column.id} style={{ width: '19%' }}>
                  <Paper elevation={3} sx={{ padding: 2 }}>
                    <Typography variant="h6" sx={{ mb: 2 }}>
                      {column.title}
                    </Typography>
                    <Droppable droppableId={column.id}>
                      {(provided, snapshot) => (
                        <ul
                          {...provided.droppableProps}
                          ref={provided.innerRef}
                          style={{
                            minHeight: '100px',
                            position: 'relative', // Add position relative
                          }}
                        >
                          {tasksInColumn.map((task, index) => (
                            <Draggable
                              key={task.id}
                              draggableId={task.id}
                              index={index}
                            >
                              {(provided, snapshot) => (
                                <li
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  ref={provided.innerRef}
                                >
                                  {task.content}
                                  {/* Add a blue line as a placeholder */}
                                  {snapshot.isDraggingOver && (
                                    <div
                                      style={{
                                        position: 'absolute',
                                        width: '100%',
                                        height: '2px',
                                        backgroundColor: 'blue',
                                        top: provided.draggableProps.style.top, // Match the top position of the dragged item
                                      }}
                                    />
                                  )}
                                </li>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </ul>
                      )}
                    </Droppable>
                  </Paper>
                </div>
              );
            })}
          </div>
        </DragDropContext>
      </Container>
    </>
  );
}
