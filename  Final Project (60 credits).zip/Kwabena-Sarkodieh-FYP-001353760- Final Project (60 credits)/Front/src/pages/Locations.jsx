import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import React, { useEffect, useState } from 'react'
import { useNavigate , Link} from 'react-router-dom';
import axios from 'axios'
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
  ButtonGroup,
  Box,
  Tab, 

} from '@mui/material';


import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
import Maps from './Maps';
import LocationList from './LocationsList';

// mock
//import USERLIST from '../_mock/user';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'name', label: 'Location', alignRight: false },
  { id: 'role', label: 'Address Description', alignRight: false },
  { id: 'isVerified', label: 'Customer', alignRight: false },
  { id: 'status', label: 'Schedule', alignRight: false },
  { id: 'full_name', label: 'Frequency', alignRight: false },
  { id: 'markoff', label: '', alignRight: false },
  { id: '' },
];

// ----------------------------------------------------------------------



export default function Location() {



    const [value, setValue] = React.useState('1');

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };




  return (
    <>
     
      


<TabContext value={value}>
  <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
    <TabList onChange={handleChange} aria-label="lab API tabs example">
      <Tab label="List View" value="1" />
      <Tab label="Map View" value="2" />
 
    </TabList>
  </Box>
  <TabPanel value="1">
    <LocationList/>
  </TabPanel>
  <TabPanel value="2">
    
   <Maps /> 
  

  </TabPanel>
 
</TabContext>

    </>
  );
}
