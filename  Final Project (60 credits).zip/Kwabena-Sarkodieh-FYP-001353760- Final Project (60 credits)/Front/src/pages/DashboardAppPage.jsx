import { Helmet } from 'react-helmet-async';
import { faker } from '@faker-js/faker';
// @mui
import { useTheme } from '@mui/material/styles';
import { Grid, Container, Typography, Popover, Button ,Box, Card} from '@mui/material';
// components
import Iconify from '../components/iconify';
// sections
import {
  AppTasks,
  AppNewsUpdate,
  AppOrderTimeline,
  AppCurrentVisits,
  AppWebsiteVisits,
  AppTrafficBySite,
  AppWidgetSummary,
  AppCurrentSubject,
  AppConversionRates,
} from '../sections/@dashboard/app';
import axios from 'axios';
import { useEffect, useRef, useState } from 'react';
import { Refresh } from '@mui/icons-material';
import AI_Camera from './AI_Camera';
import WasteChart from './Report Stuff/Operationmgt/WasteChart';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import Wastetype from './Report Stuff/Personamgt/WasteType';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import { useNavigate } from 'react-router-dom';



// ----------------------------------------------------------------------

export default function DashboardAppPage() {
  const theme = useTheme();
  const [regStatus, setRegStatus] = useState("");
  const [UDate, setUDate] = useState("");
  const [anchorEl, setAnchorEl] = useState('');
  const navigate = useNavigate();
//role
const displayID = localStorage.getItem('displayID');
const [user, setUser] = useState({
  username: '',
  password: '',
  role: '', // Default role
  picture: '',
});
useEffect (() => {
  const fetchUserData = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/users/${displayID}`);
      const userData = response.data;
      setUser(userData);
    } catch (err) {
      console.log(err);
    }
  };

  const fetchUserDate = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/CdashDate/${displayID}`);
      const userData = response.data;
      setUDate(userData);
    } catch (err) {
      console.log(err);
    }
  };

  if (displayID) {
    fetchUserData();
    fetchUserDate();
  }
}, [displayID]);

console.log(UDate,'herrr bb')


  //gps
  const [UserID, setUserID] = useState("");
  const [ vehicleID, setvehicleID] = useState("");
  const [Longitude, setLongitude] = useState("");
  const [ Latitude, setLatitude] = useState("");
  const [Timestamp, setTimestamp] = useState("");
  const [Speed, setSpeed] = useState("");
  const [assignedVehicleID, setAssignedVehicleID] = useState(null);
  const [CurrentUserID, setCurrentUserID] = useState(localStorage.getItem('displayID'));




  const formatCurrentDateTime = () => {
    const currentDate = new Date();
    const formattedDate = currentDate.toISOString().slice(0, 19).replace('T', ' '); // Format to 'YYYY-MM-DD HH:mm:ss'
    return formattedDate;
  };
  const [disposalTime, setDisposalTime] = useState(formatCurrentDateTime());

//get vehicle
useEffect(() => {
  const fetchAssignedVehicleID = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/findVehicleID/${localStorage.getItem('displayID')}`);
      setAssignedVehicleID(response.data.vehicle_id);
     
    } catch (error) {
      console.error('Error fetching AssignedVehicleID:', error);
    }
  };

  fetchAssignedVehicleID();
}, []);


// Check role
const [userRole, setUserRole] = useState(null);

useEffect(() => {
  const checkRole = async () => {
    try {
      const response = await axios.post(`http://localhost:8080/check_role/${localStorage.getItem('displayID')}`);
      
      // Use response.data instead of response.status
      
      setUserRole(response.data.status);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  checkRole();
}, []);





//GPS API
const options = {
  enableHighAccuracy: true,
  timeout: 5000,
  maximumAge: 0,
};

function success(pos) {
  const crd = pos.coords;
  
  // console.log("Your current position is:");
  // console.log(`Latitude : ${crd.latitude}`);
  // console.log(`Longitude: ${crd.longitude}`);
  // console.log(`More or less ${crd.accuracy} meters.`);


  setLongitude(crd.longitude);
  setLatitude(crd.latitude);
  setSpeed(crd.accuracy);
}

function error(err) {
  console.warn(`ERROR(${err.code}): ${err.message}`);
}

navigator.geolocation.getCurrentPosition(success, error, options);







//id, UserID, vehicleID, Longitude, Latitude, Timestamp, Speed
const Addgps = () => {

  const CurrentDate = new Date().toISOString().slice(0, 19).replace("T", " ");





  axios.post("http://localhost:8080/addGPS", {
    UserID:  CurrentUserID,
    vehicleID: assignedVehicleID,
    Longitude: Longitude,
    Latitude: Latitude,
    Timestamp: CurrentDate,
    Speed: Speed,
  }).then((response) => {
    console.log(response + "help");
    setRegStatus(response.data.message);

    
  });

}


// Function to initialize GPS recording and set up interval
function initializeGPS() {
  // Record initial GPS data when the page is opened
  Addgps();
  

  // Set up interval to record GPS data every 3 minutes
  setInterval(function() {
      // Addgps();
    
  }, 3 * 60 * 1000); // 3 minutes in milliseconds (1 minute = 60 seconds, 1 second = 1000 milliseconds)
}

//dont forget to run it when demosntrating
//initializeGPS();


console.log(disposalTime )



const handlePopoverOpen = (event) => {
  setAnchorEl(event.currentTarget);
};

const handlePopoverClose = () => {
  window.location.href = '/dashboard/app';


  setAnchorEl(null);
  console.log('help me')
};

const handleYesClick = async () => {
  try {
    const response = await axios.put(`http://localhost:8080/Dispose/${CurrentUserID}`, { disposal_time: disposalTime });
    console.log('Response:', response.data);
  } catch (error) {
    console.error('Error updating user:', error);
  }
};



const handleNoClick = () => {
  // Handle 'No' click logic here

  handlePopoverClose();
};


//ai


const [anchorElz, setAnchorElz] = useState(null);

  const handleClickz = (event) => {
    setAnchorElz(event.currentTarget);
  };

  const handleClosez = () => {
    setAnchorElz(null);
  };

  const open = Boolean(anchorElz);
  const id = open ? 'simple-popover' : undefined;


//show collected in widget
const [Collected, setCollected] = useState(null);

useEffect(() => {
  // Assuming your server API endpoint for issue data is '/AUG'
  axios.get('http://localhost:8080/NCW')
    .then(response => {
      // Check if the response is an array and not empty
      if (Array.isArray(response.data) && response.data.length > 0) {
        // Extract the 'total_records' value from the first object in the array
        const totalRecords = response.data[0].total_records;
        setCollected(totalRecords);
      } else {
        console.error('Invalid data structure received from the server.');
      }
    })
    .catch(error => {
      console.error('Error retrieving data:', error);
    });
}, []);


//show CCollect in widget
// Frontend
// Frontend
const [Ccollected, setCcollected] = useState(null);

useEffect(() => {
  axios.get(`http://localhost:8080/NCWC/${CurrentUserID}`)
    .then(response => {
      // Handle the response data
      if (response.data && response.data.total_records !== undefined) {
        const totalRecords = response.data.total_records;
        setCcollected(totalRecords);
      } else {
        console.error('Invalid data structure received from the server.');
      }
    })
    .catch(error => {
      console.error('Error retrieving data:', error);
    });
}, [CurrentUserID]);

// first widget
const [Wcollected, setWcollected] = useState(null);

useEffect(() => {
  axios.get(`http://localhost:8080/WNCWC/${CurrentUserID}`)
    .then(response => {
      // Handle the response data
      if (response.data && response.data.total_records !== undefined) {
        const totalRecords = response.data.total_records;
        setWcollected(totalRecords);
      } else {
        console.error('Invalid data structure received from the server.');
      }
    })
    .catch(error => {
      console.error('Error retrieving data:', error);
    });
}, [CurrentUserID]);


///
const [Wollected, setWollected] = useState(null);

useEffect(() => {
  // Assuming your server API endpoint for issue data is '/AUG'
  axios.get('http://localhost:8080/WNCW')
    .then(response => {
      // Check if the response is an array and not empty
      if (Array.isArray(response.data) && response.data.length > 0) {
        // Extract the 'total_records' value from the first object in the array
        const totalRecords = response.data[0].total_records;
        setWollected(totalRecords);
      } else {
        console.error('Invalid data structure received from the server.');
      }
    })
    .catch(error => {
      console.error('Error retrieving data:', error);
    });
}, []);


console.log(Ccollected+"kk56")

const [latestChanges, setLatestChanges] = useState([]);

  useEffect(() => {
    const fetchLatestChanges = async () => {
      try {
        const response = await axios.get('http://localhost:8080/latestChanges');
        setLatestChanges(response.data);
      } catch (error) {
        console.error('Error fetching latest changes:', error);
      }
    };

    fetchLatestChanges();
  }, []);
  
  const getDescriptionByTitle = (title, description) => {
    if (title.endsWith('Issues' || 'Complaints')) {
      return `Issue type ${description} reported.`;
    } else if (title === 'General Waste' || title === 'Recyclables' || title === 'Bulky Waste' || title === 'Hazardous Waste' || title === 'Electronic Waste') {
      return `Waste of ${description} recorded.`;
    } else if (description === 'Admin' || description === 'Garbage Collector') {
      return `New user role ${description} added.`;
    } else {
      return description; // Fallback to the original description if no match
    }
  };
  
  
  
  
  const [showLocationMessage, setShowLocationMessage] = useState(true);
  const [showLogoutMessage, setShowLogoutMessage] = useState(false);

  useEffect(() => {
    const locationMessageTimer = setTimeout(() => {
      setShowLocationMessage(false);
      setShowLogoutMessage(true);

     
    }, 6000);

    const logoutMessageTimer = setTimeout(() => {
      setShowLogoutMessage(false);

      if (user.role =='Customer'){
        setShowLogoutMessage(true); 
        setShowLocationMessage(true);
      }
    }, 12000); // 6 seconds after the location message disappears

    return () => {
      clearTimeout(locationMessageTimer);
      clearTimeout(logoutMessageTimer);
    };
  }, []);

  const getDatesForDayOfWeek = (dayOfWeek) => {
    const currentDate = new Date();
    const currentWeekStart = startOfWeek(currentDate);
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = addDays(currentWeekStart, i);
      if (date.getDay() === dayOfWeek) {
        dates.push(date);
      }
    }
    return dates;
  };
let Empt =' .'

//customer collected
const [totalA, setTotalA] = useState(null);

useEffect(() => {
  const fetchData = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/TotalWasteC/${localStorage.getItem('displayID')}`);
      setTotalA(response.data[0]['sum(quantity)']); // Accessing the value from the response object
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  fetchData();
}, []);
  return (
    <>
      <Helmet>
        <title> Dashboard | Minimal UI </title>
      </Helmet>

      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 5 }}>
          Hi, Welcome back
        </Typography>

        {showLocationMessage && (
             <Box
             sx={{
               position: 'fixed',
               bottom: '20px',
               left: '50%',
               transform: 'translateX(-50%)',
               backgroundColor: 'rgba(255, 0, 0, 0.8)',
               color: '#fff',
               padding: '10px 20px',
               borderRadius: '5px',
               zIndex: 9999,
               display: showLocationMessage ? 'block' : 'none',
               animation: showLocationMessage ? 'blink 1s infinite' : 'none',
             }}
           >
            Waste System Tracking your Location
          </Box>
        )}

        {showLogoutMessage && (
          <Box
          sx={{
            position: 'fixed',
            bottom: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: 'rgba(255, 0, 0, 0.8)',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '5px',
            zIndex: 9999,
            display: showLogoutMessage ? 'block' : 'none',
            animation: showLogoutMessage ? 'blink 1s infinite' : 'none',
          }}
        >
            Garbage Collectors Must LogOut When Not Collecting
          </Box>
        )}

        <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={user.role === 'Customer' ? 6 : 3}>

            <AppWidgetSummary title="Collected Waste" total={user.role === 'Admin' ? Wollected : (user.role === 'Garbage Collector' ? Wcollected : (user.role === 'Customer' ? totalA : null))}
   icon={'mdi:bin-empty'} />
            
          </Grid>

          {user.role !== 'Customer' && (
  <Grid item xs={12} sm={6} md={3}>
    <AppWidgetSummary title="Completed Waste" total={userRole === 'allow' ? Collected : Ccollected}  color="info" icon={'mdi:bin-outline'} />
  </Grid>
)}


          <>
          <Grid
  item
  xs={12}
  sm={6}
  md={user.role === 'Customer' ? 6 : 3}
  onClick={handleClickz}
  style={{ transition: 'transform 0.2s ease-in-out' }}
  onMouseEnter={(e) => {
    e.currentTarget.style.transform = 'scale(1.05)';
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.transform = 'scale(1)';
  }}
>
  <AppWidgetSummary
    title="AI Camera"
    color="warning"
    icon={'mdi:camera-enhance'}
    total={<span style={{ opacity: 0 }}>.</span>}
    style={{ transition: 'transform 0.2s ease-in-out' }}
  />
</Grid>


      <Popover
        id={id}
        open={open}
        anchorEl={anchorElz}
        onClose={handleClosez}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'center',
          horizontal: 'center',
        }}
      >
          <Grid style={{ width: '50vw', height: '50vh', display: 'grid' }}>
           
           <AI_Camera/>
        </Grid>
      </Popover>
    </>

    {user.role !== 'Customer' && (
  <Grid
    item
    xs={12}
    sm={6}
    md={3}
    onClick={handlePopoverOpen}
    style={{ transition: 'transform 0.2s ease-in-out' }}
    onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'scale(1.05)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'scale(1)';
    }}
  >
    <AppWidgetSummary
      title="Dispose Waste"
      color="error"
      icon={'mdi:bin-restore'}
      total={<span style={{ opacity: 0 }}>.</span>}
      style={{ transition: 'transform 0.2s ease-in-out' }}
    />
    <Popover
      open={Boolean(anchorEl)}
      anchorEl={anchorEl}
      onClose={handlePopoverClose}
      anchorOrigin={{
        vertical: 'center',
        horizontal: 'center',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
    >
      <Grid style={{ width: '30vw', height: '30vh', display: 'grid' }}>
        <Typography>
          Do you want to proceed?
        </Typography>
        <Button onClick={handleYesClick} style={{ color: 'green' }}>
          Yes
        </Button>
        <Button onClick={handleNoClick} style={{ color: 'red' }}>
          No
        </Button>
      </Grid>
    </Popover>
  </Grid>
)}



    <Grid item xs={12} md={6} lg={8}>
      <Card>
  {user.role === "Customer" ? <Wastetype/> : <WasteChart/>}
  </Card>
</Grid>


          <Grid item xs={12} md={6} lg={4}>
            <Card>
  {user.role === 'Admin' ? (
    <AppNewsUpdate
      title="Latest Changes"
      list={Array.isArray(latestChanges) ? latestChanges.map(item => ({
        id: item.record_id,
        title: item.title,
        description: getDescriptionByTitle(item.title, item.description),
        image: `/assets/images/covers/cover_${item.record_id}.jpg`,
        postedAt: item.record_time,
      })) : []}
    />
  ) : user.role === 'Customer'  ? (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
    {UDate.map((data, index) => {
      console.log(data.Schedule,'tetttt'); // Log data.Schedule value
      return (
        <DateCalendar
          key={index}
          initialDate={data.Schedule} // Pass the selected date from UDate as the initialDate
          readOnly // Disable the pick function
        />
      );
    })}
  </LocalizationProvider>
  ) : (
    <AppNewsUpdate
    title="Latest Changes"
    list={[]}
/>

  )}</Card>
</Grid>




       

    

         

         

         
        </Grid>
      </Container>
      <style jsx global>{`
        @keyframes blink {
          0% {
            opacity: 1;
          }
          25% {
            opacity: 1;
          }
          50% {
            opacity: 1;
          }
          100% {
            opacity: 0;
          }
        }
      `}</style>
    </>
  );
}
