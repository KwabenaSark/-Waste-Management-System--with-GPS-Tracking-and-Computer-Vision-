import { Helmet } from 'react-helmet-async';
import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import React, { useEffect, useState } from 'react'
import { useNavigate , Link} from 'react-router-dom';
import axios from 'axios'
// @mui
import {
  Card,
  Table,
  Stack,
  Paper,
  Avatar,
  Button,
  Popover,
  Checkbox,
  TableRow,
  MenuItem,
  TableBody,
  TableCell,
  Container,
  Typography,
  IconButton,
  TableContainer,
  TablePagination,
  ButtonGroup,
  Box,
  Tab, 

} from '@mui/material';


import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
// components
import Label from '../components/label';
import Iconify from '../components/iconify';
import Scrollbar from '../components/scrollbar';
// sections
import { UserListHead, UserListToolbar } from '../sections/@dashboard/user';
import Maps from './Maps';
import LocationList from './LocationsList';
import Fleetmgt from './Report Stuff/Fleetmgt';
import Usermgt from './Report Stuff/Usermgt';
import Operationmgt from './Report Stuff/Operationmgt';
import Personamgt from './Report Stuff/Personamgt';

// mock
//import USERLIST from '../_mock/user';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'name', label: 'Location', alignRight: false },
  { id: 'role', label: 'Address Description', alignRight: false },
  { id: 'isVerified', label: 'Customer', alignRight: false },
  { id: 'status', label: 'Schedule', alignRight: false },
  { id: 'full_name', label: 'Frequency', alignRight: false },
  { id: 'markoff', label: '', alignRight: false },
  { id: '' },
];

// ----------------------------------------------------------------------





export default function Report() {

  const displayID = localStorage.getItem('displayID');
const [user, setUser] = useState({
  username: '',
  password: '',
  role: '', // Default role
  picture: '',
});
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/users/${displayID}`);
        const userData = response.data;
        setUser(userData);
      } catch (err) {
        console.log(err);
      }
    };
  
    if (displayID) {
      fetchUserData();
    }
  }, [displayID]);

   const [value, setValue] = React.useState('1');
const [defaultValueSet, setDefaultValueSet] = React.useState(false); // New state for tracking default value setting

const handleChange = (event, newValue) => {
  setValue(newValue);
};
    React.useEffect(() => {
      if (!defaultValueSet) { // Set default value only once when component mounts
        if (user.role !== 'Admin') {
          setValue('4');
        }setValue('1');
        setDefaultValueSet(true);
        
      }
    }, [defaultValueSet, user.role]);

    let tabsToRender;
    if (user.role === 'Admin') {
      tabsToRender = (
        <>
         <TabList onChange={handleChange} aria-label="lab API tabs example">
          <Tab label="Fleet Management Overview" value="1" />
          <Tab label="Employee Management Overview" value="2" />
          <Tab label="Operational Management Overview" value="3" />
          </TabList>
        </>
      );
    } else { 
      tabsToRender = ( <TabList onChange={handleChange} aria-label="lab API tabs example">
      <Tab label="Personalized Report" value="4" /></TabList>);
    }

    let Access;
    if (user.role === 'Admin') {
      Access = (
        <>
         <TabPanel value="1">
   <Fleetmgt/>
  </TabPanel>
  <TabPanel value="2">
    
 <Usermgt/>
  

  </TabPanel>
  <TabPanel value="3">
    
  <Operationmgt/>
   
 
   </TabPanel>
        </>
      );
    } else {
      Access = (
        <TabPanel value="4">
    
        <Personamgt/>
          
        
          </TabPanel>);
    }
    



  

  return (
    <>
     
      


<TabContext value={value}>
  <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
   
    { tabsToRender}
 
   
  </Box>
 
   { Access}
 
</TabContext>
<div style={{paddingLeft:'3%'}}>
<Button color="primary" variant="outlined"  onClick={print} >Print</Button></div>
    </>
  );
}
