import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function TotalEmp() {
  const [totalUsers, setTotalUsers] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/Rev')
      .then(response => {
        // Extract the total users count from the response data
        const numberOfUsers = response.data[0]?.['sum(price)'] || 0;

        // Set the state with the extracted count
        setTotalUsers(numberOfUsers);

        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Revenue</Typography>
      <Typography variant='h2'>${totalUsers}</Typography>
    </>
  );
}
