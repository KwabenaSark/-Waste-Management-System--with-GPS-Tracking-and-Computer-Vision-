import React, { useState, useEffect } from 'react';
import { Typography } from '@mui/material';
import { AppWebsiteVisits } from 'src/sections/@dashboard/app';
import axios from 'axios';

export default function WasteChart() {
  // State variables
  const [chartData, setChartData] = useState([]);
  const [wasteOutData, setWasteOutData] = useState([]);

  useEffect(() => {
    const fetchWasteData = async () => {
      try {
        const res = await axios.get('http://localhost:8080/WasteIn');
        const data = res.data.map(entry => ({
          name: entry.average_date,
          WasteIn: parseInt(entry.total_quantity)
        }));
        setChartData(data);
      } catch (err) {
        console.error('Error fetching waste data:', err);
      }
    };

    fetchWasteData();
  }, []);

  useEffect(() => {
    const fetchWasteOutData = async () => {
      try {
        const res = await axios.get('http://localhost:8080/WasteOut');
        const data = res.data.map(entry => ({
          name: entry.average_date,
          WasteOut: parseInt(entry.total_quantity)
        }));
        setWasteOutData(data);
      } catch (err) {
        console.error('Error fetching waste out data:', err);
      }
    };

    fetchWasteOutData();
  }, []);

   // Calculate the average between WasteIn and WasteOut for each corresponding index
   const averageData = chartData.map((entry, index) => ({
    name: entry.name,
    Average: (entry.WasteIn + wasteOutData[index]?.WasteOut) / 2
  }));
  console.log(averageData,'ddjd')

  return (
    <>
      <Typography variant='h6'>Waste In & Out</Typography>
      <AppWebsiteVisits
        chartLabels={chartData.map(entry => entry.name)}
        chartData={[
          {
            name: 'Waste In',
            type: 'column',
            fill: 'solid',
            data: chartData.map(entry => entry.WasteIn),
          },
          {
            name: 'Waste Out',
            type: 'area',
            fill: 'gradient',
            data: wasteOutData.map(entry => entry.WasteOut),
          },
          {
            name: 'Average',
            type: 'line',
            fill: 'solid',
            data:  averageData.map(entry => entry.Average),
          },
        ]}
      />
    </>
  );
}
