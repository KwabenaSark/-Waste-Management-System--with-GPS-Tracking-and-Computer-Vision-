import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Typography } from '@mui/material';
import { AppCurrentVisits } from 'src/sections/@dashboard/app';
import { useTheme } from '@mui/material/styles';

export default function CustomerRegion() {
  const theme = useTheme();
  const [issueData, setIssueData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/CusReg')
      .then(response => {
        setIssueData(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  // Mapping issueData to create chartData and chartColors
  const chartData = issueData.map(item => ({
    label: item.Location_Name,
    value: item.count,
  }));

  const chartColors = [
    theme.palette.primary.main,
    theme.palette.info.main,
    theme.palette.warning.main,
    theme.palette.error.main,
    // Add more colors if needed based on the length of issueData
  ];

  return (
    <>
      <Typography variant='h6'>Customer based regions</Typography>
      <AppCurrentVisits
        chartData={chartData}
        chartColors={chartColors}
      />
    </>
  );
}
