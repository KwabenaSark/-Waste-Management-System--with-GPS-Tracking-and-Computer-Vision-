import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function TotalWaste() {
  const [totalWasteCollected, setTotalWasteCollected] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/OPtop')
      .then(response => {
        // Extract the total waste collected value from the response data
        const totalWaste = response.data[0]?.total_waste_collected || 0;

        // Set the state with the extracted value
        setTotalWasteCollected(totalWaste);

        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Waste Collected/kg</Typography>
      <Typography variant='h2'>{totalWasteCollected}</Typography>
    </>
  );
}
