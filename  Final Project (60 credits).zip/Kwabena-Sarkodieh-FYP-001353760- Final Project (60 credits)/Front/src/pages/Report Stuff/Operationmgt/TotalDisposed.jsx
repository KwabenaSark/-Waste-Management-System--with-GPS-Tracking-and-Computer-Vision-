

import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function TotalDisposed() {
  const [totalCustomers, setTotalCustomers] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/OPtop')
      .then(response => {
        // Extract the total customers count from the response data
        const numberOfCustomers = response.data[0]?.total_disposals || 0;

        // Set the state with the extracted count
        setTotalCustomers(numberOfCustomers);

        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
        <Typography variant='h6'>Waste Disposed/kg</Typography>
      <Typography variant='h2'>{totalCustomers}</Typography>
    </>
  );
}
