import React, { useState, useEffect } from 'react';
import { Stack, Typography } from '@mui/material';
import { PolarArea } from 'react-chartjs-2';
import 'chart.js/auto';
import axios from 'axios';

const ActiveUsers = () => {
  const [subData, setSubData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/ClerkR')
      .then(response => {
        setSubData(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  const generateRandomColor = () => {
    return `rgba(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, 0.5)`;
  };

  const filteredSubData = subData.filter(item => item.name); // Filter out entries with null or empty subscriptions

  const labels = filteredSubData.map(item => item.name);
  const counts = filteredSubData.map(item => item.number);
  const backgroundColors = filteredSubData.map(() => generateRandomColor());

  const data = {
    labels: labels,
    datasets: [
      {
        data: counts,
        backgroundColor: backgroundColors,
      },
    ],
  };

  const config = {
    type: 'polarArea',
    data: data,
    options: {
      responsive: true,
      scales: {
        r: {
          pointLabels: {
            display: true,
            font: {
              size: 18,
            },
          },
        },
      },
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Clerks',
        },
      },
    },
  };

  return (
    <Stack spacing={2} style={{ width: '70%', margin: 'auto' }}>
      <Typography variant="h6">Error rates or discrepancies in data entries of Clerk</Typography>
      <PolarArea {...config} />
    </Stack>
  );
};

export default ActiveUsers;




