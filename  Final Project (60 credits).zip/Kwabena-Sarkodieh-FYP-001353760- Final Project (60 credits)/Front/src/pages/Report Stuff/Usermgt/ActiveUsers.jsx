import React, { useEffect, useState } from 'react';
import { Stack, Typography } from '@mui/material';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';
import axios from 'axios';

const ActiveUsers = () => {
  const [issueData, setIssueData] = useState([]);

  useEffect(() => {
    // Assuming your server API endpoint for issue data is '/AUG'
    axios.get('http://localhost:8080/AUG')
      .then(response => {
        setIssueData(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  const roles = issueData.map(entry => entry.role);
  const usersWithYesStatusData = issueData.map(entry => entry.users_with_yes_status);

  // Simple prediction logic (for demonstration purposes)
  const predictedValues = usersWithYesStatusData.map(value => value + Math.random() * 5);

  const datasets = roles.map((role, index) => ({
    label: role,
    data: [usersWithYesStatusData[index], predictedValues[index]],
    borderColor: getRandomColor(),
    backgroundColor: 'rgba(0, 0, 0, 0)', // Set background color to transparent
    cubicInterpolationMode: 'monotone',
  }));

  const data = {
    labels: ['Active Users', 'Predicted Users / hr'],
    datasets: datasets,
  };

  const config = {
    type: 'line',
    data: data,
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Active Users Right Now',
        },
      },
    },
  };

  return (
    <Stack spacing={2} style={{ height: '45vh' }}>
      <Typography variant="h6">Active users right now</Typography>
      <Line {...config} />
    </Stack>
  );
};

export default ActiveUsers;

// Function to generate a random color (for borderColor)
function getRandomColor() {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}
