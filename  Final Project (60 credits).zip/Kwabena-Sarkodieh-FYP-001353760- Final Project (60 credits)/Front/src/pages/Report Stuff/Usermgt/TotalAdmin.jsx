import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function TotalAdmin() {
  const [totalA, setTotalA] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/NumR')
      .then(response => {
        // Extract the Admin count from the response data
        const numberOfAdmins = response.data[0]?.total_users || 0;

        // Set the state with the extracted count
        setTotalA(numberOfAdmins);

        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Admin</Typography>
      <Typography variant='h2'>{totalA}</Typography>
    </>
  );
}
