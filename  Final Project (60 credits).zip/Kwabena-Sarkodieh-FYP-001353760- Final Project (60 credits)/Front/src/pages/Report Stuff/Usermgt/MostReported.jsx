import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import { AppConversionRates } from 'src/sections/@dashboard/app';
import axios from 'axios';

export default function MostReported() {
  const [issueData, setIssueData] = useState([]);

  useEffect(() => {
    // Assuming your server API endpoint for issue data is '/MRep'
    axios.get('http://localhost:8080/MRep')
      .then(response => {
        setIssueData(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  const chartData = issueData.map(item => ({
    label: item.IssueType,
    value: item.Count,
  }));

  return (
    <>
      <Typography variant='h6'>Most reported issue</Typography>
      <AppConversionRates chartData={chartData} />
    </>
  );
}
