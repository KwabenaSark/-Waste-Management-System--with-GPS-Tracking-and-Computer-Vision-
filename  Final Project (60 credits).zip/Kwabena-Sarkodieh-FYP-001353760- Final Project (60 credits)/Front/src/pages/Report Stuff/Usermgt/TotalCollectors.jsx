import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function TotalCollectors() {
  const [totalCollectors, setTotalCollectors] = useState(null);

  useEffect(() => {
    // Assuming your server API endpoint for both Admin and Garbage Collector counts is '/NumR'
    axios.get('http://localhost:8080/NumR')
      .then(response => {
        // Find the entry with role 'Garbage Collector' and extract the total_users count
        const garbageCollectorEntry = response.data.find(entry => entry.role === 'Garbage Collector');
        const numberOfCollectors = garbageCollectorEntry?.total_users || 0;

        // Set the state with the extracted count
        setTotalCollectors(numberOfCollectors);

        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Garbage Collector</Typography>
      <Typography variant='h2'>{totalCollectors}</Typography>
    </>
  );
}
