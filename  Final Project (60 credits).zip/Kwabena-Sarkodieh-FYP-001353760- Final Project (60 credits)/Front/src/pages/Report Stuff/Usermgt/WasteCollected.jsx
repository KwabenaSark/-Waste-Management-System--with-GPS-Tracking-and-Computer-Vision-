import React, { useState, useEffect } from 'react';
import {
  Card,
  Button,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Avatar,
} from '@mui/material';
import axios from 'axios';
// ... other imports

export default function WasteCollected() {
  const [users, setUsers] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);

  const fetchAllUsers = async () => {
    try {
      const response = await axios.get('http://localhost:8080/WorkU');
      const fetchedUsers = response.data;

      // Check if the fetchedUsers is an array before setting the state
      if (Array.isArray(fetchedUsers)) {
        setUsers(fetchedUsers);
      } else {
        console.error('Invalid data structure received from the server.');
      }
    } catch (error) {
      console.error('Failed to fetch users:', error.message);
    }
  };

  useEffect(() => {
    fetchAllUsers();
  }, []); // Use useEffect to fetch data when the component mounts

  const handleListItemClick = (userId) => {
    setSelectedUserId(userId);
    // Add your logic for handling the click event, if needed
  };

  return (
    <>
      <Typography variant='h6'>Quantities of waste collected by each collector.</Typography>
      <br />
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell> Name</TableCell>
              <TableCell>Quantity</TableCell>
              {/* Add more columns as needed */}
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user) => (
              <TableRow
                key={user.user_id}
                onClick={() => handleListItemClick(user.user_id)}
                selected={selectedUserId === user.user_id}
              >
                <TableCell style={{ display: 'flex' }}>
                  <Avatar alt={user.username} src={user.picture} />
                  {user.username}
                </TableCell>
                <TableCell>{user.total_quantity}</TableCell>
                {/* Add more cells for additional information */}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
