import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function TotalClerks() {
  const [totalClerks, setTotalClerks] = useState(null);

  useEffect(() => {
    // Assuming your server API endpoint for Clerk count is '/NumR'
    axios.get('http://localhost:8080/NumR')
      .then(response => {
        // Find the entry with role 'Clerk' and extract the total_users count
        const clerkEntry = response.data.find(entry => entry.role === 'Clerk');
        const numberOfClerks = clerkEntry?.total_users || 0;

        // Set the state with the extracted count
        setTotalClerks(numberOfClerks);

        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Clerk</Typography>
      <Typography variant='h2'>{totalClerks}</Typography>
    </>
  );
}
