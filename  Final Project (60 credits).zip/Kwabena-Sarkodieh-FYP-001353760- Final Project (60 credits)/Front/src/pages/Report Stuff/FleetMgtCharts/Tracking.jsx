import React, { useState, useEffect } from 'react';
import { Typography, Divider, LinearProgress, Box, Stack, List, ListItem, ListItemText, ListItemAvatar, Avatar } from '@mui/material';
import axios from 'axios';

export default function Tracking() {
  const [drivers, setDrivers] = useState([]);

  const fetchAllVehicles = async () => {
    try {
      const res = await axios.get('http://localhost:8080/Carbon');
      const fetchedDrivers = res.data;
      setDrivers(fetchedDrivers);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAllVehicles();
  }, []);

  return (
    <>
      <Stack>
        <Typography variant='h6'>Realtime Carbon Emissions Tracking</Typography>
        <Divider />
        <Box sx={{ width: '100%' }}>
          {drivers.map(driver => (
            <React.Fragment key={driver.id}>
              <List sx={{ width: '100%', maxWidth: '100%', bgcolor: 'background.paper' }}>
                <ListItem button>
                  <ListItemAvatar>
                    <Avatar alt={driver.username} src={driver.picture} />
                  </ListItemAvatar>
                  <ListItemText primary={driver.username} secondary={`Carbon Emissions per km: ${driver.estimated_carbon_emission_per_km}`} />
                </ListItem>
              </List>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Box sx={{ width: '100%', mr: 1 }}>
                  <LinearProgress variant="determinate" value={(driver.total_carbon_emission / 10000) * 100} />
                </Box>
                <Box sx={{ minWidth: 35 }}>
                  <Typography variant="body2" color="text.secondary">{`Total: ${driver.total_carbon_emission}`}</Typography>
                </Box>
              </Box>
              <Divider />
            </React.Fragment>
          ))}
        </Box>
      </Stack>
    </>
  );
}
