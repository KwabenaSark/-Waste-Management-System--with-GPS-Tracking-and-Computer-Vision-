import * as React from 'react';
import { PieChart } from '@mui/x-charts/PieChart';
import { useDrawingArea } from '@mui/x-charts/hooks';
import { styled } from '@mui/material/styles';
import { Stack, Typography } from '@mui/material';
import { Divider } from '@mui/material';
import { useEffect } from 'react';
import axios from 'axios';
import { useState } from 'react';




const data = [
  { value: 0, label: 'Available' },
  { value: 1, label: 'InUse' },

];

const size = {
  width: 400,
  height: 200,
};

const StyledText = styled('text')(({ theme }) => ({
  fill: theme.palette.text.primary,
  textAnchor: 'middle',
  dominantBaseline: 'central',
  fontSize: 20,
}));

function PieCenterLabel({ children }) {
  const { width, height, left, top } = useDrawingArea();
  return (
    <StyledText x={left + width / 2} y={top + height / 2}>
      {children}
    </StyledText>
  );
}

export default function VehicleStatusChart() {

const [vehicleOptions, setVehicleOptions] = useState([]);
const [vehicleUse, setVehicleUse] = useState([]);
useEffect(() => {
 

  const fetchVehicleOptions = async () => {
    try {
      const response = await axios.get('http://localhost:8080/vehicle-options'); // Change the endpoint accordingly
      setVehicleOptions(response.data);
      data[0].value = response.data.length;
    } catch (err) {
      console.log(err);
    }
  };



  fetchVehicleOptions();





  const fetchVehicleInUse = async () => {
      try {
        const response = await axios.get('http://localhost:8080/vehicle-in-use'); // Change the endpoint accordingly
        setVehicleUse(response.data);
        data[1].value = response.data.length;
      } catch (err) {
        console.log(err);
      }
    };

   

    fetchVehicleInUse();
}, []);



  return (
    <>
    <Stack>
    <Typography variant='h6'>Vehicle Status</Typography>
    </Stack>
    <Divider />
    <PieChart series={[{ data, innerRadius: 75 }]} {...size}>
      <PieCenterLabel>Vehicle Status</PieCenterLabel>
    </PieChart>
    </>
  );
}