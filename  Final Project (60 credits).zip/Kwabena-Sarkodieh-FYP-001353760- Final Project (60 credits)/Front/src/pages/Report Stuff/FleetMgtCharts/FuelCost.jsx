
import React, { useState, useEffect } from 'react';
import { Stack, Typography } from '@mui/material';
import axios from 'axios';

function FuelCost() {
  const [vroute, setVroute] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/FCost')
      .then(response => {
        const numberOfVehicles = response.data[0]?.fuel_cost || 0;
        setVroute(numberOfVehicles);
        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Fuel Cost</Typography>
      <Typography variant='h2'>{vroute !== null ? vroute : 'Loading...'}</Typography>
    </>
  );
}

export default FuelCost;

