// Importing necessary modules and components from React, Material-UI, and other libraries
import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import { Stack, Typography } from '@mui/material';
import { BarChart } from '@mui/x-charts/BarChart';
import { Divider } from '@mui/material';
import axios from 'axios';


// Functional component named VehicleUsageGraph
export default function VehicleUsageGraph() {
  // State variables using the useState hook
  const [series, setSeries] = useState([]);
  const [seriesNb, setSeriesNb] = useState(2);
  const [itemNb, setItemNb] = useState(20);
  const [skipAnimation, setSkipAnimation] = useState(false);
  

  // useEffect hook to fetch data from the backend when the component mounts
  useEffect(() => {
    axios.get('http://localhost:8080/vehicleUsage')
      .then((response) => {
        if (response.data.length > 0) {
          const seriesData = response.data
            .filter((vehicle) => vehicle.Model && vehicle.TotalMileage !== undefined && vehicle.TotalMileage >= 0)
            .map((vehicle) => ({
              name: vehicle.Model,
              data: [vehicle.TotalMileage],
            }));
          setSeries(seriesData);
        } else {
          console.error('Empty data received.');
        }
      })
      .catch((error) => console.error('Error fetching vehicle usage data:', error));
  }, []);
  
 
  // JSX code for rendering the component
  return (
    <>
      <Stack>
        <Typography variant='h6'>Vehicle Usage</Typography>
      </Stack>
      <Divider />
      <Box sx={{ width: '100%', height: '50%' }}>
        {/* BarChart component from @mui/x-charts library */}
     
       
<BarChart
   xAxis={[{ scaleType: 'band', data: ['Total Mile Usage'] }]}
  height={200}
  series={series.map((s) => ({
    label: s.name,
    data: s.data.slice(0, itemNb),
  }))}
  skipAnimation={skipAnimation}
  tooltip={{
    formatter: (params) => {
      const { label, value, color } = params;
      return (
        `<div style="display: flex; flex-direction: column;">
          <span>Name: ${label}</span>
          <span>Total Mileage: ${value} Mileage</span>
          <span>Color: ${color}</span>
        </div>`
      );
    },
  }}
/>






      </Box>
    </>
  );
}
