import React, { useState, useEffect } from 'react';
import { Card, Button, Typography, Grid, Paper, List, ListItem, ListItemText, ListItemAvatar, Avatar} from '@mui/material';
import axios from 'axios';
import Label from 'src/components/label';
export default function DriverStatus() {
  const [emp, setEmp] = useState([]);
  const [selectedId, setSelectedId] = useState(null);

  const fetchAllVehicles = async () => {
    try {
      const res = await axios.get('http://localhost:8080/DStats');
      const fetchedUsers = res.data;
      setEmp(fetchedUsers);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAllVehicles();
  }, []); // Use useEffect to fetch data when the component mounts

  const handleListItemClick = (id) => {
    setSelectedId(id);
    // Add your logic for handling the click event, if needed
  };

  return (
    <>
     <Typography variant='h6'>Driver Status</Typography>
     <br />
      <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
        {emp.map((user) => (
          <ListItem
            key={user.id}
            onClick={() => handleListItemClick(user.id)}
            selected={selectedId === user.id}
            button
          >
            <ListItemAvatar>
              <Avatar alt={user.username} src={user.picture} />
            </ListItemAvatar>
            <ListItemText primary={user.username} secondary={`Vehicle: ${user.vehicle}`} />
            <Label color={user.status === 'Active' ? 'success' : 'error'}>{user.status}</Label>
            
          </ListItem>
          
        ))}
      </List>
    </>
  );
}
