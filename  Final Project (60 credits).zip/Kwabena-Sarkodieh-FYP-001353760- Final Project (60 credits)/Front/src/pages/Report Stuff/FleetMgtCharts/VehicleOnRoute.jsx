import React, { useState, useEffect } from 'react';
import { Stack, Typography } from '@mui/material';
import axios from 'axios';

function VehicleOnRoute() {
  const [vroute, setVroute] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:8080/VRoute')
      .then(response => {
        const numberOfVehicles = response.data[0]?.num_vehicles || 0;
        setVroute(numberOfVehicles);
        console.log(response.data);
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
      });
  }, []);

  return (
    <>
      <Typography variant='h6'>Number of Vehicles on Route</Typography>
      <Typography variant='h2'>{vroute !== null ? vroute : 'Loading...'}</Typography>
    </>
  );
}

export default VehicleOnRoute;
