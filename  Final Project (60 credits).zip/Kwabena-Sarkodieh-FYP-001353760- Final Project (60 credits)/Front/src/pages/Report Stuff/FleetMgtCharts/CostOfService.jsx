import React from 'react'
import { Stack, Typography } from '@mui/material';

export default function CostOfService() {
  return (
    <>
          <Typography variant='h6'>Cost Of Service</Typography>
          <Typography variant='h2'>67</Typography>
  
    </>
  )
}


