import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function Subscription() {
    const [totalA, setTotalA] = useState(null);

    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await axios.get(`http://localhost:8080/TotalWasteC/${localStorage.getItem('displayID')}`);
          setTotalA(response.data[0]['sum(quantity)']); // Accessing the value from the response object
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      };
  
      fetchData();
    }, []);

  return (
    <>
      <Typography variant='h6'>Total Waste  </Typography>
      <Typography variant='h2'>{totalA} kg</Typography>
    </>
  );
}
