import React, { useState, useEffect } from 'react';
import { Stack, Typography } from '@mui/material';
import { PolarArea } from 'react-chartjs-2';
import 'chart.js/auto';
import axios from 'axios';

const Wastetype = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAllUsers = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/CWtype/${localStorage.getItem('displayID')}`);
        const fetchedUsers = response.data;

        if (Array.isArray(fetchedUsers)) {
          setUsers(fetchedUsers);
        } else {
          console.error('Invalid data structure received from the server.');
        }
      } catch (error) {
        console.error('Failed to fetch users:', error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAllUsers();
  }, []); // Empty dependency array ensures this effect runs only once after initial render

  const labels = users.map(user => user.wastetype);
  const quantities = users.map(user => user.quantity);

  const data = {
    labels: labels,
    datasets: [
      {
        label: 'Dataset 1',
        data: quantities,
        backgroundColor: [
          'rgba(255, 99, 132, 0.5)',
          'rgba(255, 165, 0, 0.5)',
          'rgba(255, 255, 0, 0.5)',
          'rgba(0, 128, 0, 0.5)',
          'rgba(0, 0, 255, 0.5)',
        ],
      },
    ],
  };

  const config = {
    type: 'polarArea',
    data: data,
    options: {
      responsive: true,
      scales: {
        r: {
          pointLabels: {
            display: true,
            font: {
              size: 18,
            },
          },
        },
      },
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Waste Type',
        },
      },
    },
  };

  return (
    <Stack spacing={2} style={{ width: '70%', margin: 'auto' }}>
      <Typography variant="h6">Waste Type</Typography>
      {loading ? (
        <Typography>Loading...</Typography>
      ) : (
        <PolarArea {...config} />
      )}
    </Stack>
  );
};

export default Wastetype;
