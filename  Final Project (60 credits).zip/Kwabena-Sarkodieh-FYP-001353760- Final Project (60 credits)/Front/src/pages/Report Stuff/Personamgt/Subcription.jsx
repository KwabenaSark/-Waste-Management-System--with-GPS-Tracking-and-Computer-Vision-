import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import axios from 'axios';

export default function Subscription() {
  const [subscriptionType, setSubscriptionType] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/Csub/${localStorage.getItem('displayID')}`);
        setSubscriptionType(response.data[0].subscriptions); // Accessing the subscriptions property
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <Typography variant='h6'>Subscription Type</Typography>
      <Typography variant='h2'>{subscriptionType !== null ? subscriptionType : 'Loading...'}</Typography>
    </>
  );
}
