import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Unstable_Grid2';
import TotalAdmin from './Usermgt/TotalAdmin';
import Card from '@mui/material/Card';
import TotalCollectors from './Usermgt/TotalCollectors';
import TotalClerks from './Usermgt/TotalClerks';
import MostReported from './Usermgt/MostReported';
import ActiveUsers from './Usermgt/ActiveUsers';
import WasteCollected from './Usermgt/WasteCollected';
import ErrorRate from './Usermgt/ErrorRate';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Usermgt() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
      
        <Grid xs={6} md={4}>
        <Card>
          <Item>
              <TotalAdmin/>
          </Item>
          </Card>
        </Grid>
          <Grid xs={6} md={4}>
          <Card>
          <Item>
              <TotalCollectors/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={4}>
        <Card>
          <Item>
              <TotalClerks/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={7}>
        <Card>
          <Item>
              <MostReported/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={5}>
        <Card>
          <Item>
              <ActiveUsers/>
          </Item>
          </Card>
        </Grid>
         <Grid xs={6} md={6}>
         <Card>
          <Item>
              <WasteCollected/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={6}>
        <Card>
          <Item>
              <ErrorRate/>
          </Item>
          </Card>
        </Grid>
        
      </Grid>
    </Box>
  );
}