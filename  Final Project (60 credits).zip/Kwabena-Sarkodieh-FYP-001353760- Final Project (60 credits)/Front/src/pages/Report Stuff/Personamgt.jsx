import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Unstable_Grid2';
import TotalAdmin from './Usermgt/TotalAdmin';
import Card from '@mui/material/Card';
import TotalCollectors from './Usermgt/TotalCollectors';
import TotalClerks from './Usermgt/TotalClerks';
import MostReported from './Usermgt/MostReported';
import ActiveUsers from './Usermgt/ActiveUsers';
import WasteCollected from './Usermgt/WasteCollected';
import ErrorRate from './Usermgt/ErrorRate';
import CustCollected from './Personamgt/CustCollected';
import Subscription from './Personamgt/Subcription';
import History from './Personamgt/History';
import Wastetype from './Personamgt/WasteType';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Personamgt() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
      
        <Grid xs={6} md={6}>
        <Card>
          <Item>
              <CustCollected/>
          </Item>
          </Card>
        </Grid>
          <Grid xs={6} md={6}>
          <Card>
          <Item>
              <Subscription/>
          </Item>
          </Card>
        </Grid>

         <Grid xs={6} md={6}>
         <Card>
          <Item>
              <History/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={6}>
        <Card>
          <Item>
              <Wastetype/>
          </Item>
          </Card>
        </Grid>
        
      </Grid>
    </Box>
  );
}