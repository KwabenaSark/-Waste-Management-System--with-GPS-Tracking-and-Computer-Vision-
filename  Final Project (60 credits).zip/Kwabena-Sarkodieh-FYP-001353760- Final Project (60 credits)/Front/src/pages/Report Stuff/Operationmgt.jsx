import * as React from 'react';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Unstable_Grid2';
import WasteChart from './Operationmgt/WasteChart';
import Card from '@mui/material/Card';
import TotalCustomers from './Operationmgt/TotalCustomers';
import TotalWaste from './Operationmgt/TotalWaste';
import TotalDisposed from './Operationmgt/TotalDisposed';
import TotalEmp from './Operationmgt/TotalEmp';
import WComposition from './Operationmgt/WComposition';
import CustomerRegion from './Operationmgt/CustomerRegion';
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Operationmgt() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
      
        <Grid xs={6} md={3}>
        <Card>
          <Item>
<TotalCustomers/>
          </Item>
          </Card>
        </Grid>
          <Grid xs={6} md={3}>
          <Card>
          <Item>
<TotalWaste/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={3}>
        <Card>
          <Item>
<TotalDisposed/>
          </Item>
          </Card>
        </Grid>
          <Grid xs={6} md={3}>
          <Card>
          <Item>
<TotalEmp/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={7}>
        <Card>
          <Item>
          <WComposition/>
          </Item>
          </Card>
        </Grid>
        <Grid xs={6} md={5}>
          <Card>
          <Item>
<CustomerRegion/>
          </Item>
          </Card>
        </Grid>
        
        <Grid xs={6} md={12}>
          <Card>
          <Item>
            <WasteChart/>
          </Item>
          </Card>
        </Grid>
        
      </Grid>
    </Box>
  );
}