import { Helmet } from 'react-helmet-async';
// @mui
import { styled } from '@mui/material/styles';
import { Link, Container, Typography, Divider, Stack, Button } from '@mui/material';
// hooks

// components
import Logo from 'src/components/logo';
import useResponsive from 'src/hooks/useResponsive';
import VehicleAddForm from 'src/Forms/VehicleAddForm';
import LocationAddForm from 'src/Forms/LocationAddForm';

// sections






// ----------------------------------------------------------------------

const StyledRoot = styled('div')(({ theme }) => ({
  [theme.breakpoints.up('md')]: {
    display: 'flex',
  },
}));

const StyledSection = styled('div')(({ theme }) => ({
  width: '100%',
  maxWidth: 480,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  boxShadow: theme.customShadows.card,
  backgroundColor: theme.palette.background.default,
}));

const StyledContent = styled('div')(({ theme }) => ({
  maxWidth: 480,
  margin: 'auto',
  minHeight: '100vh',
  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'column',
  padding: theme.spacing(12, 0),
}));

// ----------------------------------------------------------------------

export default function LocationAdd() {
  const mdUp = useResponsive('up', 'md');




  return (
    <>
      <Helmet>
        <title> Add Customer | Waste Management System </title>
      </Helmet>

      <StyledRoot>
        <Logo
          sx={{
            position: 'fixed',
            top: { xs: 16, sm: 24, md: 40 },
            left: { xs: 16, sm: 24, md: 40 },
          }}
        />

        {mdUp && (
          <StyledSection>
            <Typography variant="h3" sx={{ px: 10, mt: 10, mb: 5 }}>
              Register New Customer / Location
            </Typography>
            <img src="/assets/illustrations/K4C.png" alt="login" />
          </StyledSection>
        )}

        <Container maxWidth="sm">
          <StyledContent>
            <Typography variant="h4" gutterBottom>
              Register to the Waste Management System
            </Typography>



            <Divider sx={{ my: 3 }}>
              <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                Begin
              </Typography>
            </Divider>

            <LocationAddForm/>
          </StyledContent>
        </Container>
      </StyledRoot>
    </>
  );
}
