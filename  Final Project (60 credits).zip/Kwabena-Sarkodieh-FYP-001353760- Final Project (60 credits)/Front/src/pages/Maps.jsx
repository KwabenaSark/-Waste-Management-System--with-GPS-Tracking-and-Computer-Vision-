import React, { useEffect, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import axios from 'axios';
import {Card,  Button, Typography }from '@mui/material';
import CardContent from '@mui/material/CardContent';

import 'mapbox-gl/dist/mapbox-gl.css';

const Maps = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [mapStyle, setMapStyle] = useState('mapbox://styles/mapbox/streets-v12');

  useEffect(() => {
    const fetchAllUsers = async () => {
      try {
        const res = await axios.get('http://localhost:8080/Map');
        const fetchedUsers = res.data;
console.log(fetchedUsers)
        // Convert latitude and longitude to numbers
        const usersWithNumericCoordinates = fetchedUsers.map((user) => ({
          ...user,
          Latitude: parseFloat(user.Latitude),
          Longitude: parseFloat(user.Longitude),
        }));

        // Initialize both users and filteredUsers with the converted data
        setUsers(usersWithNumericCoordinates);
        setFilteredUsers(usersWithNumericCoordinates);

        // Initialize the map
        mapboxgl.accessToken = 'pk.eyJ1Ijoia29iYnkxLSIsImEiOiJjbHB2NW5lMmcwMjNqMmhwYm12NWtiZm05In0.Z0IZunMVk_wccwNHMRh7AA';

        const map = new mapboxgl.Map({
          container: 'map', // container ID
          style: mapStyle, // set the initial style
          zoom: 10, // starting zoom
          center: [-0.1869644, 5.6037168], // Accra, Ghana coordinates
        });

       map.on('load', () => {
  // Load an image from an external URL.
  map.loadImage(
    '/assets/illustrations/marker.png',
    (error, image) => {
      if (error) throw error;

      // Add the image to the map style.
      map.addImage('cat', image);

      // Create a GeoJSON FeatureCollection with multiple features
      const geojsonFeatures = usersWithNumericCoordinates.map((user) => ({
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [user.Longitude, user.Latitude],
        },
        properties: {
          title: user.Location_Name,
        },
      }));

      // Add a layer to use the image to represent the data.
      map.addLayer({
        id: 'points',
        type: 'symbol',
        source: {
          type: 'geojson',
          data: {
            type: 'FeatureCollection',
            features: geojsonFeatures,
          },
        },
        layout: {
          'icon-image': 'cat',
          'icon-size': 0.2,
          'text-field': ['get', 'title'],
          'text-size': 12,
          'text-offset': [0, -5],
          'text-anchor': 'top',
        },
      });
    }
  );
});
      } catch (err) {
        console.error(err);
      }
    };

    fetchAllUsers();
  }, [mapStyle]); // Depend on mapStyle to re-render when the style changes

  const handleStyleChange = (newStyle) => {
    setMapStyle(newStyle);
  };

  return (
    <>
      

    <Card id="map" style={{ height: '80vh', width: '100%' }} >
      
    </Card>
    <br />
    <Card style={{ marginTop: '10px' }}>  
    <Button onClick={() => handleStyleChange('mapbox://styles/mapbox/dark-v11')}>Dark View</Button>
    <Button onClick={() => handleStyleChange('mapbox://styles/mapbox/satellite-streets-v12')}>Satellite View</Button>
    <Button onClick={() => handleStyleChange('mapbox://styles/mapbox/streets-v12')}>Streets View</Button>
</Card>
<br />
<Typography>
      Map only Shows Uncollected Locations
      </Typography>
    </>
  
  );
};

export default Maps;
