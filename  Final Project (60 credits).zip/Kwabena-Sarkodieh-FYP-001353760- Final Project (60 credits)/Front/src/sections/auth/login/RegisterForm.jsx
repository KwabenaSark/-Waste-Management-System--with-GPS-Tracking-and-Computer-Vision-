import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
// @mui
import { Link, Stack, IconButton, InputAdornment, TextField, Checkbox, Select, MenuItem } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import Iconify from '../../../components/iconify';
import {
    Avatar,
    Grid,
    FormControl,
  InputLabel,
  } from '@mui/material';

// ----------------------------------------------------------------------

import axios from 'axios'; 
import { useLocation } from 'react-router-dom';

export default function RegisterForm() {
  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);
  const [usernameReg, setUernameReg] = useState("");
  const [passwordReg, setPasswordReg] = useState("");
  const [role, setRole] = useState("Garbage Collector"); // Default role

  //New sets
  const [drivers_license_no_Reg, setDrivers_license_no_Reg] = useState("");
  const [employment_date_Reg, setEmployment_date_Reg] = useState("");
  const [full_name_Reg, setfull_name_Reg] = useState("");
  const [phone_number_Reg, setphone_number_Reg] = useState("");
  const [email_Reg, setemail_Reg] = useState("");
  const [address_Reg, setaddress_Reg] = useState("");
  const [vehicle_id_Reg, setvehicle_id_Reg] = useState("");
  const [Vehicle_Reg, setVehicle_Reg] = useState("");


  const [regStatus, setRegStatus] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState(null);


  const avatarImages = Array.from({ length: 25 }, (_, index) => `/assets/images/avatars/avatar_${index + 1}.jpg`);
  const register = () => {
    axios.post("http://localhost:8080/register", {
      username: usernameReg,
      password: passwordReg,
      role: role,
      picture: selectedAvatar, 
      //new sets

   drivers_license_no:drivers_license_no_Reg,
    employment_date:employment_date_Reg, 
    full_name:full_name_Reg,
    email:email_Reg, 
    phone_number:phone_number_Reg, 
    address:  address_Reg,
     vehicle_id: vehicle_id_Reg , 
     Vehicle:  Vehicle_Reg ||'',







    }).then((response) => {
      console.log(response + "help");
      setRegStatus(response.data.message);

      if (response.data.message === 'Registration successful') {
        navigate('/dashboard/user');
      }
    });
  };


  const [vehicleOptions, setVehicleOptions] = useState([]);

useEffect(() => {
  // Fetch vehicle options from your API endpoint
  axios.get("http://localhost:8080/vehicle-options")
    .then((response) => {
      setVehicleOptions(response.data);
    })
    .catch((error) => {
      console.error("Error fetching vehicle options:", error);
    });
}, []);
console.log(vehicleOptions, 'options')
;

  return (
    <>
      <Stack spacing={3}>


 {/* Avatar selection dropdown */}
 <FormControl fullWidth sx={{ mt: 2 }}>
          <InputLabel id="avatar-label">Avatar</InputLabel>
          <Select
            labelId="avatar-label"
            value={selectedAvatar}
            onChange={(e) => setSelectedAvatar(e.target.value)}
            label="Avatar"
            renderValue={(selected) => (
              <Avatar
                alt="Selected Avatar"
                src={selected}
                sx={{ cursor: 'pointer', marginRight: 1 }}
              />
            )}
          >
            {avatarImages.map((avatarUrl, index) => (
              <MenuItem key={index} value={avatarUrl}>
                <Avatar
                  alt={`Avatar ${index + 1}`}
                  src={avatarUrl}
                  sx={{ cursor: 'pointer', marginRight: 1 }}
                />
                Avatar {index + 1}
              </MenuItem>
            ))}
          </Select>
        </FormControl>




        <TextField
          name="username"
          label="Username"
          onChange={(e) => {
            setUernameReg(e.target.value);
          }}
        />

        <TextField
          name="password"
          label="Password"
          type={showPassword ? 'text' : 'password'}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                  <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                </IconButton>
              </InputAdornment>
            ),
          }}
          onChange={(e) => {
            setPasswordReg(e.target.value);
          }}
        />

        {/* Dropdown for Role */}
        <Select
          label="Role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          sx={{ mt: 2 }}
        >
          <MenuItem value="Admin">Admin</MenuItem>
          <MenuItem value="Garbage Collector">Garbage Collector</MenuItem>
          <MenuItem value="Clerk">Clerk</MenuItem>
        </Select>

        <TextField
  name="drivers_license_no"
  label="Driver's License Number"
  onChange={(e) => {
    setDrivers_license_no_Reg(e.target.value);
  }}
/>

<TextField
  name="employment_date"
  label="Employment Date"
  type="date"  // Assuming it's a date input, adjust as needed
  onChange={(e) => {
    setEmployment_date_Reg(e.target.value);
  }}
/>

<TextField
  name="full_name"
  label="Full Name"
  onChange={(e) => {
    setfull_name_Reg(e.target.value);
  }}
/>

<TextField
  name="phone_number"
  label="Phone Number"
  onChange={(e) => {
    setphone_number_Reg(e.target.value);
  }}
/>

<TextField
  name="email"
  label="Email"
  type="email"  // Assuming it's an email input, adjust as needed
  onChange={(e) => {
    setemail_Reg(e.target.value);
  }}
/>

<TextField
  name="address"
  label="Address"
  onChange={(e) => {
    setaddress_Reg(e.target.value);
  }}
/>

<FormControl fullWidth sx={{ mt: 2 }}>
  <InputLabel id="vehicle-label">Vehicle</InputLabel>
  <Select
    labelId="vehicle-label"
    value={Vehicle_Reg}
    onChange={(e) => {
      setVehicle_Reg(e.target.value);
      // Set the corresponding vehicle_id based on the selected option
      const selectedOption = vehicleOptions.find((option) => option.Model === e.target.value);
      if (selectedOption) {
        setvehicle_id_Reg(selectedOption.VehicleID);
        console.log(selectedOption.VehicleID, 'doen here')
      }
    }}
    label="Vehicle"
  >
    {vehicleOptions.map((option) => (
      <MenuItem key={option.id} value={option.Model}>
        {option.Model}
      </MenuItem>
      
    ))}
  </Select>
</FormControl>










      </Stack>
      
      <br />


      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={register}>
        Register
      </LoadingButton>

      <h1> {regStatus}</h1>
    </>
  );
}
