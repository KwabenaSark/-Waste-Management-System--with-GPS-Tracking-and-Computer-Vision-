import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
// @mui
import { Link, Stack, IconButton, InputAdornment, TextField, Checkbox } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// components
import Iconify from '../../../components/iconify';

// ----------------------------------------------------------------------

import axios from 'axios';
import { useLocation } from 'react-router-dom';

export default function LoginForm() {
  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);

  const handleClick = () => {
    navigate('/dashboard', { replace: true });
  };

  const [username, setUername] = useState('');
  const [password, setPassword] = useState('');
  const [loginStatus, setLoginStatus] = useState('');
 

  const login = () => {
    axios.post('http://localhost:8080/login', {
      username: username,
      password: password,
    }).then((response) => {
      if (!response.data.message) {
        setLoginStatus();
      } else {
        setLoginStatus(response.data.message);

        if (response.data.message === 'Login successful') {

          localStorage.setItem('Token', 'true');
          window.location.href = '/dashboard';
          //console.log(response.data.username)
          const displayID = response.data.userId;
         localStorage.setItem('displayID', response.data.userId);
         axios.put(`http://localhost:8080/update-status/${displayID}`);
         console.log(displayID)
        }
      }
    });

   


  };

  const isButtonDisabled = !username || !password;

  return (
    <>
      <Stack spacing={3}>
        <TextField
          name="email"
          label="Username"
          onChange={(e) => {
            setUername(e.target.value);
          }}
        />

        <TextField
          name="password"
          label="Password"
          type={showPassword ? 'text' : 'password'}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                  <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                </IconButton>
              </InputAdornment>
            ),
          }}
          onChange={(e) => {
            setPassword(e.target.value);
          }}
        />
      </Stack>

      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ my: 2 }}>
      
        <Link variant="subtitle2" underline="hover" href="/landing">
          Forgot password?
        </Link>
      </Stack>

      <LoadingButton
        fullWidth
        size="large"
        type="submit"
        variant="contained"
        onClick={login}
        disabled={isButtonDisabled}
      >
        Login
      </LoadingButton>

      <h1> {loginStatus}</h1>
    </>
  );
}
