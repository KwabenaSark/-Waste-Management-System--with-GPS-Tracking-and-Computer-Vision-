import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {
  Stack,
  IconButton,
  InputAdornment,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Avatar,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import Iconify from '../../../components/iconify';
import axios from 'axios';
import { useLocation } from 'react-router-dom';

export default function UpdateForm() {
  const navigate = useNavigate();
  const { id } = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    username: '',
    password: '',
    role: 'Garbage Collector', // Default role
    picture: '',

  //new sets
  drivers_license_no:'',
  employment_date:'', 
  full_name:'',
  email:'', 
  phone_number:'', 
  address:'',
   vehicle_id:'', 
   Vehicle:'',


  });
  const [Use, setUse] = useState([]);
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState('Garbage Collector');
  const [regStatus, setRegStatus] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(null);
  const [vehicleOptions, setVehicleOptions] = useState([]);
  const [vehicleUse, setVehicleUse] = useState([]);
  const avatarImages = Array.from({ length: 24 }, (_, index) => `/assets/images/avatars/avatar_${index + 1}.jpg`);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/users/${id}`);
        const userData = response.data;
        userData.employment_date = userData.employment_date ? new Date(userData.employment_date).toISOString().split('T')[0] : '';
        setUser(userData);
        setRole(userData.role);
        setSelectedAvatar(userData.picture || null);
      } catch (err) {
        console.log(err);
      }
    };

    const fetchVehicleOptions = async () => {
      try {
        const response = await axios.get('http://localhost:8080/vehicle-options'); // Change the endpoint accordingly
        setVehicleOptions(response.data);
        
      } catch (err) {
        console.log(err);
      }
    };

    if (id) {
      fetchUserData();
    }

    fetchVehicleOptions();





    const fetchVehicleInUse = async () => {
        try {
          const response = await axios.get('http://localhost:8080/vehicle-in-use'); // Change the endpoint accordingly
          setVehicleUse(response.data);
          
        } catch (err) {
          console.log(err);
        }
      };
  
      if (id) {
        fetchUserData();
      }
  
      fetchVehicleInUse();
  }, [id]);

  console.log(vehicleUse.map(vet => vet.VehicleID + ' used'));



//   console.log(vehicleOptions.map((vehicle) => vehicle.VehicleID), 'testlog');


const handleChange = (e) => {
    const { name, value } = e.target;
  
    // Check if the selected vehicle is in vehicleOptions
    const selectedVehicleOptions = vehicleOptions.find((vehicle) => vehicle.Model === value);
  
    // Check if the selected vehicle is in vehicleUse
    const selectedVehicleUse = vehicleUse.find((vet) => vet.Model === value);
    // 
    // For the "Vehicle" dropdown, set the selected vehicle's ID to the "vehicle_id" field
    if (name === 'Vehicle') {
      setUser((prev) => ({
        ...prev,
        vehicle_id: selectedVehicleOptions ? selectedVehicleOptions.VehicleID : 
                    selectedVehicleUse ? selectedVehicleUse.VehicleID : '',
        [name]: value,
      }));
    } else {
      setUser((prev) => ({
        ...prev,
        [name]: value,
      }));
    }

    setUse(selectedVehicleUse.VehicleID) 
  };

  
  
  
  console.log(user.vehicle_id +'here id again')
  
  
  console.log(Use , 'used');
  
  

  const handleClick = async (e) => {
    e.preventDefault();
    
    try {
      console.log('Request Payload:', user); // Log user data
  
      if (user.vehicle_id === Use ) {
        // Run both requests in parallel and wait for both to complete
        await Promise.all([
          axios.put(`http://localhost:8080/v-assign/${Use}`),
         axios.put(`http://localhost:8080/users/${id}`, user)
        ]);
console.log('not working')
    navigate('/dashboard/user');
      } else {
        // Run only the second request
        await axios.put(`http://localhost:8080/users/${id}`, user);
        navigate('/dashboard/user'); // Only navigate when the second request is executed
      }
  
      setRegStatus('Update successful!');
    } catch (err) {
      console.log(err);
      setRegStatus('Update failed. Please try again.');
    }
  };
  





  
  

  return (
    <>
      <Stack spacing={3}>

{/* {Avatar picture} */}
      <FormControl fullWidth sx={{ mt: 2 }}>
  <InputLabel id="avatar-label">Avatar</InputLabel>
  <Select
    name='picture'
    labelId="avatar-label"
    value={user.picture || ''}
    onChange={(e) => setUser((prev) => ({ ...prev, picture: e.target.value }))}
    label="Avatar"
    renderValue={(selected) => (
      <Avatar alt="Selected Avatar" src={selected} sx={{ cursor: 'pointer', marginRight: 1 }} />
    )}
  >
    {avatarImages.map((avatarUrl, index) => (
      <MenuItem key={index} value={avatarUrl}>
        <Avatar alt={`Avatar ${index + 1}`} src={avatarUrl} sx={{ cursor: 'pointer', marginRight: 1 }} />
        Avatar {index + 1}
      </MenuItem>
    ))}
  </Select>
</FormControl>

<TextField name="username" label="username" onChange={handleChange} value={user.username} />


        <TextField
          name="password"
          label="Password"
          type={showPassword ? 'text' : 'password'}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                  <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                </IconButton>
              </InputAdornment>
            ),
          }}
          onChange={handleChange}
          value={user.password}
        />

<Select name='role' label="Role" value={user.role} onChange={(e) => setUser((prev) => ({ ...prev, role: e.target.value }))} sx={{ mt: 2 }}>
  <MenuItem value="Admin">Admin</MenuItem>
  <MenuItem value="Garbage Collector">Garbage Collector</MenuItem>
  <MenuItem value="Clerk">Clerk</MenuItem>
</Select>



 {/* New text fields */}
 <TextField
  name="employment_date"
  label="Employment Date"
  onChange={handleChange}
  value={user.employment_date}
  type='date'
  InputLabelProps={{
    shrink: true,
  }}
  InputProps={{
    inputProps: {
      style: { fontSize: 14 },
      pattern: '\\d{4}-\\d{2}-\\d{2}', 
    },
  }}
/>


        <TextField name="full_name" label="Full Name" onChange={handleChange} value={user.full_name} />
        <TextField name="email" label="Email" onChange={handleChange} value={user.email} />
        <TextField name="phone_number" label="Phone Number" onChange={handleChange} value={user.phone_number} />
        <TextField name="address" label="Address" onChange={handleChange} value={user.address} />
       
        {/* <TextField name="vehicle_id" label="vehicle_id" onChange={handleChange} value={user.vehicle_id} /> */}
        {/* Vehicle dropdown */}

        <TextField
          name="Vehicle"
          label="Vehicle"
          onChange={handleChange}
          value={user.Vehicle}  // Set the default value from the state
          disabled  // Make the TextField non-editable
        />

        <FormControl fullWidth sx={{ mt: 2 }}>
          <InputLabel id="vehicle-label">Change Vehicle</InputLabel>
          <Select
  name="Vehicle"
  labelId="vehicle-label"
  value={user.Vehicle || ''}
  onChange={(e) => handleChange(e)}  // Make sure the event is passed to handleChange
  label="Vehicle"
>
    {[...vehicleOptions, ...vehicleUse].map((vehicle) => (
  <MenuItem
    key={vehicle.VehicleID}
    value={vehicle.Model}
    style={{ color: vehicleUse.some((vet) => vet.Model === vehicle.Model) ? 'red' : 'green' }}
  >
    {vehicle.Model}
  </MenuItem>
))}

          </Select>
        </FormControl>

      </Stack>
<br />
   
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
