import { useState, useEffect } from 'react';
// @mui
import { alpha } from '@mui/material/styles';
import { Box, MenuItem, Stack, IconButton, Popover, TextField, Button, Container, Grid,Tab, Tabs } from '@mui/material';
import MarkEmailReadIcon from '@mui/icons-material/MarkEmailRead';
import axios from 'axios';
// ----------------------------------------------------------------------











// Now you can use the roleOptions array for rendering your UI


// ----------------------------------------------------------------------

export default function LanguagePopover() {

  const displayID = localStorage.getItem('displayID');

  const [user, setUser] = useState({
    username: '',
    password: '',
    role: 'Garbage Collector', // Default role
    picture: '',
  });

  

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/users/${displayID}`);
        const userData = response.data;
        setUser(userData);
      } catch (err) {
        console.log(err);
      }
    };

    // Check if displayID is defined before making the request
    if (displayID) {
      fetchUserData();
    }
  }, [displayID]); // Change id to displayID














  let roleOptions = [];

if (user.role === 'Admin') {
  // Admin can see all options
  roleOptions = [
    { label: 'All', value: 'All' },
    { label: 'Admin', value: 'Admin' },
    { label: 'Garbage Collector', value: 'Garbage Collector' },
    { label: 'Clerk', value: 'Clerk' },
    { label: 'Customer', value: 'Customer' },
  ];
} else if (user.role === 'Clerk') {
  // Clerk can only see customer and garbage collector options
  roleOptions = [
    { label: 'Customer', value: 'Customer' },
    { label: 'Garbage Collector', value: 'Garbage Collector' },
  ];
} else {
  // For other roles, show all options
  roleOptions = [
   
   
  ];
}

  
  const [open, setOpen] = useState(null);

  const handleOpen = (event) => {
    setOpen(event.currentTarget);
  };

  const handleClose = () => {
    setOpen(null);
  };



  const [formData, setFormData] = useState({
    role: '',
    user_id: null,
    message: '',
  
  });

console.log(formData.role)

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/notification', formData);
      // Assuming '/api/notification' is the endpoint to post data to
      console.log('Data posted successfully!');
      handleClose()
      // You may want to display a success message or reset the form here
    } catch (error) {
      console.error('Error posting data:', error);
      // Handle errors appropriately, like displaying an error message
    }
  };



  const handleRoleChange = (newValue) => {
    setFormData({ ...formData, role: newValue });
  };





  return (
    <>
      <IconButton
        onClick={handleOpen}
        sx={{
          padding: 0,
          width: 44,
          height: 44,
          ...(open && {
            bgcolor: (theme) => alpha(theme.palette.primary.main, theme.palette.action.focusOpacity),
          }),
        }}
      >
       <MarkEmailReadIcon/>
      </IconButton>

      <Popover
        open={Boolean(open)}
        anchorEl={open}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        PaperProps={{
          sx: {
            p: 1,
            mt: 1.5,
            ml: 0.75,
            width: 580,
            '& .MuiMenuItem-root': {
              px: 1,
              typography: 'body2',
              borderRadius: 0.75,
            },
          },
        }}
      >
        <Stack spacing={0.75}>
          

        <Container maxWidth="sm">
      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Tabs
              value={formData.role}
              onChange={(e, newValue) => handleRoleChange(newValue)}
              variant="scrollable"
              scrollButtons="auto"
            >
              {roleOptions.map((option, index) => (
                <Tab
                  key={index}
                  label={option.label}
                  value={option.value}
                  sx={{
                    
                    color: 'grey', // Default color
                    '&.Mui-selected': {
                      color: index % 2 === 0 ? 'blue' : 'green', // Varying color when selected
                    },
                  }}
                />
              ))}
            </Tabs>
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              variant="outlined"
              label="Message"
              name="message"
              value={formData.message}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              fullWidth
            >
              Submit
            </Button>
          </Grid>
        </Grid>
      </form>
    </Container>



        </Stack>
      </Popover>
    </>
  );
}
