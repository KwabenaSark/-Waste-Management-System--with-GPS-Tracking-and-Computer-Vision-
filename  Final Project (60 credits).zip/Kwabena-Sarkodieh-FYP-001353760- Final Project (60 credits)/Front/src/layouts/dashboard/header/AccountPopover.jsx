import { useEffect, useState } from 'react';
// @mui
import { alpha } from '@mui/material/styles';
import { Box, Divider, Typography, Stack, MenuItem, Avatar, IconButton, Popover, FormControlLabel, Switch, TextField , Button} from '@mui/material';
// mocks_
import account from '../../../_mock/account';
import axios from 'axios';
import { useNavigate , Link} from 'react-router-dom';
import FormGroup from '@mui/material/FormGroup';

// ----------------------------------------------------------------------

const MENU_OPTIONS = [
  {
    label: 'Home',
    icon: 'eva:home-fill',
  },
  {
    label: 'Profile',
    icon: 'eva:person-fill',
  },
  {
    label: 'Settings',
    icon: 'eva:settings-2-fill',
  },
];

// ----------------------------------------------------------------------

export default function AccountPopover() {
  const displayID = localStorage.getItem('displayID');

  const [settingsPopoverOpen, setSettingsPopoverOpen] = useState(false); // Define settings popover state
 
  //delte Acc
  const [isDeleteAccount, setIsDeleteAccount] = useState(false);
  const [textFieldValue, setTextFieldValue] = useState('');
  const handleTextFieldChange = (event) => {
    const { value } = event.target;
    setTextFieldValue(value);
    
    if (value === 'Delete Account') {
      setIsDeleteAccount(true);
    } else {
      setIsDeleteAccount(false);
    }
  };

  const [user, setUser] = useState({
    username: '',
    password: '',
    role: 'Garbage Collector', // Default role
    picture: '',
  });

  

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/users/${displayID}`);
        const userData = response.data;
        setUser(userData);
      } catch (err) {
        console.log(err);
      }
    };

    // Check if displayID is defined before making the request
    if (displayID) {
      fetchUserData();
    }
  }, [displayID]); // Change id to displayID

  const [open, setOpen] = useState(null);

  const handleOpen = (event) => {
    setOpen(event.currentTarget);
  };

  const handleClose = () => {
    setOpen(null);
  };

  const handleLogout = () => {
    // Perform any necessary logout actions
    setOpen(null);
    // Redirect to the desired location
    window.location.href = "/landing";
    axios.put(`http://localhost:8080/update-status-off/${displayID}`);



  };

  //delete
  const handleDelete = async () => {
    try {
      await Promise.all(
        selected.map(async (id) => {
          // Delete user based on the username
          await axios.delete(`http://localhost:8080/users/${displayID}`);
        })
      );
  
      setSelected([]);
      window.location.href ='/landing';
  
    } catch (err) {
      console.error(err);
    }
  };
  const handleSwitchToggle = () => {
    setIsDeleteAccount(!isDeleteAccount);
    handleDelete();
  };





  //Settings data

  useEffect(() => {
    const fetchSettingsData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/Settings`);
        const settData = response.data[0];
        setUpdatesett(settData);
      } catch (err) {
        console.log(err);
      }
    };

    fetchSettingsData();
  }, []); // Empty dependency array to execute only once on mount


 
  //Settings Update

  const [updatesett, setUpdatesett] = useState({
    start_time: '',
    end_time: '',
    Standard:'',
    professional: '',
    Enterprise: '',
  });
  const SettingChange = async (e) => {
    e.preventDefault();
    try {
        console.log('Request Payload:', updatesett); // Log user data
        await axios.put(`http://localhost:8080/SettingsUpdate`, updatesett);
        console.log('Settings updated successfully');
    } catch (err) {
        console.error('Failed to update settings:', err);
    }

    setSettingsPopoverOpen(false)
};



const handleSetting = (e) => {
  const { name, value } = e.target;

  setUpdatesett((prev) => ({
    ...prev,
    [name]: value,
  }));
};

// Store user role in local storage
localStorage.setItem('userRole', user.role);

  return (
    <>
      <IconButton
        onClick={handleOpen}
        sx={{
          p: 0,
          ...(open && {
            '&:before': {
              zIndex: 1,
              content: "''",
              width: '100%',
              height: '100%',
              borderRadius: '50%',
              position: 'absolute',
              bgcolor: (theme) => alpha(theme.palette.grey[900], 0.8),
            },
          }),
        }}
      >
        <Avatar src={user.picture} alt="photoURL" />
      </IconButton>

      <Popover
        open={Boolean(open)}
        anchorEl={open}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        PaperProps={{
          sx: {
            p: 0,
            mt: 1.5,
            ml: 0.75,
            width: 180,
            '& .MuiMenuItem-root': {
              typography: 'body2',
              borderRadius: 0.75,
            },
          },
        }}
      >
        <Box sx={{ my: 1.5, px: 2.5 }}>
          <Typography variant="subtitle2" noWrap>
            {user.username}
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }} noWrap>
            {user.role}
          </Typography>
        </Box>

        <Divider sx={{ borderStyle: 'dashed' }} />

        <Stack sx={{ p: 1 }}>
  {MENU_OPTIONS.map((option) => (
    <MenuItem
      key={option.label}
      onClick={() => {
        handleClose();
        switch (option.label) {
          case 'Home':
            window.location.href = "/dashboard";
            break;
          case 'Profile':
            // Navigate to profile page
            if (user.role === 'Customer') {
              window.location.href = `/dashboard/CustomerUpdate/${displayID}`;
            } else {
              window.location.href = `/dashboard/update/${displayID}`;
            }
            
            break;
          case 'Settings':
            setSettingsPopoverOpen(true);
            break;
          default:
            break;
        }
      }}
    >
      {option.label}
    </MenuItem>
  ))}
</Stack>


        <Divider sx={{ borderStyle: 'dashed' }} />

        <MenuItem onClick={handleLogout} sx={{ m: 1 }}>
          Logout 
        </MenuItem>
      </Popover>
      <Popover
        open={settingsPopoverOpen}
        onClose={() => setSettingsPopoverOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        transformOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        PaperProps={{
          sx: {
            p: 0,
            mt: 1.5,
            ml: 0.75,
            width: 180,
            '& .MuiMenuItem-root': {
              typography: 'body2',
              borderRadius: 0.75,
            },
          },
        }}
      >
        {/* Settings Popover Content */}
       
        <Box sx={{ my: 1.5, px: 2.5 }}>
          <Typography variant="subtitle2" noWrap>
          Settings Content
          </Typography>
          <Divider sx={{ borderStyle: 'dashed' }} />


        
          <FormGroup>
<br />
{user.role === 'Admin' && (
  <>
    <TextField
      name="start_time"
      label="Start Time"
      value={updatesett.start_time}
      onChange={handleSetting}
    />
    <br />
    <TextField
      name="end_time"
      label="End Time"
      onChange={handleSetting}
      value={updatesett.end_time} 
    />
    <br />
    <Divider sx={{ borderStyle: 'dashed' }} />
    <br />
    <TextField
      name="Standard"
      label="Standard"
      onChange={handleSetting}
      value={updatesett.Standard } 
    />
    <br />
    <TextField
      name="professional"
      label="Professional"
      onChange={handleSetting}
      value={updatesett.professional} 
    />
    <br />
    <TextField
      name="Enterprise"
      label="Enterprise"
      onChange={handleSetting}
      value={updatesett.Enterprise} 
    />
    <br />
    <Divider sx={{ borderStyle: 'dashed' }} />
    <br />
    <Button onClick={SettingChange} variant='contained'> Done</Button>
  </>
)}

 <br />
      <Divider sx={{ borderStyle: 'dashed' }} />
      <FormControlLabel
        control={<Switch checked={isDeleteAccount} onChange={handleSwitchToggle} />}
        label="Delete Account"
        disabled={!isDeleteAccount}
      />
      <TextField
        value={textFieldValue}
        onChange={handleTextFieldChange}
        placeholder="Delete Account"
      />
     
    </FormGroup>
        </Box>
      </Popover>
    </>
  );
}
