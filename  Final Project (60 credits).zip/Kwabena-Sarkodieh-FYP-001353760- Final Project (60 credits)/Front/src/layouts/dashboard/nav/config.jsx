// component
import SvgColor from '../../../components/svg-color';

// ----------------------------------------------------------------------

const icon = (name) => <SvgColor src={`/assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />;



const navConfig = [
  {
    title: 'dashboard',
    path: '/dashboard/app',
    icon: icon('ic_analytics'),
  },
  // {
  //   title: 'Expo',
  //   path: '/dashboard/Expo',
  //   icon: icon('ic_analytics'),
  // },
  {
    title: 'employees',
    path: '/dashboard/user',
    icon: icon('Emp'),
  },
  {
    title: 'customers',
    path: '/dashboard/Customers',
    icon: icon('ic_user'),
  },
  {
    title: 'Vehicle',
    path: '/dashboard/vehicle',
    icon: icon('car'),
  },
  {
    title: 'Fuel Logs',
    path: '/dashboard/FuelLog',
    icon: icon('fuel'),
  },
  {
    title: 'Collection Records',
    path: '/dashboard/CollectionRec',
    icon: icon('log'),
  },
  {
    title: 'Locations',
    path: '/dashboard/Location',
    icon: icon('location'),
  },
  {
    title: 'GPS',
    path: '/dashboard/GPS',
    icon: icon('gps'),
  },
  {
    title: 'Issue',
    path: '/dashboard/Issue',
    icon: icon('prob'),
  },
  {
    title: 'Report',
    path: '/dashboard/Report',
    icon: icon('stat'),
  },
  // {
  //   title: 'product',
  //   path: '/dashboard/products',
  //   icon: icon('ic_cart'),
  // },
  // {
  //   title: 'blog',
  //   path: '/dashboard/blog',
  //   icon: icon('ic_blog'),
  // },
  // {
  //   title: 'login',
  //   path: '/login',
  //   icon: icon('ic_lock'),
  // },
  // {
  //   title: 'Not found',
  //   path: '/404',
  //   icon: icon('ic_disabled'),
  // },
];

export default navConfig;
