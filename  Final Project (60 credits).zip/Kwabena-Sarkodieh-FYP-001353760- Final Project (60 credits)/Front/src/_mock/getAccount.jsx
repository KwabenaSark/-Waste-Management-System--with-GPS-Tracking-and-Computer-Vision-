// // Assuming you have included Axios in your project
// // You can install it using: npm install axios
// // Or include it from a CDN

// import axios from "axios";


// const displayID = localStorage.getItem('displayID');

// // Make a GET request to fetch user data using Axios


// axios.get(`http://localhost:8080/users/${displayID}`)
//   .then(response => {
//     // Assuming the response.data contains the user information
//     const userData = response.data;

//     // Store the user data in another local storage
//     localStorage.setItem('userData', JSON.stringify(userData));

//     // Redirect to another page or do whatever you need with the data
//     // Example: window.location.href = '/another-page.html';
//   })
//   .catch(error => {
//     console.error('Error fetching user data:', error);
//   });
