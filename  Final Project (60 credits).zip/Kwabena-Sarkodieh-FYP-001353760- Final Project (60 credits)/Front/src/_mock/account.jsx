import axios from "axios";




const displayID = localStorage.getItem('displayID');
const userData = JSON.parse(localStorage.getItem('userData'));

// Log the user data
console.log('User Data:', userData);

const account = {
  displayName: `${displayID}`,
  email: `${'User Data:' + userData}`,
  photoURL: '/assets/images/avatars/avatar_25.jpg',
};

export default account;
