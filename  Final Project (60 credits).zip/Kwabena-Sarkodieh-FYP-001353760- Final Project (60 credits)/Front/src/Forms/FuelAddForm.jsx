import React, { useEffect, useState,useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Stack, TextField ,Modal, Typography,Button  } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import axios from 'axios';

export default function FuelAddForm() {
  const navigate = useNavigate();

  const [cost, setcost] = useState("");
  const [note, setnote] = useState("");
  const [regStatus, setRegStatus] = useState("");
  const [assignedVehicleID, setAssignedVehicleID] = useState(null);
  const [CurrentUserID, setCurrentUserID] = useState(localStorage.getItem('displayID'));

  useEffect(() => {
    const fetchAssignedVehicleID = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/findVehicleID/${localStorage.getItem('displayID')}`);
        setAssignedVehicleID(response.data.vehicle_id);
      } catch (error) {
        console.error('Error fetching AssignedVehicleID:', error);
      }
    };

    fetchAssignedVehicleID();
  }, []);

  const CurrentDate = new Date().toISOString().slice(0, 19).replace("T", " ");
  

  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);

  const [photoFile, setPhotoFile] = useState(null);
  const videoRef = useRef(null);

  useEffect(() => {
    if (isCameraOpen) {
      openCamera();
    }
  }, [isCameraOpen]);

  const handleFileChange = (e) => {
    setPhotoFile(e.target.files[0]);
  };

  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const closeCamera = () => {
    const stream = videoRef.current.srcObject;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
    }
    setIsCameraOpen(false);
  };

  const takePhotoAndUpload = () => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

    const imageUrl = canvas.toDataURL('image/png');
    setCapturedImage(imageUrl);

    const stream = videoRef.current.srcObject;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
    }

    setIsCameraOpen(false);
  };

  const register = () => {
    const formData = new FormData();
    formData.append("VehicleID", assignedVehicleID);
    formData.append("cost", cost);
    formData.append("date",  CurrentDate);
    formData.append("note", note);
    formData.append("UserID", CurrentUserID);

    if (capturedImage) {
      // Convert data URL to Blob
      const blob = dataURLtoBlob(capturedImage);
      const file = new File([blob], 'captured_photo.png');
      formData.append("Proof", file);
    } else if (photoFile) {
      formData.append("Proof", photoFile);
    }

    axios.post("http://localhost:8080/addFuel", formData)
      .then((response) => {
        console.log(response + "help me");
        setRegStatus(response.data.message);

        if (response.data.message === 'Fuel log Added successfully') {
          navigate('/dashboard/FuelLog');
        }
      });
  };

  const dataURLtoBlob = (dataurl) => {
    const arr = dataurl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
  };

  return (
    <>
      <Stack spacing={3}>
        <TextField
          name="cost"
          label="cost"
          onChange={(e) => setcost(e.target.value)}
        />
        <TextField
          name="note"
          label="note"
          onChange={(e) => setnote(e.target.value)}
        />

<Stack direction="row" spacing={2}>
          <TextField
            type="file"
            name="Proof"
            label="Upload Photo"
            focused
            onChange={handleFileChange}
          />
          <Typography>or</Typography>
          <Button variant="contained" onClick={() => setIsCameraOpen(true)}>
            Open Camera
          </Button>
        </Stack>
      </Stack>

      <br />

      <LoadingButton fullWidth size="large" type="submit"
       variant="contained" onClick={register}>
        Add Fuel Log
      </LoadingButton>

      <h1>{regStatus}</h1>
      {/* Camera Modal */}
      <Modal open={isCameraOpen} onClose={closeCamera}>
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '20px' }}>
          <video ref={videoRef} autoPlay playsInline muted></video>
          <p>Camera Preview</p>
          <Button variant="contained" onClick={takePhotoAndUpload}>
            Capture
          </Button>
        </div>
      </Modal>
    </>
  );
}
