import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {
  Stack,
  IconButton,
  InputAdornment,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Avatar,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';

import axios from 'axios';


export default function VehicleUpdateForm() {
  const navigate = useNavigate();
  const { VehicleID } = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    Model: '',
    VehicleType: '',
    RegistrationNumber:'',
    Color: '',
    Image: '',
    // Last_Maintenance: '', 
    Maintenance_History:''
  });

  
  const [regStatus, setRegStatus] = useState("");

 

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/vehicle/${VehicleID}`);
        const userData = response.data;
        setUser(userData);
       
      } catch (err) {
        console.log(err);
      }
    };
    console.log(VehicleID,'help') 

    // Check if id is defined before making the request
    if (VehicleID) {
      fetchUserData();
    }
  }, [VehicleID]);







  const handleChange = (e) => {
    const { name, value } = e.target;
  
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  
  const handleClick = async (e) => {
    e.preventDefault();
    try {
      const updatedUser = {
        ...user,
        Last_Maintenance: new Date().toISOString().slice(0, 19).replace("T", " "),
      };
  
      console.log('Request Payload:', updatedUser); // Log updated user data
  
      await axios.put(`http://localhost:8080/vehicle/${VehicleID}`, updatedUser);
      setRegStatus('Update successful!');
      navigate('/dashboard/vehicle');
    } catch (err) {
      console.log(err);
      setRegStatus('Update failed. Please try again.');
    }
  };
  

  
  

  return (
    <>
      <Stack spacing={3}>
      

        <TextField
          name="Model"
          label="Model"
          onChange={handleChange} value={user.Model} 
        />
        <TextField
          name="VehicleType"
          label="Vehicle Type"
          onChange={handleChange} value={user.VehicleType} 
        />
        <TextField
          name="RegistrationNumber"
          label="Registration Number"
          onChange={handleChange} value={user.RegistrationNumber} 
        />
        <TextField
          name="Color"
          label="Color"
          onChange={handleChange} value={user.Color} 
        />
        <TextField
          name="Image"
          label="Image"
          onChange={handleChange} value={user.Image} 
        />
         <TextField
          name="Maintenance_History"
          label="Maintenance History"
          onChange={handleChange} value={user.Maintenance_History} 
        />
     
      </Stack>

    
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
