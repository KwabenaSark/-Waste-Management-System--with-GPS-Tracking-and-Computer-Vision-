import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Stack,
  TextField,
  MenuItem,
  RadioGroup,
  FormControl,
  FormControlLabel,
  Radio,
  Button,
  Typography // Import Button component from MUI
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import axios from 'axios';

export default function LocationAddForm() {
  const navigate = useNavigate();
  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const [user_full_name, setuser_full_name] = useState("");
  const [email, setemail] = useState("");
  const [phone_number, setphone_number] = useState("");
  const [address, setaddress] = useState("");
  const [Location, setLocation] = useState("");
  const [Long, setLong] = useState("");
  const [Lat, setLat] = useState("");
  const [Desc, setDesc] = useState("");
  const [Schedule, setSchedule] = useState("");
  const [Status, setStatus] = useState("");
  const [Frequency, setFrequency] = useState("");
  const [Customer, setCustomer] = useState("");
  const [regStatus, setRegStatus] = useState("");

  const StatusValue = "Active"

  // Function to fetch latitude and longitude from Positionstack
  const fetchLatLong = async () => {
    try {
      const response = await axios.get(
        `http://api.positionstack.com/v1/forward?access_key=9313ecc646b732dd5200fb4636bb1c6d&query=${Location}`
      );

      const { data } = response;
      if (data.data.length > 0) {
        const { latitude, longitude } = data.data[0];
        setLat(latitude);
        setLong(longitude);
      } else {
        // Handle the case where no location data is found
        console.error('No location data found for the given query.');
      }
    } catch (error) {
      console.error('Error fetching location data:', error);
    }
  };

  const fetchCurrentLocation = () => {
    // Logic to fetch current location goes here
    navigator.geolocation.getCurrentPosition((position) => {
      setLat(position.coords.latitude);
      setLong(position.coords.longitude);
    }, (error) => {
      console.error('Error fetching current location:', error);
    });
  };

  const register = () => {
    // Call the fetchLatLong function before making the POST request
    fetchLatLong();

    // Continue with the rest of your registration logic
    axios.post("http://localhost:8080/addGPS", {
      username: username,
      password: password,
      full_name: user_full_name,
      email: email,
      phone_number: phone_number,
      address: address,
      Location_Name: Location,
      Longitude: Long,
      Latitude: Lat,
      Description: Desc,
      customer_name: user_full_name,
      Schedule: Schedule,
      Status: StatusValue,
      Frequency: Frequency,
      role: 'Customer'
    }).then((response) => {
      console.log(response + "help");
      setRegStatus(response.data.message);

      if (response.data.message === 'Insert successful!') {
        navigate('/dashboard/Location');
      }
    });
  };

  return (
    <>
      <Stack spacing={3}>
        <TextField
          name="username"
          label="username"
          onChange={(e) => setusername(e.target.value)}
        />
        <TextField
          name="password"
          label="password"
          onChange={(e) => setpassword(e.target.value)}
        />
        <TextField
          name="user_full_name"
          label="user_full_name"
          onChange={(e) => setuser_full_name(e.target.value)}
        />
        <TextField
          name="email"
          label="email"
          onChange={(e) => setemail(e.target.value)}
        />
        <TextField
          name="phone_number"
          label="phone_number"
          onChange={(e) => setphone_number(e.target.value)}
        />
        <TextField
          name=" address"
          label=" address"
          onChange={(e) => setaddress(e.target.value)}
        />

<Stack direction="row" spacing={2}>
<TextField
          name="Location_Name"
          label="Location"
          onChange={(e) => setLocation(e.target.value)}
        />
          <Typography>or</Typography>
 <Button onClick={fetchCurrentLocation} variant="contained">Use Current Location</Button>
</Stack>
      
        <TextField
          name="Longitude"
          label="Longitude"
          value={Long} // Display the fetched longitude
          readOnly
          disabled
        />
        <TextField
          name="Latitude"
          label="Latitude"
          value={Lat} // Display the fetched latitude
          readOnly
          disabled
        />
        <TextField
          name=" Description"
          label=" Description"
          onChange={(e) => setDesc(e.target.value)}
        />

        <FormControl>
          <TextField
            name="Schedule"
            label="Schedule"
            select
            onChange={(e) => setSchedule(e.target.value)}
          >
            <MenuItem value="Monday">Monday</MenuItem>
            <MenuItem value="Tuesday">Tuesday</MenuItem>
            <MenuItem value="Wednesday">Wednesday</MenuItem>
            <MenuItem value="Thursday">Thursday</MenuItem>
            <MenuItem value="Friday">Friday</MenuItem>
          </TextField>
        </FormControl>

        <FormControl>
          <RadioGroup
            name="Frequency"
            onChange={(e) => setFrequency(e.target.value)}
            row // Display radio buttons horizontally
          >
            <FormControlLabel
              value="Weekly"
              control={<Radio />}
              label="Weekly"
            />
            <FormControlLabel
              value="Bi-Weekly"
              control={<Radio />}
              label="Bi-Weekly"
            />
            <FormControlLabel
              value="Daily"
              control={<Radio />}
              label="Daily"
            />
          </RadioGroup>
        </FormControl>

        {/* Button to fetch current location */}
       
      </Stack>

      <br />

      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={register}>
        Add
      </LoadingButton>

      <h1>{regStatus}</h1>
    </>
  );
}
