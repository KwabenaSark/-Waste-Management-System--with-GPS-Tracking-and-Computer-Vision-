import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Stack,
  IconButton,
  InputAdornment,
  TextField,
  Select,
  MenuItem,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  InputLabel,
  Typography,
  Button
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import axios from 'axios';

export default function CustomerUpdateForm() {
  const navigate = useNavigate();
  const { id } = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    username: '',
    password: '',
    user_full_name: '',
    email: '',
    phone_number: '',
    address: '',
    Location_Name: '',
    Longitude: '',
    Latitude: '',
    Description: '',
    Schedule: '',
    Status: '',
    Frequency: '',
    waste_location_customer_name:'',
  });

  const [regStatus, setRegStatus] = useState('');
  const [lat, setLat] = useState('');
  const [long, setLong] = useState('');

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/customers/${id}`);
        const userData = response.data;
        setUser(userData);
      } catch (err) {
        console.log(err);
      }
    };

    // Check if id is defined before making the request
    if (id) {
      fetchUserData();
    }
  }, [id]);

  // Function to fetch latitude and longitude from Positionstack
  const fetchLatLong = async () => {
    try {
      const response = await axios.get(
        `http://api.positionstack.com/v1/forward?access_key=9313ecc646b732dd5200fb4636bb1c6d&query=${user.Location_Name}`
      );

      const { data } = response;
      if (data.data.length > 0) {
        const { latitude, longitude } = data.data[0];
        setLat(latitude);
        setLong(longitude);
      } else {
        // Handle the case where no location data is found
        console.error('No location data found for the given query.');
      }
    } catch (error) {
      console.error('Error fetching location data:', error);
    }
  };

  const fetchCurrentLocation = () => {
    // Logic to fetch current location goes here
    navigator.geolocation.getCurrentPosition((position) => {
      setUser(prevUser => ({
        ...prevUser,
        Latitude: position.coords.latitude,
        Longitude: position.coords.longitude
      }));
    }, (error) => {
      console.error('Error fetching current location:', error);
    });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleClick = async (e) => {
    e.preventDefault();
    try {
      // Assign user_full_name to waste_location_customer_name
      const updatedUser = {
        ...user,
        waste_location_customer_name: user.user_full_name
      };
      setUser(updatedUser);
  
      console.log('Request Payload:', updatedUser); // Log updated user data
      await axios.put(`http://localhost:8080/customer/${id}`, updatedUser);
      setRegStatus('Update successful!');
      navigate('/dashboard/Customers');
    } catch (err) {
      console.log(err);
      setRegStatus('Update failed. Please try again.');
    }
  };
  
  
  
  

  return (
    <>
      <Stack spacing={3}>
        <TextField
          name="username"
          label="username"
          onChange={handleChange}
          value={user.username}
        />
        <TextField
          name="password"
          label="password"
          onChange={handleChange}
          value={user.password}
        />
        <TextField
          name="user_full_name"
          label="user_full_name"
          onChange={handleChange}
          value={user.user_full_name}
        />
        <TextField
          name="email"
          label="email"
          onChange={handleChange}
          value={user.email}
        />
        <TextField
          name="phone_number"
          label="phone_number"
          onChange={handleChange}
          value={user.phone_number}
        />
        <TextField
          name="address"
          label="address"
          onChange={handleChange}
          value={user.address}
        />
         

<Stack direction="row" spacing={2}>
<TextField
            name="Location_Name"
            label="Location"
            onChange={handleChange}
            value={user.Location_Name}
          />
          <Typography>or</Typography>
          <Button onClick={fetchCurrentLocation} variant="contained">Use Current Location</Button>
        </Stack>
        <TextField
            name="Latitude"
            label="Latitude"
            onChange={handleChange}
            value={user.Latitude}
            readOnly
            disabled
          />
        <TextField
          name="Longitude"
          label="Longitude"
          onChange={handleChange}
          value={user.Longitude}
          readOnly
          disabled
        />

        <TextField
          name="Description"
          label="Description"
          onChange={handleChange}
          value={user.Description}
        />

        <FormControl>
          <InputLabel id="schedule-label">Schedule</InputLabel>
          <Select
            labelId="schedule-label"
            id="schedule"
            name="Schedule"
            value={user.Schedule}
            onChange={handleChange}
          >
            <MenuItem value="Monday">Monday</MenuItem>
            <MenuItem value="Tuesday">Tuesday</MenuItem>
            <MenuItem value="Wednesday">Wednesday</MenuItem>
            <MenuItem value="Thursday">Thursday</MenuItem>
            <MenuItem value="Friday">Friday</MenuItem>
          </Select>
        </FormControl>

        <FormControl>
          <RadioGroup
            name="Frequency"
            value={user.Frequency}
            onChange={handleChange}
            row // Display radio buttons horizontally
          >
            <FormControlLabel value="Weekly" control={<Radio />} label="Weekly" />
            <FormControlLabel value="Monthly" control={<Radio />} label="Monthly" />
          </RadioGroup>
        </FormControl>

        <FormControl>
          <RadioGroup
            name="Status"
            value={user.Status}
            onChange={handleChange}
            row // Display radio buttons horizontally
          >
            <FormControlLabel value="Active" control={<Radio />} label="Marked ON" />
            <FormControlLabel value="Inactive" control={<Radio />} label="Marked OFF" />
          </RadioGroup>
        </FormControl>
      </Stack>

      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
