import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {
    Stack,
    IconButton,
    TextField,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Avatar,
    Typography,
    ListItemText,
    InputAdornment
  } from '@mui/material';
import { LoadingButton } from '@mui/lab';

import axios from 'axios';


export default function CollectionUpdateForm() {
  const navigate = useNavigate();
  const { id } = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    wasteType: '',
    quantity: '',

  });


  const [wasteType, setwasteType] = useState("");
  const [quantity, setquantity] = useState("");
  const [regStatus, setRegStatus] = useState("");
 

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/CollectTextfield/${id}`);
        const userData = response.data;
        setwasteType(userData.wasteType);
        setquantity(userData.quantity);
      } catch (err) {
        console.log(err);
      }
    };

    if (id) {
      fetchUserData();
    }
  }, [id]);







  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === 'wasteType') {
      setwasteType(value);
    } else if (name === 'quantity') {
      setquantity(value);
    }
  };
  
  const handleClick = async (e) => {
    e.preventDefault();
    const updatedUserData = {
      wasteType: wasteType,
      quantity: quantity,
    };

    try {
      console.log('Request Payload:', updatedUserData);
      await axios.put(`http://localhost:8080/updateCollection/${id}`, updatedUserData);
      setRegStatus('Update successful!');
      navigate('/dashboard/CollectionRec');
    } catch (err) {
      console.log(err);
      setRegStatus('Update failed. Please try again.');
    }
  };


  
  

  return (
    <>
      <Stack spacing={3}>
      

      <FormControl fullWidth>
  <InputLabel htmlFor="wasteType">Waste Type</InputLabel>
  <Select
 name="wasteType"
 label="Waste Type"
 value={wasteType}
 onChange={handleChange}
    renderValue={(selected) => {
      if (!selected) {
        return 'Select Waste Type';
      }
      return selected;
    }}
  >
    <MenuItem value="" disabled>
      Select Waste Type
    </MenuItem>
    <MenuItem value="General Waste">
      <ListItemText
        primary={
          <Typography>
            General Waste <span style={{ color: 'grey' }}> (Organic waste, Metal cans, Paper etc )</span>
          </Typography>
        }
      />
    </MenuItem>
    <MenuItem value="Recyclables">
      <ListItemText
        primary={
          <Typography>
            Recyclables <span style={{ color: 'grey' }}> (Aluminum cans, Glass bottles, Plastic etc )</span>
          </Typography>
        }
      />
    </MenuItem>

    <MenuItem value="Bulky Waste">
      <ListItemText
        primary={
          <Typography>
            Bulky Waste <span style={{ color: 'grey' }}> (Furniture, Appliances, Construction debris etc )</span>
          </Typography>
        }
      />
    </MenuItem>
    <MenuItem value="Hazardous Waste">
      <ListItemText
        primary={
          <Typography>
           Hazardous Waste <span style={{ color: 'grey' }}> (Batteries, Paint, Pesticides, Motor oil etc )</span>
          </Typography>
        }
      />
    </MenuItem>
    <MenuItem value=" Electronic Waste">
      <ListItemText
        primary={
          <Typography>
            Electronic Waste <span style={{ color: 'grey' }}> (Computers, Audio and video equipment etc )</span>
          </Typography>
        }
      />
    </MenuItem>


   
    
   
  </Select>
</FormControl>







<TextField
     name="quantity"
     label="Quantity"
     type="number"
     value={quantity}
     onChange={handleChange}
    InputProps={{
      endAdornment: <InputAdornment position="end">Litre</InputAdornment>,
      inputProps: { min: "0" }, // Optionally set a minimum value
    }}
 
  />
     
      </Stack>
<br />
    
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
