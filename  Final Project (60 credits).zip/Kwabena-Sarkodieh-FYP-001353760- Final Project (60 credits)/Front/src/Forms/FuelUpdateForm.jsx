import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {
  Stack,
  IconButton,
  InputAdornment,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Avatar,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';

import axios from 'axios';


export default function FuelUpdateForm() {
  const navigate = useNavigate();
  const { id } = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    cost: '',
    note: '',

  });

  
  const [regStatus, setRegStatus] = useState("");

 

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/Textfield/${id}`);
        const userData = response.data;
        setUser(userData);
       
      } catch (err) {
        console.log(err);
      }
    };
    console.log(id,'help') 

    // Check if id is defined before making the request
    if (id) {
      fetchUserData();
    }
  }, [id]);







  const handleChange = (e) => {
    const { name, value } = e.target;
  
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  

 const handleClick = async (e) => {
  e.preventDefault();
  try {
   console.log('Request Payload:', user); // Log user data
    await axios.put(`http://localhost:8080/updateFuel/${id}`, user);
    setRegStatus('Update successful!');
    navigate('/dashboard/FuelLog');
  } catch (err) {
    console.log(err);
    setRegStatus('Update failed. Please try again.');
  }
};

  
  

  return (
    <>
      <Stack spacing={3}>
      

        <TextField
          name="cost"
          label="cost"
          onChange={handleChange} value={user.cost} 
        />
        <TextField
          name="note"
          label="note"
          onChange={handleChange} value={user.note} 
        />
     
      </Stack>

    
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
