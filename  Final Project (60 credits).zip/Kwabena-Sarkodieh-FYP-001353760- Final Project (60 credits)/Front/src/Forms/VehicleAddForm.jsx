import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Stack,
  TextField,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import axios from 'axios';

export default function VehicleAddForm() {
  const navigate = useNavigate();

  const [model, setModel] = useState("");
  const [vehicleType, setVehicleType] = useState("");
  const [RegNo, setRegNo] = useState("");
  const [Color, setColor] = useState("");
  const [Image, setImage] = useState(null);
  const [regStatus, setRegStatus] = useState("");
  const [Maintenance_History, setMaintenance_History] = useState("");

  // State for Last Maintenance
  const [Last_Maintenance, setLast_Maintenance] = useState(new Date().toISOString().slice(0, 19).replace("T", " "));

  const register = () => {
    axios.post("http://localhost:8080/addVehicle", {
      Model: model,
      VehicleType: vehicleType,
      RegistrationNumber: RegNo,
      Color: Color,
      Image: Image,
      Last_Maintenance: Last_Maintenance, // Use the state value
      Maintenance_History: Maintenance_History
    }).then((response) => {
      console.log(response + "help");
      setRegStatus(response.data.message);

      if (response.data.message === 'Vehicle Added successfully') {
        navigate('/dashboard/vehicle');
      }
    });
  };

  return (
    <>
      <Stack spacing={3}>
        <TextField
          name="Model"
          label="Model"
          onChange={(e) => setModel(e.target.value)}
        />
        <TextField
          name="VehicleType"
          label="Vehicle Type"
          onChange={(e) => setVehicleType(e.target.value)}
        />
        <TextField
          name="RegistrationNumber"
          label="Registration Number"
          onChange={(e) => setRegNo(e.target.value)}
        />
        <TextField
          name="Color"
          label="Color"
          onChange={(e) => setColor(e.target.value)}
        />
        <TextField
          name="Image"
          label="Image"
          onChange={(e) => setImage(e.target.value)}
        />
        <TextField
          name="Maintenance_History"
          label="Maintenance History"
          onChange={(e) => setMaintenance_History(e.target.value)} // Fixed this line
        />
      </Stack>

      <br />

      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={register}>
        Add Vehicle
      </LoadingButton>

      <h1>{regStatus}</h1>
    </>
  );
}
