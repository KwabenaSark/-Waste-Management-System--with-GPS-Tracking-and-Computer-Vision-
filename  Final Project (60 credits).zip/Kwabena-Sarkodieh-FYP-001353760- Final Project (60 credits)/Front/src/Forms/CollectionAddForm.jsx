import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Stack,
  TextField,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import axios from 'axios';
import { MenuItem, Select, InputLabel, FormControl, ListItemText, Typography, InputAdornment } from '@mui/material';
import { useParams } from 'react-router-dom';







export default function CollectionAddForm() {
  const navigate = useNavigate();

  const [wasteType, setwasteType] = useState("");
  const [quantity, setquantity] = useState("");
  const [regStatus, setRegStatus] = useState("");

  const { id } = useParams(); // Extract id from URL params
  console.log(id ,'param')
  const [CurrentUserID, setCurrentUserID] = useState(localStorage.getItem('displayID'));
  const CurrentDate = new Date().toISOString().slice(0, 19).replace("T", " ");

  const register = () => {
  
    axios.post("http://localhost:8080/addCollection", {
        user_id: CurrentUserID,
        wasteType: wasteType,
        quantity: quantity,
        collection_time: CurrentDate,
        locationID: id,
    }).then((response) => {
      console.log(response + "help");
      setRegStatus(response.data.message);

      if (response.data.message === 'Record Added successfully') {
        navigate('/dashboard/location');
      }
    });


    axios.put(`http://localhost:8080/MarkedOff/${id}`);
  };

 


  
  return (
    <>
      <Stack spacing={3}>
      <FormControl fullWidth>
  <InputLabel htmlFor="wasteType">Waste Type</InputLabel>
  <Select
    name="wasteType"
    label="Waste Type"
    value={wasteType}
    onChange={(e) => setwasteType(e.target.value)}
    renderValue={(selected) => {
      if (!selected) {
        return 'Select Waste Type';
      }
      return selected;
    }}
  >
    <MenuItem value="" disabled>
      Select Waste Type
    </MenuItem>
    <MenuItem value="General Waste">
      <ListItemText
        primary={
          <Typography>
            General Waste <span style={{ color: 'grey' }}> (Organic waste, Metal cans, Paper etc )</span>
          </Typography>
        }
      />
    </MenuItem>
    <MenuItem value="Recyclables">
      <ListItemText
        primary={
          <Typography>
            Recyclables <span style={{ color: 'grey' }}> (Aluminum cans, Glass bottles, Plastic etc )</span>
          </Typography>
        }
      />
    </MenuItem>

    <MenuItem value="Bulky Waste">
      <ListItemText
        primary={
          <Typography>
            Bulky Waste <span style={{ color: 'grey' }}> (Furniture, Appliances, Construction debris etc )</span>
          </Typography>
        }
      />
    </MenuItem>
    <MenuItem value="Hazardous Waste">
      <ListItemText
        primary={
          <Typography>
           Hazardous Waste <span style={{ color: 'grey' }}> (Batteries, Paint, Pesticides, Motor oil etc )</span>
          </Typography>
        }
      />
    </MenuItem>
    <MenuItem value=" Electronic Waste">
      <ListItemText
        primary={
          <Typography>
            Electronic Waste <span style={{ color: 'grey' }}> (Computers, Audio and video equipment etc )</span>
          </Typography>
        }
      />
    </MenuItem>


   
    
   
  </Select>
</FormControl>







<TextField
    name="quantity"
    label="Quantity"
    type="number"
    InputProps={{
      endAdornment: <InputAdornment position="end">Litre</InputAdornment>,
      inputProps: { min: "0" }, // Optionally set a minimum value
    }}
    onChange={(e) => setquantity(e.target.value)}
  />
     
      </Stack>

      <br />

      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={register}>
        Add Record
      </LoadingButton>

      <h1>{regStatus}</h1>
    </>
  );
}
