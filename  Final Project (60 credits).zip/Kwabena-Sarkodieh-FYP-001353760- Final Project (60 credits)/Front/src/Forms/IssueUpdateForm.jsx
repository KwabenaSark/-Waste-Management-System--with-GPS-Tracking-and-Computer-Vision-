import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {
  Stack,
  IconButton,
  InputAdornment,
  TextField,
  Select,
  MenuItem,
  
  InputLabel,
  Avatar,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  
} from '@mui/material';
import { LoadingButton } from '@mui/lab';

import axios from 'axios';


export default function IssueUpdateForm() {
  const navigate = useNavigate();
  const { id } = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    IssueType: '',
    Description: '',
    Photo:'',
    solved:'',

  });

  
  const [regStatus, setRegStatus] = useState("");

 

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/IssuesUP/${id}`);
        const userData = response.data;
        setUser(userData);
       
      } catch (err) {
        console.log(err);
      }
    };
    console.log(id,'help') 

    // Check if id is defined before making the request
    if (id) {
      fetchUserData();
    }
  }, [id]);







  const handleChange = (e) => {
    const { name, value } = e.target;
  
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  

 const handleClick = async (e) => {
  e.preventDefault();
  try {
   console.log('Request Payload:', user); // Log user data
    await axios.put(`http://localhost:8080/updateIssues/${id}`, user);
    setRegStatus('Update successful!');
    navigate('/dashboard/issue');
  } catch (err) {
    console.log(err);
    setRegStatus('Update failed. Please try again.');
  }
};



  return (
    <>
      <Stack spacing={3}>
      

     <FormControl>
          <TextField
            name="IssueType"
            label="Issue Type"
            select
            onChange={handleChange} value={user.IssueType} 
          >
            <MenuItem value="Vehicle Issues">Vehicle Issues</MenuItem>
            <MenuItem value="Waste Collection Issues">Waste Collection Issues</MenuItem>
            <MenuItem value="GPS Tracking Issues">GPS Tracking Issues</MenuItem>
            <MenuItem value="Route Optimization Issues"> Route Optimization Issues</MenuItem>
            <MenuItem value="Public Complaints">Public Complaints</MenuItem>
          </TextField>
        </FormControl>


        <TextField
          name="description"
          label="Description"
          onChange={handleChange} value={user.Description} 
          multiline
          maxRows={4}
        />

<Stack direction="row" spacing={2}>
          <TextField
            type="file"
            name="photo"
            label="Upload Photo"
            focused
            onChange={handleChange} value={user.image} 
          />
        </Stack>

        <FormControl>
        <RadioGroup
    name="Frequency"
    onChange={handleChange} value={user.solved}
    row // Display radio buttons horizontally
  >
    <FormControlLabel
      value="Yes"
      control={<Radio />}
      label="Solved"
    />
    <FormControlLabel
      value="No"
      control={<Radio />}
      label="Not Solved"
    />
  </RadioGroup>
  </FormControl>

     

      </Stack>



     

    
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
