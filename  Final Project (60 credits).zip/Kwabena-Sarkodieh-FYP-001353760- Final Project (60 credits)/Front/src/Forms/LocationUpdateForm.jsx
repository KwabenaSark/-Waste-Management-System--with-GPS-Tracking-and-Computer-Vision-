import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {
  Stack,
  IconButton,
  InputAdornment,
  TextField,
  Select,
  MenuItem,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  InputLabel 
} from '@mui/material';
import { LoadingButton } from '@mui/lab';

import axios from 'axios';


export default function LocationUpdateForm() {
  const navigate = useNavigate();
  const { id} = useParams(); // Extract id from URL params

  const [user, setUser] = useState({
    Location_Name: '',
    Longitude: '',
    Latitude:'',
    Description: '',
    Customer_Name: '',
    Schedule: '',
    Status: '',
    Frequency: '',
  });

  const [regStatus, setRegStatus] = useState("");

 

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/LocationTextfield/${id}`);
        const userData = response.data;
        setUser(userData);
       
      } catch (err) {
        console.log(err);
      }
    };
    console.log(id,'help') 

    // Check if id is defined before making the request
    if (id) {
      fetchUserData();
    }
  }, [id]);







  const handleChange = (e) => {
    const { name, value } = e.target;
  
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  

 const handleClick = async (e) => {
  e.preventDefault();
  try {
   console.log('Request Payload:', user); // Log user data
    await axios.put(`http://localhost:8080/updateLocation/${id}`, user);
    setRegStatus('Update successful!');
    navigate('/dashboard/Location');
  } catch (err) {
    console.log(err);
    setRegStatus('Update failed. Please try again.');
  }
};

  
  

  return (
    <>
      <Stack spacing={3}>
      
      <TextField
          name="Location_Name"
          label="Location"
          onChange={handleChange} value={user.Location_Name} 
        />
        <TextField
          name="Longitude"
          label="Longitude"
          onChange={handleChange} value={user.Longitude} // Display the fetched longitude
          readOnly
          disabled
        />
        <TextField
          name="Latitude"
          label="Latitude"
          onChange={handleChange} value={user.Latitude} 
          readOnly
          disabled
        />


<TextField
          name="Description"
          label="Description"
          onChange={handleChange} value={user.Description} 
        />
        <TextField
          name="Customer_Name"
          label="Customer Name"
          onChange={handleChange} value={user.Customer_Name} 
          disabled
        />

<FormControl>

    
  <TextField
    name="Schedule"
    label="Schedule"
    onChange={handleChange}
    value={user.Schedule}
    select
  >
    <MenuItem value="Monday">Monday</MenuItem>
    <MenuItem value="Tuesday">Tuesday</MenuItem>
    <MenuItem value="Wednesday">Wednesday</MenuItem>
    <MenuItem value="Thursday">Thursday</MenuItem>
    <MenuItem value="Friday">Friday</MenuItem>
  </TextField>
</FormControl>

    <FormControl>
      <RadioGroup
        name="Frequency"
      
        onChange={handleChange} value={user.Frequency} 
        row // Display radio buttons horizontally
      >
        <FormControlLabel
          value="Weekly"
          control={<Radio />}
          label="Weekly"
        />
        <FormControlLabel
          value="Monthly"
          control={<Radio />}
          label="Monthly"
        />
      </RadioGroup>
    </FormControl>
  

    <FormControl>
  <RadioGroup
    name="Frequency"
    onChange={handleChange}
    value={user.Status}
    row // Display radio buttons horizontally
  >
    <FormControlLabel
      value="Active"
      control={<Radio />}
      label="Marked ON"
    />
    <FormControlLabel
      value="InActive"
      control={<Radio />}
      label="Marked OFF"
    />
  </RadioGroup>
</FormControl>
     
      </Stack>

    
      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={handleClick}>
        Update
      </LoadingButton>

      {regStatus && <div>{regStatus}</div>}
    </>
  );
}
