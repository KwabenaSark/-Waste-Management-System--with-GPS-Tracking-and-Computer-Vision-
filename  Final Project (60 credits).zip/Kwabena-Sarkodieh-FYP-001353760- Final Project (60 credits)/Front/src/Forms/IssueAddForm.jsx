import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { MenuItem, Stack, TextField, FormControl, Button, Modal, Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import axios from 'axios';


export default function IssueAddForm() {
  const displayID = localStorage.getItem('displayID');
  const [user, setUser] = useState({
    username: '',
    password: '',
    role: '', // Default role
    picture: '',
  });
  useEffect (() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/users/${displayID}`);
        const userData = response.data;
        setUser(userData);
      } catch (err) {
        console.log(err);
      }
    };

    if (displayID) {
      fetchUserData();
    }
  }, [displayID]);

console.log(user.role,'ggg')
  const navigate = useNavigate();

  const [issueType, setIssueType] = useState("");
  const [regStatus, setRegStatus] = useState("");
  const [description, setDescription] = useState("");
  const [currentUserID, setCurrentUserID] = useState(localStorage.getItem('displayID'));
  const currentDate = new Date().toISOString().slice(0, 19).replace("T", " ");
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);

  const [photoFile, setPhotoFile] = useState(null);
  const videoRef = useRef(null);

  useEffect(() => {
    if (isCameraOpen) {
      openCamera();
    }
  }, [isCameraOpen]);

  const handleFileChange = (e) => {
    setPhotoFile(e.target.files[0]);
  };

  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const closeCamera = () => {
    const stream = videoRef.current.srcObject;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
    }
    setIsCameraOpen(false);
  };

  const takePhotoAndUpload = () => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

    const imageUrl = canvas.toDataURL('image/png');
    setCapturedImage(imageUrl);

    const stream = videoRef.current.srcObject;
    if (stream) {
      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());
    }

    setIsCameraOpen(false);
  };

  const register = () => {
    const formData = new FormData();
    formData.append("IssueType", issueType);
    formData.append("Timestamp", currentDate);
    formData.append("Description", description);
    formData.append("User_id", currentUserID);

    if (capturedImage) {
      // Convert data URL to Blob
      const blob = dataURLtoBlob(capturedImage);
      const file = new File([blob], 'captured_photo.png');
      formData.append("Photo", file);
    } else if (photoFile) {
      formData.append("Photo", photoFile);
    }

    axios.post("http://localhost:8080/addissue", formData)
      .then((response) => {
        console.log(response + "help me");
        setRegStatus(response.data.message);

        if (response.data.message === 'Issue Reported') {
          navigate('/dashboard/Issue');
        }
      });
  };

  const dataURLtoBlob = (dataurl) => {
    const arr = dataurl.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
  };

  return (
    <>
      <Stack spacing={3}>
      <FormControl>
  {user.role === "Customer" ? (
    <TextField
      name="issueType"
      label="Issue Type"
      select
      value="Public Complaints"
     
      onChange={(e) => setIssueType(e.target.value)}
    >
      <MenuItem value="Public Complaints">Public Complaints</MenuItem>
    </TextField>
  ) : (
    <TextField
      name="issueType"
      label="Issue Type"
      select
      onChange={(e) => setIssueType(e.target.value)}
    >
      <MenuItem value="Vehicle Issues">Vehicle Issues</MenuItem>
      <MenuItem value="Waste Collection Issues">Waste Collection Issues</MenuItem>
      <MenuItem value="GPS Tracking Issues">GPS Tracking Issues</MenuItem>
      <MenuItem value="Route Optimization Issues">Route Optimization Issues</MenuItem>
      <MenuItem value="Public Complaints">Public Complaints</MenuItem>
    </TextField>
  )}
</FormControl>


        <TextField
          name="description"
          label="Description"
          onChange={(e) => setDescription(e.target.value)}
          multiline
          maxRows={4}
        />

        <Stack direction="row" spacing={2}>
          <TextField
            type="file"
            name="photo"
            label="Upload Photo"
            focused
            onChange={handleFileChange}
          />
          <Typography>or</Typography>
          <Button variant="contained" onClick={() => setIsCameraOpen(true)}>
            Open Camera
          </Button>
        </Stack>
      </Stack>

      <br />

      <LoadingButton fullWidth size="large" type="submit" variant="contained" onClick={register}>
        Report Issue
      </LoadingButton>

      <h1>{regStatus}</h1>

      {/* Camera Modal */}
      <Modal open={isCameraOpen} onClose={closeCamera}>
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'white', padding: '20px' }}>
          <video ref={videoRef} autoPlay playsInline muted></video>
          <p>Camera Preview</p>
          <Button variant="contained" onClick={takePhotoAndUpload}>
            Capture
          </Button>
        </div>
      </Modal>
    </>
  );
}
