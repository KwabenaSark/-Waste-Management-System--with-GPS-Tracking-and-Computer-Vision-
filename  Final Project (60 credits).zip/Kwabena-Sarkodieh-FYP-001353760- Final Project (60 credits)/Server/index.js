import express from "express";
import mysql from 'mysql2';
import cors from 'cors';
import multer from "multer";  // First import

const app = express();


const db = mysql.createConnection({
    host: "localhost",
    port: 3306,
    user: "root",
    password: "12345678",
    database: "test"
});

// Function to execute a query using the connection pool
const queryDatabase = async (query, params) => {
    return new Promise((resolve, reject) => {
        db.query(query, params, (error, results) => {
            if (error) {
                reject(error);
            } else {
                resolve(results);
            }
        });
    });
};

app.use(express.json());
app.use(cors());



// Remove this duplicate import
// const multer = require("multer");
// Increase the limit for both urlencoded and json payloads


// Set up Multer storage
const storage = multer.memoryStorage(); // This stores the file in memory, change as needed
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // Set your desired file size limit (in bytes)
  },
});



app.get("/books",(req,res)=>{
    const q = "SELECT * FROM books"
    db.query(q,(err,data)=>{
        if(err)return res.json("failed to get books")
        return res.json(data)
    })
})

app.post("/books",(req,res)=>{
    const q = "Insert into books (`title`,`desc`, `cover`) values (?)"
    const values = [req.body.title,req.body.desc,req.body.cover]
    db.query(q, [values],(err,data)=>{
        if(err) return json(err)
        return res.json("book created successfully")
    })

})

app.delete("/books/:id",(req,res)=>{
   const bookId = req.params.id;
   const q = "delete from books where id = ? "

    db.query(q, [bookId],(err,data)=>{
        if(err) return json(err)
        return res.json("book deleted successfully")
    })

})

app.put("/books/:id",(req,res)=>{
    const bookId = req.params.id;
    const q = "Update books set `title`= ? ,`desc`= ? , `cover`= ? where id = ?"

    const values = [req.body.title,req.body.desc,req.body.cover]
    
     db.query(q, [...values,bookId],(err,data)=>{
         if(err) return json(err)
         return res.json("book deleted successfully")
     })
 
})


//dashboard

app.put("/Dispose/:id", (req, res) => {
  const userId = req.params.id;
  const { disposal_time } = req.body;

  console.log('Received data:', { disposal_time, userId });

  const q = `
  UPDATE Collection_Records
  SET disposal_time = ?
  WHERE user_id = ? AND disposal_time IS NULL;  
  `;

  db.query(q, [disposal_time, userId], (err) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ error: 'Failed to update user' });
    }

    console.log('Update successful!');
    res.json({ message: 'Update successful!' });
  });
});








//show all users
app.get("/users",(req,res)=>{
    const q = `
    SELECT id, username, password, picture, role,drivers_license_no,
     employment_date, full_name, email, phone_number, status, address,
      vehicle_id, Vehicle 
FROM 
    users
WHERE 
    role <> 'Customer';

`
    db.query(q,(err,data)=>{
        if(err)return res.json("failed to get users")
        return res.json(data)
    })
})





import bcrypt from 'bcrypt';

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT id, username, password FROM users WHERE username = ?",
    [username],
    async (err, result) => {
      if (err) {
        res.status(500).send({ error: err });
      } else {
        if (result.length > 0) {
          const user = result[0];
          // Check if the stored password is hashed or plaintext
          const isHashedPassword = /^\$2[abxy]?\$\d{2}\$[./0-9A-Za-z]{53}$/.test(user.password);

          if (isHashedPassword) {
            // Compare hashed password
            const passwordMatch = await bcrypt.compare(password, user.password);
            if (passwordMatch) {
              res.send({
                message: "Login successful",
                username: user.username,
                userId: user.id,
              });
            } else {
              res.send({ message: "Wrong username/password combination!" });
            }
          } else {
            // Compare plaintext password
            if (password === user.password) {
              res.send({
                message: "Login successful",
                username: user.username,
                userId: user.id,
              });
            } else {
              res.send({ message: "Wrong username/password combination!" });
            }
          }
        } else {
          res.send({ message: "User not found!" });
        }
      }
    }
  );
});








//show in update / user
app.get('/users/:id', (req, res) => {
    const userId = req.params.id;
  
    // Use a parameterized query to prevent SQL injection
    const q = 'SELECT * FROM users WHERE id = ?';
    db.query(q, [userId], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get user' });
      }
  
      if (results.length > 0) {
        const user = results[0];
        res.json(user);
      } else {
        res.status(404).json({ error: 'User not found' });
      }
    });
  });

  

//delete user
app.delete("/users/:id", (req, res) => {
    const id = req.params.id; // Corrected from req.params.id to req.params.username
    const q = "DELETE FROM users WHERE id = ? ";
  
    db.query(q, [id], (err, data) => {
      if (err) return res.json(err);
      return res.json("User deleted successfully");
    });
  });




// Update user
app.put("/users/:id", (req, res) => {
    const userId = req.params.id;
    const { username, password, picture, role, drivers_license_no, employment_date, 
            full_name, email, phone_number, address, vehicle_id, Vehicle } = req.body;

    console.log('Received data:', { username, password, picture, role, drivers_license_no, 
                                   employment_date, full_name, email, phone_number, 
                                   address, vehicle_id, Vehicle, userId });

    const q = `UPDATE users SET username = ?, password = ?, picture = ?, role = ?, 
               drivers_license_no = ?, employment_date = ?, full_name = ?, email = ?, 
               phone_number = ?, address = ?, vehicle_id = ?, Vehicle = ? WHERE id = ?`;

    db.query(q, [username, password, picture, role, drivers_license_no, employment_date, 
                 full_name, email, phone_number, address, vehicle_id, Vehicle, userId], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Failed to update user' });
        }

        res.json({ message: 'Update successful!' });
    });
});


//reg
app.post("/register", (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    const role = req.body.role || 'Garbage Collector'; // Default role if not provided
    const picture = req.body.picture;
    const drivers_license_no = req.body.drivers_license_no;
    const employment_date = req.body.employment_date;
    const full_name = req.body.full_name;
    const email = req.body.email;
    const phone_number = req.body.phone_number;
    const address = req.body.address;
    const vehicle_id = req.body.vehicle_id || null;
    const Vehicle = req.body.Vehicle;
  
    db.query(
      "INSERT INTO users (username, password, role, picture, drivers_license_no, employment_date, full_name, email, phone_number, address, vehicle_id, Vehicle) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [username, password, role, picture, drivers_license_no, employment_date, full_name, email, phone_number, address, vehicle_id, Vehicle],
      (err, result) => {
        if (err) {
          console.error('Error:', err);
          return res.status(500).json({ message: "Registration failed" });
        }
        return res.status(200).json({ message: "Registration successful", data: result });
      }
    );
  });
  
  
//customer

//show customers
app.get("/customers",(req,res)=>{
  const q = `SELECT
  u.id AS user_id,
  u.username,
  u.password,
  u.role,
  u.full_name AS user_full_name,
  u.email,
  u.phone_number,
  u.address,
  u.subscriptions,
  wl.id AS waste_location_id,
  wl.Location_Name,
  wl.Longitude,
  wl.Latitude,
  wl.Description,
  wl.Customer_Name AS waste_location_customer_name,
  wl.Schedule,
  wl.Status,
  wl.Frequency
FROM
  users u
JOIN
  waste_locations wl ON u.full_name = wl.Customer_Name
WHERE
  u.role = 'customer';
`
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})



//show in update / customers
app.get('/customers/:id', (req, res) => {
  const userId = req.params.id;

  // Use a parameterized query to prevent SQL injection
  const q = `SELECT
  u.id AS user_id,
  u.username,
  u.password,
  u.role,
  u.full_name AS user_full_name,
  u.email,
  u.phone_number,
  u.address,
  wl.id AS waste_location_id,
  wl.Location_Name,
  wl.Longitude,
  wl.Latitude,
  wl.Description,
  wl.Customer_Name AS waste_location_customer_name,
  wl.Schedule,
  wl.Status,
  wl.Frequency
FROM
  users u
JOIN
  waste_locations wl ON u.full_name = wl.Customer_Name
WHERE
  u.role = 'customer' AND u.id = ?;
`;
  db.query(q, [userId], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user' });
    }

    if (results.length > 0) {
      const user = results[0];
      res.json(user);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });
});



//delete customer
app.delete("/customers/:id", (req, res) => {
  const id = req.params.id;

  const getUsernameQuery = `
    SELECT full_name FROM users WHERE id = ?
  `;

  db.query(getUsernameQuery, [id], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to retrieve username' });
    }

    if (result.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const username = result[0].username;

    const deleteUserQuery = `
      DELETE FROM users WHERE id = ?
    `;

    const deleteLocationsQuery = `
      DELETE FROM waste_locations WHERE Customer_Name = ?
    `;

    db.query(deleteLocationsQuery, [username], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to delete location data' });
      }

      db.query(deleteUserQuery, [id], (err) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ error: 'Failed to delete user data' });
        }

        res.json({ message: 'User and associated data deleted successfully' });
      });
    });
  });
});





// Update customer
app.put("/customer/:id", (req, res) => {
  const userId = req.params.id;
  const { username, password, role, user_full_name, email, phone_number, address, waste_location_id, Location_Name, Longitude, Latitude, Description, waste_location_customer_name, Schedule, Status, Frequency } = req.body;

  console.log('Received data:', { userId, username, password, role, user_full_name, email, phone_number, address, waste_location_id, Location_Name, Longitude, Latitude, Description, waste_location_customer_name, Schedule, Status, Frequency });

  const userUpdateQuery = `UPDATE users u
                           JOIN waste_locations wl ON u.full_name = wl.Customer_Name
                           SET 
                             u.username = ?, 
                             u.password = ?, 
                             u.role = ?, 
                             u.full_name = ?, 
                             u.email = ?, 
                             u.phone_number = ?, 
                             u.address = ?, 
                             wl.Location_Name = ?, 
                             wl.Longitude = ?, 
                             wl.Latitude = ?, 
                             wl.Description = ?, 
                             wl.Customer_Name = ?, 
                             wl.Schedule = ?, 
                             wl.Status = ?, 
                             wl.Frequency = ? 
                           WHERE 
                             u.id = ?`;

  db.query(userUpdateQuery, [username, password, role, user_full_name, email, phone_number, address, Location_Name, Longitude, Latitude, Description, waste_location_customer_name, Schedule, Status, Frequency, userId], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update user and waste location' });
    }

    res.json({ message: 'Update successful!' });
  });
});




//Customer Account Creation




app.post("/CusCreate", async (req, res) => {
  const { 
    username, password, role, full_name, email, phone_number, address, 
    Location_Name, Longitude, Latitude, Description, customer_name, 
    Schedule, Frequency, Status ,subscriptions,price
  } = req.body;

  console.log('Received data:', { 
    username, role, full_name, email, phone_number, address, 
    Location_Name, Longitude, Latitude, Description, customer_name, 
    Schedule, Frequency, Status ,subscriptions,price
  });

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10); // 10 is the salt rounds

    const userInsertQuery = `
      INSERT INTO users (username, password, role, full_name, email, phone_number, address,subscriptions,price)
      VALUES (?, ?, ?, ?, ?, ?, ?,?,?)
    `;

    const locationInsertQuery = `
      INSERT INTO waste_locations (Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(userInsertQuery, [username, hashedPassword, role, full_name, email, phone_number, address,subscriptions,price], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to insert user data' });
      }

      db.query(locationInsertQuery, [Location_Name, Longitude, Latitude, Description, customer_name, Schedule, Status, Frequency], (err) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ error: 'Failed to insert location data' });
        }

        res.send({ message: 'Insert successful!' });
      });
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to hash password' });
  }
});





// reg vehicle options
app.get("/vehicle-options",(req,res)=>{
    const q = "SELECT DISTINCT VehicleID, Model  FROM Vehicle WHERE NOT EXISTS (  SELECT 1 FROM Users  WHERE Users.Vehicle = Vehicle.Model )"
    db.query(q,(err,data)=>{
        if(err)return res.json("failed to get users")
        return res.json(data)
    })
})

// update with vehicle in use
app.get("/vehicle-in-use",(req,res)=>{
    const q = "SELECT DISTINCT Vehicle.VehicleID, Vehicle.Model FROM Vehicle WHERE Vehicle.Model IN (SELECT DISTINCT Users.Vehicle FROM Users WHERE Users.Vehicle IS NOT NULL); "
    db.query(q,(err,data)=>{
        if(err)return res.json("failed to get users")
        return res.json(data)
    })
})


//delete user Vehicle that has been reasigned
app.put("/v-assign/:id", (req, res) => {
    const vehicle_id = req.params.id;
  
    // Find the user_id associated with the given vehicle_id
    const findUserQuery = "SELECT id FROM users WHERE vehicle_id = ?";
    db.query(findUserQuery, [vehicle_id], (err, result) => {
      if (err) {
        return res.json(err);
      }
  
      if (result.length === 0) {
        return res.json("Vehicle not found");
      }
  
      const user_id = result[0].id;
  
      // Update the user's vehicle_id and Vehicle to NULL
      const updateQuery = "UPDATE users SET vehicle_id = NULL, Vehicle = NULL WHERE id = ?";
      db.query(updateQuery, [user_id], (err, data) => {
        if (err) {
          return res.json(err);
        }
  
        return res.json("Reassigned deleted successfully");
      });
    });
  });
  

  

  //user status on
  app.put("/update-status/:id", (req, res) => {
    const userId = req.params.id;
    
    // Update the status to 'YES' for the user with the specified ID
    const updateQuery = "UPDATE users SET status = 'YES' WHERE id = ?";
    
    db.query(updateQuery, [userId], (err, result) => {
      if (err) {
        console.error('Error updating status: ' + err.message);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
  
      if (result.affectedRows === 0) {
        // If no rows were affected, the user with the specified ID was not found
        return res.status(404).json({ error: 'User not found' });
      }
  
      // Status updated successfully
      return res.json({ message: 'Status updated to YES' });
    });
  });

  //user status off
  app.put("/update-status-off/:id", (req, res) => {
    const userId = req.params.id;
    
    // Update the status to 'YES' for the user with the specified ID
    const updateQuery = "UPDATE users SET status = 'NO' WHERE id = ?";
    
    db.query(updateQuery, [userId], (err, result) => {
      if (err) {
        console.error('Error updating status: ' + err.message);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
  
      if (result.affectedRows === 0) {
        // If no rows were affected, the user with the specified ID was not found
        return res.status(404).json({ error: 'User not found' });
      }
  
      // Status updated successfully
      return res.json({ message: 'Status updated to YES' });
    });
  });








//vehicle
//show all vehicles
app.get("/vehicle", (req, res) => {
  const q = "SELECT * FROM vehicle";

  db.query(q, (err, data) => {
    if (err) {
      return res.json("failed to get vehicles");
    }

    // Convert the blob field to a base64-encoded string
    const result = data.map(item => {
      return {
        ...item,
        image: item.image.toString("base64"),
      };
    });

    return res.json(result);
  });
});



  
//add Vehicle
app.post("/addVehicle", (req, res) => {
    const Model = req.body.Model;
    const VehicleType = req.body.VehicleType
    const RegistrationNumber = req.body.RegistrationNumber
    const Image = req.body.Image;
    const Color = req.body.Color;
    const  Last_Maintenance =  req.body.Last_Maintenance;
    const  Maintenance_History =  req.body.Maintenance_History;
    db.query(
      "INSERT INTO vehicle (Model, VehicleType, RegistrationNumber, Color , Image, Last_Maintenance, Maintenance_History) VALUES (?,?,?,?,?,?,?)",
      [Model, VehicleType, RegistrationNumber, Color, Image, Last_Maintenance, Maintenance_History],
      (err, result) => {
        console.log('error is ' +  err);
        if (err) return res.json(err);
        return res.send({ message: "Vehicle Added successfully", data: result });
      }
    );
  });
  

//Delete Vehicle
app.delete("/vehicle/:VehicleID", (req, res) => {
    const VehicleID = req.params.VehicleID;
    const q = "DELETE FROM vehicle WHERE VehicleID = ? ";
  
    db.query(q, [VehicleID], (err, data) => {
      if (err) return res.json(err);
      return res.json("Vehicle deleted successfully");
    });
  });
  




//show in update / Vehicle
app.get('/vehicle/:VehicleID', (req, res) => {
    const vehicleID = req.params.VehicleID;
  
    // Use a parameterized query to prevent SQL injection
    const q = 'SELECT * FROM vehicle WHERE VehicleID = ?';
    db.query(q, [vehicleID], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get user' });
      }
  
      if (results.length > 0) {
        const user = results[0];
        res.json(user);
      } else {
        res.status(404).json({ error: 'User not found' });
      }
    });
  });


// Update Vehicle
app.put("/vehicle/:VehicleID", (req, res) => {
  const VehicleID = req.params.VehicleID;

  // Extract values from the request body
  const { Model, VehicleType, RegistrationNumber, Color, Image, Last_Maintenance, Maintenance_History } = req.body;

  // Log the received data for debugging
  console.log('Received data:', { Model, VehicleType, RegistrationNumber, Color, Image, VehicleID, Last_Maintenance, Maintenance_History });

  const q = 'UPDATE vehicle SET Model = ?, VehicleType = ?, RegistrationNumber = ?, Color = ?, Image = ?, Last_Maintenance = ?, Maintenance_History = ? WHERE VehicleID = ?';

  db.query(q, [Model, VehicleType, RegistrationNumber, Color, Image, Last_Maintenance, Maintenance_History, VehicleID], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update vehicle' });
    }

    res.json({ message: 'Update successful!' });
  });
});

  




app.get("/",(req,res)=>{
    res.json("hello world")
})

app.listen(8080, ()=>{
   console.log("Connect to backend lol noew i setyy") 
}) 


 



//Fuel Log

//Fuel Log Role permissions
app.post('/check_role/:id', async (req, res) => {
    const { id } = req.params;  // Use req.params to get the value from the URL parameter
  
    if (!id) {
      return res.status(400).json({ error: 'Missing user ID' });
    }
  
    try {
      // Query the database to get the user's role
      const query = 'SELECT role FROM users WHERE id = ?';
      const result = await queryDatabase(query, [id]);
  
      if (result.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      const role = result[0].role;
  
      // Check the user's role and respond accordingly
      if (role === 'Admin') {
        return res.json({ status: 'allow' });
      } else if (role === 'Garbage Collector') {
        return res.json({ status: 'dont allow' });
      } else {
        return res.status(403).json({ error: 'Unknown role' });
      }
    } catch (error) {
      console.error('Error querying database:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }




    
  });
  
  
//show all Fuel logs with the vehicle and car
app.get("/Fuel", (req, res) => {
  const q = "SELECT fl.id AS fuel_log_id, fl.cost, fl.date, fl.Photo, fl.note, u.vehicle, u.username FROM fuel_logs fl JOIN users u ON fl.VehicleID = u.vehicle_id WHERE fl.UserID = u.id ";

  db.query(q, (err, data) => {
      if (err) return res.json("failed to get users");

      // Convert Photo field from Blob to Base64
      const dataWithBase64 = data.map(item => ({
          ...item,
          Photo: item.Photo ? `data:image/jpeg;base64,${item.Photo.toString('base64')}` : null, // Add check for empty or null Photo field
      }));

      return res.json(dataWithBase64);
  });
});




//delele Fuel Log
app.delete("/Fuel/:id", (req, res) => {
    const id = req.params.id; // Corrected from req.params.id to req.params.username
    const q = "DELETE FROM Fuel_logs WHERE id = ? ";
  
    db.query(q, [id], (err, data) => {
      if (err) return res.json(err);
      return res.json("Fuel deleted successfully");
    });
  });


//, upload.single("Photo"),
// const Photo = req.file.buffer; // Access the file buffer

//Add Fuel Log
app.post("/addFuel", upload.single("Proof"), (req, res) => {
  const { VehicleID, cost, date, note, UserID } = req.body;
  const Photo = req.file ? req.file.buffer : null; // Check if file exists
  if (!VehicleID || !cost || !date || !note || !UserID) {
      return res.status(400).json({ error: "Missing required fields" });
  }

  db.query(
      "INSERT INTO Fuel_logs (VehicleID, cost, date, note, UserID, Photo) VALUES (?, ?, ?, ?, ?, ?)",
      [VehicleID, cost, date, note, UserID, Photo],
      (err, result) => {
          if (err) {
              console.error("Error adding fuel log:", err);
              return res.status(500).json({ error: "Internal server error" });
          }
          return res.status(201).json({ message: "Fuel log added successfully", data: result });
      }
  );
});



  //Get Assigned vehicleID from Users for Auto Fuel Log vehicleID
  app.get('/findVehicleID/:id', (req, res) => {
    const id = req.params.id;
  
    // Use a parameterized query to prevent SQL injection
    const q = 'SELECT vehicle_id FROM Users where id = ? ';
    db.query(q, [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get vehicle_id' });
      }
  
      if (results.length > 0) {
        const user = results[0];
        res.json(user);
      } else {
        res.status(404).json({ error: 'id not found' });
      }
    });
  });



//show in fuel log in Update textfields
app.get('/Textfield/:id', (req, res) => {
    const id = req.params.id;
  
    // Use a parameterized query to prevent SQL injection
    const q = 'SELECT * FROM Fuel_logs WHERE id = ?';
    db.query(q, [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get user' });
      }
  
      if (results.length > 0) {
        const user = results[0];
        res.json(user);
      } else {
        res.status(404).json({ error: 'User not found' });
      }
    });
  });

// Update Fuel
app.put("/updateFuel/:id", (req, res) => {
    const id = req.params.id;
  
    // Extract values from the request body
    const { cost, note} = req.body;
  
    // Log the received data for debugging
    console.log('Received data:', {  cost, note });
  
    const q = 'UPDATE Fuel_logs SET cost = ?, note = ?  WHERE id  = ?';
  
    db.query(q, [ cost, note, id ], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to update vehicle' });
      }
  
      res.json({ message: 'Update successful!' });
    });
  });

//Fuel log display for only user role garbage collector

app.get("/FuelSecond/:userId", (req, res) => {
    const userId = req.params.userId;
  
    const q = "SELECT fl.id AS fuel_log_id, fl.cost, fl.date, fl.note, u.vehicle, u.username FROM fuel_logs fl JOIN users u ON fl.VehicleID = u.vehicle_id WHERE fl.UserID = ?";
  
    db.query(q, [userId], (err, data) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to get fuel logs' });
      }
  
      return res.json(data);
    });
  });
  

//Fuel Pop
app.get("/Fuelpop/:id", (req, res) => {
  const id = req.params.id;

  const q = `
  SELECT * FROM Fuel_logs WHERE id = ?
  `;

  db.query(q, [id], (err, data) => {
    if (err) {
      return res.status(500).json({ error: "Failed to get data" });
    }

    if (data.length === 0) {
      return res.status(404).json({ error: "Data not found" });
    }

    const result = data[0];
    
    // Assuming that 'i.Photo' is the field containing the image blob
    if (result.photo && result.photo instanceof Buffer) {
      // Convert the image blob to Base64
      const base64Image = result.photo.toString('base64');
      const dataUrl = `data:image/jpeg;base64,${base64Image}`;

      // Update the result object with the Base64 data URL
      result.photo = dataUrl;
    }

    return res.json(result);
  });
});






//Collection of Waste Admin Data
//show all users
app.get("/WasteCollect",(req,res)=>{
    const q = " SELECT cr.id, cr.wasteType,  cr.quantity,  cr.collection_time, cr.disposal_time, u.username,  wl.Location_Name FROM Collection_Records AS cr JOIN users AS u ON cr.user_id = u.id JOIN waste_locations AS wl ON cr.locationID = wl.id "
    db.query(q,(err,data)=>{
        if(err)return res.json("failed to get users")
        return res.json(data)

    })
})

//delele Waaste Collection 
app.delete("/WasteCD/:id", (req, res) => {
    const id = req.params.id; // Corrected from req.params.id to req.params.username
    const q = "DELETE FROM Collection_Records WHERE id = ? ";
  
    db.query(q, [id], (err, data) => {
      if (err) return res.json(err);
      return res.json("Collectiom deleted successfully");
    });
  });




//Add collections
app.post("/addCollection", (req, res) => {
    const user_id = req.body.user_id;
    const wasteType = req.body.wasteType;
    const quantity = req.body.quantity;
    const locationID = req.body.locationID;
    const collection_time = req.body.collection_time;
    
    
    db.query(
      "INSERT INTO Collection_Records (user_id, wasteType, quantity, locationID , collection_time) VALUES (?,?,?,?,?)",
      [user_id, wasteType, quantity, locationID, collection_time],
      (err, result) => {
        console.log('error is ' +  err);
        if (err) return res.json(err);
        return res.send({ message: "Record Added successfully", data: result });
      }
    );
  });



//show in update / Collection
app.get('/CollectTextfield/:id', (req, res) => {
    const id = req.params.id;
  
    // Use a parameterized query to prevent SQL injection
    const q = 'SELECT * FROM Collection_Records WHERE id = ?';
    db.query(q, [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get user' });
      }
  
      if (results.length > 0) {
        const user = results[0];
        res.json(user);
      } else {
        res.status(404).json({ error: 'User not found' });
      }
    });
  });
   

// Update Fuel
app.put("/updateCollection/:id", (req, res) => {
    const id = req.params.id;
  
    // Extract values from the request body
    const { wasteType, quantity} = req.body;
  
    // Log the received data for debugging
    console.log('Received data:', {  wasteType, quantity });
  
    const q = 'UPDATE Collection_Records SET wasteType = ?, quantity = ?  WHERE id  = ?';
  
    db.query(q, [ wasteType, quantity, id ], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to update vehicle' });
      }
  
      res.json({ message: 'Update successful!' });
    });
  });



//Location

//show all Locations
app.get("/Locations",(req,res)=>{
    const q = "SELECT * FROM waste_locations "
    db.query(q,(err,data)=>{
        if(err)return res.json("failed to get users")
        return res.json(data)
    })
})


// Location Status update to grey out Mark Off
app.put("/MarkedOff/:id", (req, res) => {
    const id = req.params.id;
  
    // Extract values from the request body
    const { Status } = req.body;
  
    // Log the received data for debugging
    console.log('Received data:', { Status });
  
    const q = "UPDATE waste_locations SET `Status` = 'InActive' WHERE id = ?";
  
    db.query(q, [id], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to update Status' });
      }
  
      res.json({ message: 'Update successful!' });
    });
});

//Add Location
app.post("/addLocation", (req, res) => {
    const {Location_Name, Longitude, Latitude, 
      Description, Customer_Name, Schedule, Status,
       Frequency } = req.body
   
  
    
    db.query(
      "INSERT INTO waste_locations (Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency) VALUES  (?,?,?,?,?,?,?,?)",
      [ Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency],
      (err, result) => {
        console.log('error is ' +  err);
        if (err) return res.json(err);
        return res.send({ message: "Location Added successfully", data: result });
      }
    );
  });



  //delele issue
  app.delete("/LocationD/:id", (req, res) => {
    const id = req.params.id;
    const q1 = "SELECT Customer_Name FROM waste_locations WHERE id = ?";
    const q2 = "DELETE FROM waste_locations WHERE id = ?";
    const q3 = "DELETE FROM users WHERE full_name = ?";
  
    db.query(q1, [id], (err, data) => {
      if (err) return res.json(err);
  
      const customerName = data[0].Customer_Name;
  
      db.query(q2, [id], (err, _) => {
        if (err) return res.json(err);
  
        db.query(q3, [customerName], (err, _) => {
          if (err) return res.json(err);
          
          return res.json("Collection and associated user deleted successfully");
        });
      });
    });
  });
  



  //show in update / Location Fields
app.get('/LocationTextfield/:id', (req, res) => {
  const id = req.params.id;

  // Use a parameterized query to prevent SQL injection
  const q = 'SELECT * FROM waste_locations WHERE id = ?';
  db.query(q, [id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user' });
    }

    if (results.length > 0) {
      const user = results[0];
      res.json(user);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });
});
 

// Update Location
app.put("/updateLocation/:id", (req, res) => {
  const id = req.params.id;

  // Extract values from the request body
  const { Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency } = req.body;

  // Log the received data for debugging
  console.log('Received data:', { Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency });

  // Define the UPDATE query
  const q = `
    UPDATE waste_locations 
    SET Location_Name = ?, 
        Longitude = ?, 
        Latitude = ?, 
        Description = ?, 
        Customer_Name = ?, 
        Schedule = ?, 
        Status = ?, 
        Frequency = ? 
    WHERE id = ?;
    
    
  `;

  // Execute the query
  db.query(q, [Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency, id, Location_Name, Customer_Name], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update location' });
    }

    res.json({ message: 'Update successful!' });
  });
});



//Map View
app.get("/Map",(req,res)=>{
  const q = "SELECT * FROM waste_locations WHERE Status = 'Active' "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})



//GPS
//Record GPS
// app.post("/addGPS", (req, res) => {
//   const {UserID, vehicleID, Longitude, Latitude, Timestamp, Speed } = req.body
 
  
  
//   db.query(
//     "INSERT INTO GPS_Tracking (UserID, vehicleID, Longitude, Latitude, Timestamp, Speed) VALUES  (?,?,?,?,?,?)",
//     [ UserID, vehicleID, Longitude, Latitude, Timestamp, Speed],
//     (err, result) => {
//       console.log('error is ' +  err);
//       if (err) return res.json(err);
//       return res.send({ message: "Recording GPS Location ", data: result });
//     }
//   );
// });
//Add Customer ---GPS cant be added wihtout customer
app.post("/addGPS", (req, res) => {
  const { 
    username, password, role, full_name, email, phone_number, address, 
    Location_Name, Longitude, Latitude, Description, customer_name, 
    Schedule, Frequency, Status 
  } = req.body;

  console.log('Received data:', { 
    username, password, role, full_name, email, phone_number, address, 
    Location_Name, Longitude, Latitude, Description, customer_name, 
    Schedule, Frequency, Status 
  });

  const userInsertQuery = `
    INSERT INTO users (username, password, role, full_name, email, phone_number, address)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  const locationInsertQuery = `
    INSERT INTO waste_locations (Location_Name, Longitude, Latitude, Description, Customer_Name, Schedule, Status, Frequency)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(userInsertQuery, [username, password, role, full_name, email, phone_number, address], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to insert user data' });
    }

    db.query(locationInsertQuery, [Location_Name, Longitude, Latitude, Description, customer_name, Schedule, Status, Frequency], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to insert location data' });
      }

      res.json({ message: 'Insert successful!' });
    });
  });
});






//show all GPS
app.get("/GPS",(req,res)=>{
  const q = "WITH latest_per_user AS (SELECT UserID, MAX(id) AS latest_id FROM GPS_Tracking GROUP BY UserID) SELECT GPS_Tracking.Longitude, GPS_Tracking.Latitude, GPS_Tracking.Timestamp, GPS_Tracking.Speed, Users.id AS user_id, Users.username, Users.vehicle_id, Users.vehicle FROM GPS_Tracking INNER JOIN latest_per_user ON GPS_Tracking.UserID = latest_per_user.UserID AND GPS_Tracking.id = latest_per_user.latest_id INNER JOIN Users ON GPS_Tracking.UserID = Users.id "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//show all users with vehilces
app.get("/GPS-List",(req,res)=>{
  const q = "SELECT id, username, picture, vehicle FROM users WHERE vehicle_id IS NOT NULL "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//retrieve selected user info
app.get("/SelectedUser/:id", (req, res) => {
  const userId = req.params.id;

  const q = `
    WITH latest_per_user AS (
      SELECT UserID, MAX(id) AS latest_id 
      FROM GPS_Tracking 
      WHERE UserID = ?
      GROUP BY UserID
    )
    SELECT 
      GPS_Tracking.Longitude, 
      GPS_Tracking.Latitude, 
      GPS_Tracking.Timestamp, 
      GPS_Tracking.Speed, 
      Users.id AS user_id, 
      Users.username, 
      Users.vehicle_id, 
      Users.vehicle 
    FROM GPS_Tracking
    INNER JOIN latest_per_user ON GPS_Tracking.UserID = latest_per_user.UserID AND GPS_Tracking.id = latest_per_user.latest_id
    INNER JOIN Users ON GPS_Tracking.UserID = Users.id
  `;

  db.query(q, [userId], (err, data) => {
    if (err) return res.json("failed to get users");
    return res.json(data);
  });
});



//retrieve data for Si
app.get("/Simulate/:id", (req, res) => {
  const userId = req.params.id;

  const q = `
  SELECT Longitude, Latitude, Speed, Timestamp, id
  FROM GPS_Tracking
  WHERE UserID = ?;
  
  `;

  db.query(q, [userId], (err, data) => {
    if (err) return res.json("failed to get users");
    return res.json(data);
  });
});








//Issue
//All issues
app.get('/Issues', (req, res) => {
  const q = "SELECT i.id, i.IssueType, i.Description, i.Photo, i.Timestamp, i.solved, u.username, u.Vehicle FROM issues AS i INNER JOIN users AS u ON i.User_id = u.id ";

  db.query(q, (err, data) => {
    if (err) {
      return res.json("Failed to get issues");
    }

    // Convert Photo field from Blob to Base64
    const dataWithBase64 = data.map(item => ({
      ...item,
      Photo: item.Photo.toString('base64'), // Convert Blob to Base64
    }));

    return res.json(dataWithBase64);
  });
});

//All issues for second user only
app.get("/IssueSecond/:id", (req, res) => {
  const userId = req.params.id;

  const q = `
    SELECT i.IssueType, i.Description, i.Photo, i.Timestamp, u.username, u.Vehicle, i.id
    FROM issues AS i
    INNER JOIN users AS u ON i.User_id = u.id
    WHERE u.id = ?;
  `;

  db.query(q, [userId], (err, data) => {
    if (err) {
      return res.json("failed to get users");
    }

    // Convert the blob to a base64-encoded string
    const result = data.map(item => {
      return {
        ...item,
        Photo: item.Photo.toString("base64"),
      };
    });

    return res.json(result);
  });
});



// add new issue
app.post("/addissue", upload.single("Photo"), (req, res) => {
  const { User_id, IssueType, Description, Timestamp } = req.body;
  const Photo = req.file.buffer; // Access the file buffer

  db.query(
    "INSERT INTO Issues (User_id, IssueType, Description, Photo, Timestamp) VALUES  (?,?,?,?,?)",
    [User_id, IssueType, Description, Photo, Timestamp],
    (err, result) => {
      console.log('error is ' +  err);
      if (err) return res.json(err);
      return res.send({ message: "Issue Reported", data: result });
    }
  );
});


//delele issue
app.delete("/IssueD/:id", (req, res) => {
  const id = req.params.id; // Corrected from req.params.id to req.params.username
  const q = "DELETE FROM Issues WHERE id = ? ";

  db.query(q, [id], (err, data) => {
    if (err) return res.json(err);
    return res.json("Collectiom deleted successfully");
  });
});


//PopOver Preview
app.get("/pop/:id", (req, res) => {
  const id = req.params.id;

  const q = `
    SELECT i.IssueType, i.Description, i.Photo, i.Timestamp, u.username, u.Vehicle
    FROM issues AS i
    INNER JOIN users AS u ON i.User_id = u.id
    WHERE i.id = ?
  `;

  db.query(q, [id], (err, data) => {
    if (err) {
      return res.status(500).json({ error: "Failed to get data" });
    }

    if (data.length === 0) {
      return res.status(404).json({ error: "Data not found" });
    }

    const result = data[0];
    
    // Assuming that 'i.Photo' is the field containing the image blob
    if (result.Photo && result.Photo instanceof Buffer) {
      // Convert the image blob to Base64
      const base64Image = result.Photo.toString('base64');
      const dataUrl = `data:image/jpeg;base64,${base64Image}`;

      // Update the result object with the Base64 data URL
      result.Photo = dataUrl;
    }

    return res.json(result);
  });
});







//show in update / issue 
app.get('/IssuesUP/:id', (req, res) => {
  const id = req.params.id;

  // Use a parameterized query to prevent SQL injection
  const q = 'SELECT * FROM Issues WHERE id = ?';
  db.query(q, [id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user' });
    }

    if (results.length > 0) {
      const user = results[0];
      res.json(user);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });
});


// Update issue
app.put("/updateIssues/:id", upload.single('Photo'), (req, res) => {
  const id = req.params.id;

  // Extract values from the request body
  const { IssueType, Description , solved} = req.body;
  
  // The 'buffer' property is added by multer when handling file uploads
  const Photo = req.file ? req.file.buffer : null;

  // Log the received data for debugging
  console.log('Received data:', { IssueType, Description,solved});

  const q = 'UPDATE Fuel_logs SET IssueType = ?, Description = ?,solved = ? ,Photo = ? WHERE id = ?';

  db.query(q, [IssueType, Description, solved, Photo, id], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update vehicle' });
    }

    res.json({ message: 'Update successful!' });
  });
});

//solve isssues

app.put("/solved/:id", (req, res) => {
  const bookId = req.params.id;
  const q = "UPDATE Test.issues SET solved = ? WHERE id = ?"; // Corrected SQL query

  const values = ["Yes", bookId]; // Values to be updated

  db.query(q, values, (err, data) => {
    if (err) return res.status(500).json(err); // Return error response with status 500
    
    // If update was successful
    // Retrieve the user_id associated with the bookId
    const getUserQuery = "SELECT user_id FROM Test.issues WHERE id = ?";
    db.query(getUserQuery, [bookId], (err, result) => {
      if (err) return res.status(500).json(err); // Return error response with status 500
      
      const userId = result[0].user_id; // Extract user_id from the result
      
      // Now, retrieve the user role from the users table using the user_id
      const getRoleQuery = "SELECT role FROM Test.users WHERE id = ?";
      db.query(getRoleQuery, [userId], (err, result) => {
        if (err) return res.status(500).json(err); // Return error response with status 500
        
        const userRole = result[0].role; // Extract user role from the result
        
        // Now, post data to the notifications table
        const insertNotificationQuery = "INSERT INTO Test.notification (role, user_id, message) VALUES (?, ?, ?)";
        const notificationMessage = "Your issue has been solved successfull. Thanks for the complaint";
        db.query(insertNotificationQuery, [userRole, userId, notificationMessage], (err, result) => {
          if (err) return res.status(500).json(err); // Return error response with status 500
          
          return res.json("Issue marked as solved successfully and notification posted");
        });
      });
    });
  });
});







































//Charts

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



// Define a route to retrieve data for all vehicles
app.get('/vehicleUsage', (req, res) => {
  // Query to retrieve total mileage for each vehicle model
  const query = `
    SELECT
      Vehicle.Model,
      SUM(TripDistance) AS TotalMileage
    FROM Vehicle
    INNER JOIN (
      SELECT
        Vehicle.Model,
        GREATEST(
          (t1.Timestamp - t2.Timestamp) * t1.Speed,
          0
        ) AS TripDistance
      FROM GPS_Tracking t1
      INNER JOIN GPS_Tracking t2 ON t1.vehicleID = t2.vehicleID AND t1.Timestamp > t2.Timestamp
      INNER JOIN Vehicle ON t1.vehicleID = Vehicle.VehicleID
    ) AS MileageData ON Vehicle.Model = MileageData.Model
    WHERE MileageData.TripDistance > 0
    GROUP BY Vehicle.Model;
  `;

  db.query(query, (error, results) => {
    if (error) {
      console.error("Error executing query:", error);
      res.status(500).json({ error: 'Internal server error' });
    } else {
      if (results.length > 0) {
        res.json(results);
      } else {
        res.status(404).json({ error: 'No vehicles found' });
      }
    }
  });
});







//vehicle on Route 
app.get("/VRoute",(req,res)=>{
  const q = " SELECT COUNT(DISTINCT vehicleID) AS num_vehicles FROM GPS_Tracking "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//fuel cost
app.get("/FCost",(req,res)=>{
  const q = " SELECT SUM(cost) AS fuel_cost FROM Fuel_Logs "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})





//Driver status
app.get("/DStats",(req,res)=>{
  const q = "SELECT id, username, picture, vehicle, CASE WHEN status = 'Yes' THEN 'Active' ELSE 'Inactive' END AS status FROM users WHERE vehicle_id IS NOT NULL "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//Num of roles
app.get("/NumR",(req,res)=>{
  const q = "SELECT role, COUNT(*) AS total_users FROM Users WHERE role IN ('Admin', 'Garbage Collector', 'Clerk') GROUP BY role "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//Num of roles
app.get("/OPtop",(req,res)=>{
  const q = "SELECT sum(quantity) AS total_disposals, (SELECT COUNT(DISTINCT customer_name) FROM waste_locations) AS total_customers, (SELECT SUM(quantity) FROM collection_records) AS total_waste_collected, (SELECT COUNT(id) FROM users) AS total_users FROM Collection_Records WHERE disposal_time IS NOT NULL "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//Most reported issue
app.get("/MRep",(req,res)=>{
  const q = "SELECT IssueType, COUNT(*) AS Count FROM issues GROUP BY IssueType "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//Active usersG
app.get("/AUG",(req,res)=>{
  const q = "SELECT role, COUNT(*) AS users_with_yes_status FROM Users WHERE status = 'yes' GROUP BY role "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//CusReg
app.get("/CusReg",(req,res)=>{
  const q = "SELECT Location_Name, COUNT(*) AS count FROM waste_locations GROUP BY Location_Name "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})


app.get("/WorkU", (req, res) => {
  const q = "SELECT u.id AS user_id, u.username, u.picture, SUM(vcr.quantity) AS total_quantity FROM Users u LEFT JOIN Collection_Records vcr ON u.id = vcr.user_id WHERE u.role = 'Garbage Collector' GROUP BY u.username, u.id"
  db.query(q, (err, data) => {
    if (err) {
      console.error("Error executing SQL query:", err);
      return res.json("Failed to get users");
    }
    console.log("SQL query result:", data);
    return res.json(data);
  });
});

//NumCollWaste
app.get("/NCW",(req,res)=>{  const q = "SELECT COUNT(id) AS total_records  FROM Test.Collection_Records  WHERE disposal_time IS NOT NULL"
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//NumCollWaste to user/collector
// Backend
app.get('/NCWC/:id', (req, res) => {
  const id = req.params.id;

  // Use a parameterized query to prevent SQL injection
  const q = 'SELECT COUNT(*) AS total_records FROM Test.Collection_Records  WHERE user_id = ? and disposal_time IS NOT NULL;';

  db.query(q, [id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user' });
    }

    // Handle the results and send a response
    const totalRecords = results[0].total_records;
    res.json({ total_records: totalRecords });
  });
});

//////////////////////////////

//NumCollWaste
app.get("/WNCW",(req,res)=>{  const q = "SELECT COUNT(id) AS total_records  FROM Test.Collection_Records "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//NumCollWaste to user/collector
// Backend
app.get('/WNCWC/:id', (req, res) => {
  const id = req.params.id;

  // Use a parameterized query to prevent SQL injection
  const q = 'SELECT COUNT(*) AS total_records FROM Test.Collection_Records  WHERE user_id = ? ';

  db.query(q, [id], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user' });
    }

    // Handle the results and send a response
    const totalRecords = results[0].total_records;
    res.json({ total_records: totalRecords });
  });
});




app.get("/latestChanges", (req, res) => {
  const q = `
  (
    SELECT id AS record_id, IssueType AS title, Description AS description, Timestamp AS record_time
    FROM issues
    ORDER BY record_time DESC
    LIMIT 1
)
UNION
(
    SELECT id, wasteType AS title, quantity AS description, collection_time AS record_time
    FROM Collection_Records
    WHERE user_id IS NOT NULL
    ORDER BY record_time DESC
    LIMIT 1
)
UNION
(
    SELECT id, username AS title, role AS description, employment_date AS record_time
    FROM Users
    ORDER BY employment_date DESC
    LIMIT 1
)
UNION
(
    SELECT VehicleID, Model AS title, VehicleType AS description, NULL AS record_time
    FROM Vehicle
    ORDER BY Model DESC
    LIMIT 1
)
UNION
(
    SELECT id, Location_Name AS title, Description AS description, NULL AS record_time
    FROM waste_locations
    ORDER BY Location_Name DESC
    LIMIT 1
);

  `;

  db.query(q, (err, data) => {
    if (err) return res.json("failed to get latest changes");
    return res.json(data);
  });
});



////Waste In Chart 

//Date and Waste in
app.get("/WasteIn",(req,res)=>{  const q = 
  `SELECT
CASE WHEN MIN(collection_time) IS NOT NULL THEN DATE_FORMAT(MIN(collection_time), '%m-%d-%Y') ELSE NULL END AS average_date,
SUM(quantity) AS total_quantity
FROM Collection_Records
GROUP BY YEAR(collection_time), MONTH(collection_time)
ORDER BY average_date ASC
`
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//Waste Out
//Date and Waste in
app.get("/WasteOut",(req,res)=>{  const q = 
  `SELECT
  CASE WHEN MIN(collection_time) IS NOT NULL THEN DATE_FORMAT(MIN(collection_time), '%m-%d-%Y') ELSE NULL END AS average_date,
  SUM(quantity) AS total_quantity
FROM Collection_Records
WHERE disposal_time IS NOT NULL
GROUP BY YEAR(collection_time), MONTH(collection_time)
ORDER BY average_date ASC

`
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

//Revue Amount
app.get("/Rev",(req,res)=>{
  const q = "SELECT sum(price) FROM Test.users;"
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})



/////////////////////////////////////////////////////
//Personaliozed Report

//Waste type
app.get('/CWtype/:id', (req, res) => {
  const userId = req.params.id;

  // First query to get waste_location_id based on user ID
  const userLocationQuery = `
    SELECT
      wl.id AS waste_location_id
    FROM
      users u
    JOIN
      waste_locations wl ON u.full_name = wl.Customer_Name
    WHERE
      u.role = 'customer' AND u.id = ?
  `;

  db.query(userLocationQuery, [userId], (err, userLocationResults) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user location' });
    }

    if (userLocationResults.length === 0) {
      return res.status(404).json({ error: 'User location not found' });
    }

    const wasteLocationId = userLocationResults[0].waste_location_id;

    // Second query to get waste type and quantity based on waste_location_id
    const wasteQuery = `
      SELECT
        wastetype,
        quantity
      FROM
        Test.Collection_Records
      WHERE
        locationID = ?
    `;

    db.query(wasteQuery, [wasteLocationId], (err, wasteResults) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get waste records' });
      }

      if (wasteResults.length === 0) {
        return res.status(404).json({ error: 'Waste records not found' });
      }

      res.json(wasteResults); // Return waste records
    });
  });
});



//history
app.get('/CHistory/:id', (req, res) => {
  const userId = req.params.id;

  // First query to get waste_location_id based on user ID
  const userLocationQuery = `
    SELECT
      wl.id AS waste_location_id
    FROM
      users u
    JOIN
      waste_locations wl ON u.full_name = wl.Customer_Name
    WHERE
      u.role = 'customer' AND u.id = ?
  `;

  db.query(userLocationQuery, [userId], (err, userLocationResults) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user location' });
    }

    if (userLocationResults.length === 0) {
      return res.status(404).json({ error: 'User location not found' });
    }

    const wasteLocationId = userLocationResults[0].waste_location_id;

    // Second query to get waste type and quantity based on waste_location_id
    const wasteQuery = `
    SELECT
    u.username,
    u.picture,
    cr.quantity,
    cr.collection_time,
    wl.location_name
FROM
    Users u
JOIN
    Collection_Records cr ON u.id = cr.user_id
JOIN
    waste_locations wl ON cr.locationID = wl.id
WHERE
    cr.locationID = ?;


    `;

    db.query(wasteQuery, [wasteLocationId], (err, wasteResults) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get waste records' });
      }

      if (wasteResults.length === 0) {
        return res.status(404).json({ error: 'Waste records not found' });
      }

      res.json(wasteResults); // Return waste records
    });
  });
});


//Total waste collected for customer
app.get('/TotalWasteC/:id', (req, res) => {
  const userId = req.params.id;

  // First query to get waste_location_id based on user ID
  const userLocationQuery = `
    SELECT
      wl.id AS waste_location_id
    FROM
      users u
    JOIN
      waste_locations wl ON u.full_name = wl.Customer_Name
    WHERE
      u.role = 'customer' AND u.id = ?
  `;

  db.query(userLocationQuery, [userId], (err, userLocationResults) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user location' });
    }

    if (userLocationResults.length === 0) {
      return res.status(404).json({ error: 'User location not found' });
    }

    const wasteLocationId = userLocationResults[0].waste_location_id;

    // Second query to get waste type and quantity based on waste_location_id
    const wasteQuery = `
    SELECT sum(quantity) FROM Test.Collection_Records where locationID=?


    `;

    db.query(wasteQuery, [wasteLocationId], (err, wasteResults) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get waste records' });
      }

      if (wasteResults.length === 0) {
        return res.status(404).json({ error: 'Waste records not found' });
      }

      res.json(wasteResults); // Return waste records
    });
  });
});


//customer sub
app.get("/Csub/:id", (req, res) => {
  const userId = req.params.id;

  const q = `
  SELECT subscriptions FROM Users WHERE id=?;
  `;

  db.query(q, [userId], (err, data) => {
    if (err) {
      console.error('Error fetching user subscriptions:', err);
      return res.status(500).json({ error: 'Failed to fetch user subscriptions' });
    }

    return res.json(data); // Returning data instead of result
  });
});




/////////////
app.get("/subData",(req,res)=>{
  const q = ` SELECT subscriptions, COUNT(*) AS count
  FROM Test.users
  GROUP BY subscriptions`
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})






//////////////////////////////////////////////////////////////////////////////////////////

//Total waste collected for customer
app.get('/CdashDate/:id', (req, res) => {
  const userId = req.params.id;

  // First query to get waste_location_id based on user ID
  const userLocationQuery = `
    SELECT
      wl.id AS waste_location_id
    FROM
      users u
    JOIN
      waste_locations wl ON u.full_name = wl.Customer_Name
    WHERE
      u.role = 'customer' AND u.id = ?
  `;

  db.query(userLocationQuery, [userId], (err, userLocationResults) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to get user location' });
    }

    if (userLocationResults.length === 0) {
      return res.status(404).json({ error: 'User location not found' });
    }

    const wasteLocationId = userLocationResults[0].waste_location_id;

    // Second query to get waste type and quantity based on waste_location_id
    const wasteQuery = `
    SELECT Schedule FROM Test.waste_locations where id =?


    `;

    db.query(wasteQuery, [wasteLocationId], (err, wasteResults) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Failed to get waste records' });
      }

      if (wasteResults.length === 0) {
        return res.status(404).json({ error: 'Waste records not found' });
      }

      res.json(wasteResults); // Return waste records
    });
  });
});









//Settings

app.get("/Settings",(req,res)=>{
  const q = "SELECT * FROM Test.settings; "
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})

// PUT request to update settings
app.put("/SettingsUpdate", (req, res) => {
  const { start_time, end_time, Standard, professional, Enterprise } = req.body;
  const id = 1; // Assuming id is always 1
  let params = [];
  let updates = [];

  if (start_time !== undefined && start_time !== '') {
      updates.push("start_time = ?");
      params.push(start_time);
  }
  if (end_time !== undefined && end_time !== '') {
      updates.push("end_time = ?");
      params.push(end_time);
  }
  if (Standard !== undefined && Standard !== '') {
      updates.push("Standard = ?");
      params.push(Standard);
  }
  if (professional !== undefined && professional !== '') {
      updates.push("professional = ?");
      params.push(professional);
  }
  if (Enterprise !== undefined && Enterprise !== '') {
      updates.push("Enterprise = ?");
      params.push(Enterprise);
  }

  if (updates.length === 0) {
      return res.json("No valid fields provided for update");
  }

  const updateString = updates.join(', ');
  const q = `UPDATE Test.settings SET ${updateString} WHERE id = ?`;
  params.push(id);

  db.query(q, params, (err, result) => {
      if (err) return res.json("failed to update settings");
      return res.json("settings updated successfully");
  });
});





//
app.post('/ErrorT', (req, res) => {
  const displayID = req.body.displayID;
  const number = req.body.number;

  // Query to check if the user with the provided displayID has role 'Clerk'
  const query = `SELECT username FROM users WHERE Id = ? AND role = 'Clerk'`;

  // Execute the query
  db.query(query, [displayID], (err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    if (results.length === 0) {
      // No user found with the provided displayID and role 'Clerk'
      res.status(404).send(' not a Clerk');
    } else {
      const username = results[0].username;
      
      // Insert the username and number into errorCheck table
      const insertQuery = `INSERT INTO errorCheck (name, number) VALUES (?, ?)`;
     db.query(insertQuery, [username, number], (err, results) => {
        if (err) {
          console.error('Error executing insert query: ' + err.stack);
          res.status(500).send('Internal Server Error');
          return;
        }
        // Successfully inserted data into errorCheck table
        res.status(200).send('Data inserted successfully');
      });
    }
  });
});







app.get("/ClerkR",(req,res)=>{
  const q = `SELECT name, SUM(number) AS number
  FROM Test.errorCheck
  GROUP BY name;`
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})





//carbon Emmissions
app.get("/Carbon",(req,res)=>{
  const q = `
  
  WITH DistanceCalculation AS (
    SELECT
      gt.vehicleID,
      SUM(
        ACOS(SIN(RADIANS(gt.Latitude)) * SIN(RADIANS(gt_prev.Latitude)) +
            COS(RADIANS(gt.Latitude)) * COS(RADIANS(gt_prev.Latitude)) *
            COS(RADIANS(gt.Longitude - gt_prev.Longitude))) * 6371) AS total_distance_km
    FROM
      GPS_Tracking gt
    JOIN
      GPS_Tracking gt_prev ON gt.vehicleID = gt_prev.vehicleID
    GROUP BY
      gt.vehicleID
  ),
  FuelConsumption AS (
    SELECT
      fl.VehicleID,
      SUM(fl.cost) AS total_fuel_cost
    FROM
      Fuel_logs fl
    GROUP BY
      fl.VehicleID
  ),
  CarbonEmission AS (
    SELECT
      fc.VehicleID,
      fc.total_fuel_cost,
      dc.total_distance_km,
      (fc.total_fuel_cost * 2.3) / NULLIF(dc.total_distance_km, 0) AS estimated_carbon_emission_per_km,
      (fc.total_fuel_cost * 2.3) AS total_carbon_emission
    FROM
      DistanceCalculation dc
    JOIN
      FuelConsumption fc ON dc.vehicleID = fc.VehicleID
  )
  SELECT
    ce.VehicleID,
    u.username,
    u.picture,
    ce.total_fuel_cost,
    ce.total_distance_km,
    ce.estimated_carbon_emission_per_km,
    ce.total_carbon_emission
  FROM
    CarbonEmission ce
  JOIN
    users u ON ce.VehicleID = u.vehicle_id
  ORDER BY ce.VehicleID;
  `
  db.query(q,(err,data)=>{
      if(err)return res.json("failed to get users")
      return res.json(data)
  })
})




//notification 
app.get("/Notif", (req, res) => {
  let q = `SELECT * FROM Test.notification`;
  const storedUserRole = req.query.userRole; // Retrieve user role from query parameter

  // If user role is not Admin, filter notifications based on the user role
  if (storedUserRole && storedUserRole !== 'Admin') {
    q += ` WHERE role = '${storedUserRole}'`;
  }

  db.query(q, (err, data) => {
    if (err) return res.json("Failed to get notifications");
    return res.json(data);
  });
});




//for others
app.get("/NotiOthers/:id", (req, res) => {
  const userId = req.params.id;

  const q = `
  SELECT  role,  message FROM Test.notification where user_id = ?;
  `;

  db.query(q, [userId], (err, data) => {
    if (err) {
      return res.json("failed to get users");
    }
    return res.json(result);
  });
});


//id, role, user_id, message

//send notification

app.post("/notification", (req, res) => {
  const q = "INSERT INTO notification (role, user_id, message) VALUES (?, ?,?)";
  const values = [req.body.role, req.body.user_id,req.body.message];
  db.query(q, values, (err, data) => {
      if (err) {
          console.error("Error inserting data:", err);
          return res.status(500).json({ error: "Internal Server Error" });
      }
      return res.json("Data inserted successfully");
  });
});




//to check if its connected to database
// db.connect((err) => {
//     if (err) {
//         console.error("Error connecting to MySQL:", err);
//     } else {
//         console.log("Connected to MySQL database");
//     }
// });